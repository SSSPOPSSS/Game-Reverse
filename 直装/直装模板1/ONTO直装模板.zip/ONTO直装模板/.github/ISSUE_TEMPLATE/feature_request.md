---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

<!-- Describe your feature request here -->

<!-- Not all features we would accept. However, you can try to implement it yourself. It is open source, you are free to do anything you want. Spoonfeeding is not acceptable here :) -->
