//TODO
//Text input string

package uk.lgl.modmenu;

import android.animation.ArgbEvaluator;
import android.animation.TimeAnimator;
import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

import uk.lgl.NativeToast;

import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.widget.RelativeLayout.ALIGN_PARENT_RIGHT;
import android.icu.text.*;

public class FloatingModMenuService extends Service {
    //********** 在这里您可以轻松地更改菜单外观 **********//
    final String TAG = "Mod_Menu"; //Tag for logcat
    final int TEXT_COLOR = Color.parseColor("#000000");
    final int TEXT_COLOR_2 = Color.parseColor("#FFFFFF");
    final int BTN_COLOR = Color.parseColor("#FFFFFF");

    final int MENU_BG_COLOR = Color.parseColor("#FFFFFF"); //#AARRGGBB
    final int MENU_FEATURE_BG_COLOR = Color.parseColor("#C0FFFF"); //#AARRGGBB
    final int MENU_WIDTH = 100;
    final int MENU_HEIGHT = 100;
    final float MENU_CORNER = 20f;
    final int ICON_SIZE = 35;
    final float ICON_ALPHA = 2.0f; //Transparent
    //********************************************************************//

    //Some fields
    GradientDrawable gdMenuBody, gdAnimation = new GradientDrawable();
    RelativeLayout mCollapsed, mRootContainer;
    LinearLayout mExpanded, patches, mSettings;
    WindowManager mWindowManager;
    WindowManager.LayoutParams params;
    ImageView startimage;
    FrameLayout rootFrame;
    AlertDialog alert;
    EditText edittextvalue;
    ScrollView scrollView;

    //For alert dialog
    TextView inputFieldTextView;
    String inputFieldFeatureName;
    int inputFieldFeatureNum;
    EditTextValue inputFieldTxtValue;

    LinearLayout.LayoutParams scrlLLExpanded, scrlLL;

	
    //initialize methods from the native library
    native String Title();

    native String Heading();

    native String Icon();

    native String IconWebViewData();

    native String[] getFeatureList();

    native boolean isGameLibLoaded();

    //When this Class is called the code in this function will be executed
    @Override
    public void onCreate() {
        super.onCreate();
        Preferences.context = this;

        //A little message for the user when he opens the app
        NativeToast.makeText(this, 0);

        //创建菜单
        initFloating();
        initAlertDiag();

        //启动渐变动画
        startAnimation();

        //为此类创建处理程序
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            public void run() {
                Thread();
                handler.postDelayed(this, 1000);
            }
        });
    }

    //Here we write the code for our Menu
    // Reference: https://www.androidhive.info/2016/11/android-floating-widget-like-facebook-chat-head/
    private void initFloating() {
        rootFrame = new FrameLayout(this); // Global markup
        rootFrame.setOnTouchListener(onTouchListener());
        mRootContainer = new RelativeLayout(this); // Markup on which two markups of the icon and the menu itself will be placed
        mCollapsed = new RelativeLayout(this); // Markup of the icon (when the menu is minimized)
        mCollapsed.setVisibility(View.VISIBLE);
        mCollapsed.setAlpha(ICON_ALPHA);

        //********** Mod菜单的框 **********
        mExpanded = new LinearLayout(this); // Menu markup (when the menu is expanded)
        mExpanded.setVisibility(View.GONE);
        mExpanded.setBackgroundColor(MENU_BG_COLOR);
        mExpanded.setGravity(Gravity.CENTER);
        mExpanded.setOrientation(LinearLayout.VERTICAL);
        mExpanded.setPadding(1, 1, 1, 1);
        mExpanded.setLayoutParams(new LinearLayout.LayoutParams(dp(MENU_WIDTH), WRAP_CONTENT));
        gdMenuBody = new GradientDrawable();
        gdMenuBody.setCornerRadius(MENU_CORNER); //Set corner
        gdMenuBody.setColor(MENU_BG_COLOR); //Set background color
        //gradientdrawable.setStroke(1, Color.parseColor("#32cb00")); //Set border
        mExpanded.setBackground(Preferences.loadPrefBoolean("Color animation", 1001) ? gdAnimation : gdMenuBody); //Apply aninmation to it

        //********** 打开mod菜单的图标 **********
        startimage = new ImageView(this);
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
        int applyDimension = (int) TypedValue.applyDimension(1, ICON_SIZE, getResources().getDisplayMetrics()); //Icon size
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode = Base64.decode(Icon(), 0);
        startimage.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);
        //Initialize event handlers for buttons, etc.
        startimage.setOnTouchListener(onTouchListener());
        startimage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mCollapsed.setVisibility(View.GONE);
                mExpanded.setVisibility(View.VISIBLE);
            }
        });

        //********** The icon in Webview to open mod menu **********
        WebView wView = new WebView(this); //Icon size width=\"50\" height=\"50\"
        wView.loadData("<html>" +
                "<head></head>" +
                "<body style=\"margin: 0; padding: 0\">" +
                "<img src=\"" + IconWebViewData() + "\" width=\"" + ICON_SIZE + "\" height=\"" + ICON_SIZE + "\"" +
                "</body>" +
                "</html>", "text/html", "utf-8");
        wView.setBackgroundColor(0x00000000); //Transparent
        wView.setAlpha(ICON_ALPHA);
        wView.getSettings().setAppCachePath("/data/data/" + getPackageName() + "/cache");
        wView.getSettings().setAppCacheEnabled(true);
        wView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        wView.setOnTouchListener(onTouchListener());
        wView.requestLayout();
		
		//********** Settings icon **********
        TextView settings = new TextView(this); //Android 5 can't show ⚙, instead show other icon instead
        settings.setText(Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M ? "⚙" : "\uD83D\uDD27");
        settings.setTextColor(TEXT_COLOR);
        settings.setTypeface(Typeface.DEFAULT_BOLD);
        settings.setTextSize(20.0f);
        RelativeLayout.LayoutParams rlsettings = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        rlsettings.addRule(ALIGN_PARENT_RIGHT);
        settings.setLayoutParams(rlsettings);
        settings.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					try {
						scrollView.removeView(patches);
						scrollView.addView(mSettings);
					} catch (IllegalStateException e) {
					}
				}
			});

        
        

        //********** Title text **********
        RelativeLayout titleText = new RelativeLayout(this);
        titleText.setPadding(10, 5, 10, 5);
        titleText.setVerticalGravity(16);

        TextView title = new TextView(this);
        title.setText(Html.fromHtml(Title()));
        title.setTextColor(TEXT_COLOR);
        title.setTextSize(18.0f);
        title.setGravity(Gravity.CENTER);
        RelativeLayout.LayoutParams rl = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        rl.addRule(RelativeLayout.CENTER_HORIZONTAL);
        title.setLayoutParams(rl);

        //********** Heading text **********
        TextView heading = new TextView(this);
        heading.setText(Html.fromHtml(Heading()));
        heading.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        heading.setMarqueeRepeatLimit(-1);
        heading.setSingleLine(true);
        heading.setSelected(true);
        heading.setTextColor(TEXT_COLOR);
        heading.setTextSize(10.0f);
        heading.setGravity(Gravity.CENTER);
        heading.setPadding(0, 0, 0, 5);
		
		
		CheckBox closeBtn1 = new CheckBox(this);
        closeBtn1.setBackgroundColor(Color.TRANSPARENT);
        closeBtn1.setText("开启绘制");
		RunShell(("chmod 777 /data/data/com.tencent.igolivic/lib/libAndroid.so"));
		closeBtn1.setTextColor(TEXT_COLOR);
		closeBtn1.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					NativeToast.makeText(view.getContext(), 1);
				}
			});
		
		CheckBox closeBtn2 = new CheckBox(this);
        closeBtn2.setBackgroundColor(Color.TRANSPARENT);
        closeBtn2.setText("人物射线");
		RunShell(("chmod 777 /data/data/com.tencent.tmgp.pubgmhd/lib/libshell-super.2019.so"));
		closeBtn2.setTextColor(TEXT_COLOR);
		closeBtn2.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					NativeToast.makeText(view.getContext(), 2);
				}
 			});
         CheckBox closeBtn3 = new CheckBox(this);
        closeBtn3.setBackgroundColor(Color.TRANSPARENT);
        closeBtn3.setText("人物骨骼");
		RunShell(("chmod 777 /data/data/com.tencent.tmgp.pubgmhd/lib/libshell-super.2019.so"));
		closeBtn3.setTextColor(TEXT_COLOR);
		closeBtn3.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					NativeToast.makeText(view.getContext(), 3);
				}
			});

        CheckBox closeBtn4 = new CheckBox(this);
        closeBtn4.setBackgroundColor(Color.TRANSPARENT);
        closeBtn4.setText("人物血量");
		RunShell(("chmod 777 /data/data/com.tencent.tmgp.pubgmhd/lib/libshell-super.2019.so"));
		closeBtn4.setTextColor(TEXT_COLOR);
		closeBtn4.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					NativeToast.makeText(view.getContext(), 4);
				}
			});
			
		CheckBox closeBtn5 = new CheckBox(this);
        closeBtn5.setBackgroundColor(Color.TRANSPARENT);
        closeBtn5.setText("人物名称");
		RunShell(("chmod 777 /data/data/com.tencent.tmgp.pubgmhd/lib/libshell-super.2019.so"));
		closeBtn5.setTextColor(TEXT_COLOR);
		closeBtn5.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					NativeToast.makeText(view.getContext(), 5);
				}
			});

		CheckBox closeBtn6 = new CheckBox(this);
        closeBtn6.setBackgroundColor(Color.TRANSPARENT);
        closeBtn6.setText("人物方框");
		RunShell(("chmod 777 /data/data/com.tencent.tmgp.pubgmhd/lib/libshell-super.2019.so"));
		closeBtn6.setTextColor(TEXT_COLOR);
		closeBtn6.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					NativeToast.makeText(view.getContext(), 6);
				}
			});
			
			
			
			
			
			
			
			
			
        //********** MOD菜单功能列表**********
        scrollView = new ScrollView(this);
        //Auto size. To set size manually, change the width and height example 500, 500
        scrlLL = new LinearLayout.LayoutParams(MATCH_PARENT, dp(MENU_HEIGHT));
        scrlLLExpanded = new LinearLayout.LayoutParams(mExpanded.getLayoutParams());
        scrlLLExpanded.weight = 1.0f;
        scrollView.setLayoutParams(Preferences.loadPrefBoolean("Auto size vertically", 1002) ? scrlLLExpanded : scrlLL);
        scrollView.setBackgroundColor(MENU_FEATURE_BG_COLOR);

        patches = new LinearLayout(this);
        patches.setOrientation(LinearLayout.VERTICAL);
        patches.setBackgroundColor(MENU_FEATURE_BG_COLOR);

        //**********  隐藏/取消按钮 **********
        RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setPadding(10, 3, 10, 3);
        relativeLayout.setVerticalGravity(Gravity.CENTER);

        Button hideBtn = new Button(this);
        hideBtn.setBackgroundColor(Color.TRANSPARENT);
        hideBtn.setText("");//隐藏图标
        hideBtn.setTextColor(TEXT_COLOR);
        hideBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mCollapsed.setVisibility(View.VISIBLE);
                mCollapsed.setAlpha(0);
                mExpanded.setVisibility(View.GONE);
                NativeToast.makeText(view.getContext(), 11);
            }
        });
        hideBtn.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View view) {
                NativeToast.makeText(view.getContext(), 11);
                FloatingModMenuService.this.stopSelf();
                return false;
            }
        });
	

		CheckBox closeBtn7 = new CheckBox(this);
        closeBtn7.setBackgroundColor(Color.TRANSPARENT);
        closeBtn7.setText("附近车辆");
		RunShell(("chmod 777 /data/data/tencent.tmgp.pubgmhd/lib/libshell-super.2019.so"));
		closeBtn7.setTextColor(TEXT_COLOR);
		closeBtn7.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					
					NativeToast.makeText(view.getContext(), 7);
				}
			});
		
			
		CheckBox closeBtn8 = new CheckBox(this);
        closeBtn8.setBackgroundColor(Color.TRANSPARENT);
        closeBtn8.setText("附近资源");
		RunShell(("chmod 777 /data/data/tencent.tmgp.pubgmhd/lib/lib11.so"));
		closeBtn8.setTextColor(TEXT_COLOR);
		closeBtn8.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					NativeToast.makeText(view.getContext(), 8);
				}
			});

    
        //********** 关闭按钮**********
        Button closeBtn = new Button(this);
        closeBtn.setBackgroundColor(Color.TRANSPARENT);
        closeBtn.setText("");//最小化
        closeBtn.setTextColor(TEXT_COLOR);
        closeBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mCollapsed.setVisibility(View.VISIBLE);
                mCollapsed.setAlpha(ICON_ALPHA);
                mExpanded.setVisibility(View.GONE);
               NativeToast.makeText(view.getContext(), 10);
            }
        });

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        layoutParams.addRule(ALIGN_PARENT_RIGHT);
        closeBtn.setLayoutParams(layoutParams);

        //********** Params **********
        //Variable to check later if the phone supports Draw over other apps permission
        int iparams = Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O ? 2038 : 2002;
        params = new WindowManager.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, iparams, 8, -3);
        params.gravity = 51;
        params.x = 0;
        params.y = 100;

        //********** 添加视图组件**********
        rootFrame.addView(mRootContainer);
        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);
        if (IconWebViewData() != null) {
            mCollapsed.addView(wView);
        } else {
            mCollapsed.addView(startimage);
        }
        titleText.addView(title);
        mExpanded.addView(titleText);
        mExpanded.addView(closeBtn1);
		mExpanded.addView(closeBtn2);
		mExpanded.addView(closeBtn3);
		mExpanded.addView(closeBtn4);
		mExpanded.addView(closeBtn5);
		mExpanded.addView(closeBtn6);
		mExpanded.addView(closeBtn7);
		mExpanded.addView(closeBtn8);
        relativeLayout.addView(hideBtn);
        relativeLayout.addView(closeBtn);
        mExpanded.addView(relativeLayout);
        mWindowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        mWindowManager.addView(rootFrame, params);

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            boolean viewLoaded = false;

            @Override
            public void run() {
                //If the save preferences is enabled, it will check if game lib is loaded before starting menu
                //Comment the if-else code out except startService if you want to run the app and test preferences
                if (Preferences.savePref && !isGameLibLoaded()) {
                    if (!viewLoaded) {
                        Category("Save preferences was been enabled. Waiting for game lib to be loaded...\n\nTo cancel it, disable Save preferences from settings");
                        viewLoaded = true;
                    }
                    handler.postDelayed(this, 1000);
                } else {
                    patches.removeAllViews();
                    //********** 创建菜单列表**********
                    String[] listFT = getFeatureList();
                    for (int i = 0; i < listFT.length; i++) {
                        final int feature = i;
                        String str = listFT[i];
                        String[] strSplit = str.split("_");
          
                        if (strSplit[0].equals("CheckBox")) {
                            CheckBox(feature, strSplit[1]);
						} else if (strSplit[0].equals("CheckBox2")) {
                            CheckBox(feature, strSplit[1]);
                    }
					}
                }
            }
        }, 500);
    }

	private void RunShell(String p0)
	{
		// TODO: 实现此方法
	}
	
	
	
	
	
	
	
	
	
	

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX, initialTouchY;
            private int initialX, initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);

                        //The check for Xdiff <10 && YDiff< 10 because sometime elements moves a little while clicking.
                        //So that is click event.
                        if (rawX < 10 && rawY < 10 && isViewCollapsed()) {
                            //When user clicks on the image view of the collapsed layout,
                            //visibility of the collapsed layout will be changed to "View.GONE"
                            //and expanded view will become visible.
                            try {
                                collapsedView.setVisibility(View.GONE);
                                expandedView.setVisibility(View.VISIBLE);
                            } catch (NullPointerException e) {

                            }
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        //Calculate the X and Y coordinates of the view.
                        params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));
                        //Update the layout with new X & Y coordinate
                        mWindowManager.updateViewLayout(rootFrame, params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

    //Dialog for changing value
    private void initAlertDiag() {
        //LinearLayout 线性布局
        LinearLayout linearLayout1 = new LinearLayout(this);
        linearLayout1.setPadding(5, 5, 5, 5);
        linearLayout1.setOrientation(LinearLayout.VERTICAL);
        linearLayout1.setBackgroundColor(MENU_FEATURE_BG_COLOR);

        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.VERTICAL);

        //FrameLayout 框架布局
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.addView(linearLayout);

       
        edittextvalue = new EditText(this);
        edittextvalue.setMaxLines(1);
        edittextvalue.setWidth(convertDipToPixels(300));
        edittextvalue.setTextColor(TEXT_COLOR_2);
        edittextvalue.setHintTextColor(Color.parseColor("#434d52"));
        edittextvalue.setInputType(InputType.TYPE_CLASS_NUMBER);
        edittextvalue.setKeyListener(DigitsKeyListener.getInstance("0123456789-"));

        InputFilter[] FilterArray = new InputFilter[1];
        FilterArray[0] = new InputFilter.LengthFilter(10);
        edittextvalue.setFilters(FilterArray);

		
		
        alert = new AlertDialog.Builder(this, 2).create();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Objects.requireNonNull(alert.getWindow()).setType(Build.VERSION.SDK_INT >= 26 ? 2038 : 2002);
        }
       
        linearLayout1.addView(edittextvalue);
     
        alert.setView(linearLayout1);
    }

  
       

    
    private void CheckBox(final int featureNum, final String featureName) {
        final CheckBox checkBox = new CheckBox(this);
        checkBox.setText(featureName);
        checkBox.setTextColor(TEXT_COLOR_2);
        checkBox.setChecked(Preferences.loadPrefBoolean(featureName, featureNum));
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (checkBox.isChecked()) {
                    Preferences.changeFeatureBoolean(featureName, featureNum, isChecked);
                } else {
                    Preferences.changeFeatureBoolean(featureName, featureNum, isChecked);
                }
            }
        });
        patches.addView(checkBox);
    }

    private void Category(String text) {
        TextView textView = new TextView(this);
        textView.setBackgroundColor(Color.parseColor("#2F3D4C"));
        textView.setText(Html.fromHtml(text));
        textView.setGravity(Gravity.CENTER);
        textView.setTextSize(14.0f);
        textView.setTextColor(TEXT_COLOR_2);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(0, 5, 0, 5);
        patches.addView(textView);
    }

    
    //Credit: Octowolve
    //https://github.com/Octowolve/Hooking-Template-With-Mod-Menu/blob/27f68f4f7b4f8f40763aa2d2ebf9c85e7ae04fa5/app/src/main/java/com/dark/force/MenuService.java#L505
    public void startAnimation() {
        final int start = Color.parseColor("#dd00820d");
        final int end = Color.parseColor("#dd000282");

        final ArgbEvaluator evaluator = new ArgbEvaluator();
        gdAnimation.setCornerRadius(MENU_CORNER);
        gdAnimation.setOrientation(GradientDrawable.Orientation.TL_BR);
        final GradientDrawable gradient = gdAnimation;

        ValueAnimator animator = TimeAnimator.ofFloat(0.0f, 1.0f);
        animator.setDuration(10000);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setRepeatMode(ValueAnimator.REVERSE);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                Float fraction = valueAnimator.getAnimatedFraction();
                int newStrat = (int) evaluator.evaluate(fraction, start, end);
                int newEnd = (int) evaluator.evaluate(fraction, end, start);
                int[] newArray = {newStrat, newEnd};
                gradient.setColors(newArray);
            }
        });

        animator.start();
    }

    //Override our Start Command so the Service doesnt try to recreate itself when the App is closed
    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }

    public boolean isViewCollapsed() {
        return rootFrame == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    //For our image a little converter
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    //Check if we are still in the game. If now our menu and menu button will dissapear
    private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    //Destroy our View
    public void onDestroy() {
        super.onDestroy();
        if (rootFrame != null) {
            mWindowManager.removeView(rootFrame);
        }
        stopSelf();
    }

    //Same as above so it wont crash in the background and therefore use alot of Battery life
    public void onTaskRemoved(Intent intent) {
        super.onTaskRemoved(intent);
        stopSelf();
    }

    public void Thread() {
        if (rootFrame == null) {
            return;
        }
        if (isNotInGame()) {
            rootFrame.setVisibility(View.INVISIBLE);
        } else {
            rootFrame.setVisibility(View.VISIBLE);
        }
    }

    public class EditTextValue {
        private int val;

        public void setValue(int i) {
            val = i;
        }

        public int getValue() {
            return val;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
