
bool titleValid = false, headingValid = false, iconValid = false;

void *antiLeech(void *) {
    sleep(15);
    if (!titleValid || !headingValid || !iconValid) {
        //Bad function to make it crash
        int *p = 0;
        *p = 0;
    }
    return NULL;
}

extern "C" {
JNIEXPORT jstring
JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Title(JNIEnv *env, jobject thiz) {
    titleValid = true;

    //Html is supported
    return env->NewStringUTF(OBFUSCATE("<b>ONTO</b>"));
	//return env->NewStringUTF(OBFUSCATE("Put your website or notes here"));
}

JNIEXPORT jstring
JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Heading(JNIEnv *env, jobject thiz) {
    headingValid = true;

   // It will autoscroll if the text is too long
   // Html is supported
    return env->NewStringUTF(OBFUSCATE("<b><marquee><p style=\"font-size:30\">"
                                       "<p style=\"color:green;\">Modded by LGL</p> | "
                                       "https://github.com/LGLTeam | Lorem Ipsum is simply dummy text of the printing and typesetting</p>"
                                       "</marquee></b>"));
    return env->NewStringUTF(OBFUSCATE("Put your website or notes here"));
}

JNIEXPORT jstring
JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Icon(JNIEnv *env, jobject thiz) {
    iconValid = true;

    //Use https://www.base64encode.org/ to encode your image to base64
    return env->NewStringUTF(
            OBFUSCATE("iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAAAecSURBVHic7Z3tdds2FIZf9PR/2QnKTFBlgjITxJ0gygROJ7A6QbyBlQnsTCB1AksTiJlAygRvf1wyYkkQAAmAkFQ+5+jYlvFxeQFcABcfBGZmZmZmZmZmZmZm/m+o1AKYIJkB+B3AAkBe/UT1e94KXlYfANhVv+8A7JVSp5hy+nBxBUDyPYCi+iyMgd3ZAdgC2CqlvgZK83YgWZB8InlkfI5VXkXq504OyQ8kDxMovY8DyQ+p9TApJDOSD4kV3+ZAkSlLrZ+okLzjZSm+zYHkXWo9BYdkTvI5rW4H8UwyT623IFBq/RSda2iOvPbWQPJzai0G4HNMHUWZB1A6sw3CjeN92APQTcT+GJDGDsC7GBO64AWQUPnfIZOtetK1symskrWoPncAfjMEj1YIwSC54LT2/kRyzUC2mtJfbQ35HUleQqvuQhnfT6X8HcklI43bq7RPPXkfY+U7GoryXyMrva7tk9RASmvuK4TXUIUQpA8g+Yp4Nv87gEcAj2Psb1Vgv1R/5gAyiD0HLJ5Sir9o0/PvnVLq7VB5gkPyMWKNXw2taSTfU4a/G8d8DjS4IWh+vscwWhwJpdOKwUufQjQyZBSnnu9M+0hyqUk/t8RLM1mrBAvd6ZZ0dBNX+X+OIEMn/0quPo5M4bZgeN+Ok7mhrB3E9Cu9avI0DU1J8jmOlvuVENL0lHQY2VBGJZuA+faiyfvFIVoRRdkaYTKGcynvaKn1FFPzFCg/JzQy2FoAKToZPDT9aWgEAJ/QXRAfwxel1MIyDHwA8ApgGSA/V76NjJdjCjkZptMzCkoxN7Endn2sNfK4coil91qQZYAHXFryuA+Qhw9FS56h/Z3x+XwL4OD5cL3CUfqW1KtmW41c64FpxGkFlOGfD2uL8lOZnJoTW6Mxjp/rFDEKYGhNaLIzpDu1C7uPZcBnXscoAB8l5T1pTunCNtHx6VAqxliOoZXvM/FaGdJNbXZI/agnhEl08hG5zgMKx3BtaldyB0qtS7269FEptdR8/wR/2QrP+Gc8asOqJz2bhzE2O/a4Pxhu1t3xKY1VfuYhRN6Tpk+H7sOJZpP4FDg//1Uzjh9+mkY+Qzte22K5DePiDqWSbTzS76Ow6delDxhrC7UFQGn6Q2vGQilVAPgb0q+48B3AFwB/KqUypdRK53eidJYHhLTZZ6y6+9khkXxk5mXP92Oa5T3JF6XUCsCqUlqB7gNuIZuwtkqp3hYI/FjvfUAcxdfk3ilwfNN/6UlvrEnTLhkOfJZ6+XIzUoahbH3krYX2sb2d2k7/EdCGA6b6lAnVPdP4mawFYN2WQnEu5a4P3OKjUmqtSbOEeRugCyectyG2qfuZwjMPX0ql1BtTAJcC6KwQDUC7d4ZiSp480r0alFJGHY9ZERvCgppxd9Uq9pHzvgpit4Cat+1RCWWStsN519pNkroF1GzYmvorpUqIjXYd198kLgUwdpG6SQbgia1RUdUqCtxuIVh151IApb8cAGRkctC0hF31v1vsE0pbgKlMUE0GMUf/8ZU3zNGXieVJjksBGKf0I8gAPLN1+E0pdap8838Fzi8lVt1NaYLafKLMavPml0qpRwBvcRv9QmkLkKIFNCkAvLLl46n6hRzX3y9YdecyD8gAhF1k1vMCcV38cBlXeW8hdwZdI7/aTvU4HVGiLK5MoYQTxH+/beSdQdaVd/Wnx6+fQY6aFgAu4QaUvVIqzJo34x1D6uPBU96MsgKWEqfjSy4LMoCYgfvRGhnOG5JZu6bzfIVZjrOHtoR4Hf+pw1XxVhR38AvSuDu2QVNj/5HNkLzQcNyHspvBxIHi+88bcUzHTWMR/jQ94+5k0J4NY+s2K7qblSPJ+0a8ELu6h7COUQC+m3P76OxWqPI6VP8vGt8P3aH31Ihraz0hKRADmk8LDqVT6ymdZ/uKm6VnJbir4n7ylNeVcohOh/qCVgPD97GHbDXZ1l9QnHSvkCNQTXLPvGqXR8wJZZNV1NTp3wrW7Joc061ad41wY83gooofm3KoPsd4Q9cj4tR8VUotW7PdJYBn9O8XKj3yq8k4zWHq+FcXUOz0mFZQslvzbYcz2vOAUXa8iht7JNR5vpiFMOa8QKFJx7bretUK73JgupMGw55t7qPzfFHhMGV0OkDaa2TZCj/mNM0j4228baLdBRgVyg431xlme2QDmpWiOzA31IQ8c5qrkU9Mdcco3U1RoYlreqC7VtgpTMhY0t4tSjdPaaGJp6Ok5uSKYx4pSHthUw3t0/xCE6fpWyqpMVNVuKn9OK5MNbGzQzERpkLoU25uSbfgZRxjbWO95WVyKIXQ1ykPPr7P9HdG9HHipSm/hmbfu7YVaNLIOd0BiqF0RmcXB83m6IEas0NR+gemv6zDRBSzE/Py7i3MC/nb6mcRQ4bA7AEUF31vtA5e7vBxCJcx1BwLZbI29ZpsCDoTwquFYuPHONJSYdwccLVQWkPIZc3QaDcH3BQ8b5q6pIIoKWsNlzm+jwXFzZCyIErGvGTvWqC4HNacprOu30NQpH5u4DJf5llvsC0QbkPwHueXeU6/eGLg4gqgCcUmL6B/nW37pP036F9na32Zz8zMzMzMzMzMzMzMzJT8C+VjiIsbEtgSAAAAAElFTkSuQmCC"));
			}

JNIEXPORT jstring
JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_IconWebViewData(JNIEnv *env, jobject thiz) {
    iconValid = true;
    //WebView support GIF animation. Upload your image or GIF on imgur.com or other sites

    // From internet (Requires android.permission.INTERNET)
    // return env->NewStringUTF(OBFUSCATE_KEY("https://i.imgur.com/SujJ85j.gif", 'd'));

    // From assets folder: (Requires android.permission.INTERNET)
    // return env->NewStringUTF(OBFUSCATE_KEY("file:///android_asset/example.gif", 'r');

    // Base64 html:
    // return env->NewStringUTF("data:image/png;base64, <encoded base64 here>");

    // To disable it, return NULL. It will use normal image above:
    // return NULL

    //return env->NewStringUTF(OBFUSCATE_KEY("https://i.imgur.com/SujJ85j.gif", 'u'));
    return NULL;
}


JNIEXPORT jobjectArray
JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_getFeatureList(JNIEnv *env, jobject activityObject) {
    jobjectArray ret;
    // Note: Do not translate the first text

    // Usage:
    // Category_(text)
    // Toggle_(feature name)
    // SeekBar_(feature name)_(min value)_(max value)
    // Spinner_(feature name)_(Items e.g. item1,item2,item3)
    // Button_(feature name)
    // ButtonLink_(feature name)_(URL/Link here)
    // ButtonOnOff_(feature name)
    // InputValue_(feature name)
    // CheckBox_(feature name)
    // RadioButton_(feature name)_(Items e.g. radio1,radio2,radio3)
    // RichTextView_(Text with limited HTML support)
    // RichWebView_(Full HTML support)

    // Learn more about HTML https://www.w3schools.com/

    const char *features[] = {
         //  OBFUSCATE("Category_The Category"),
       //     OBFUSCATE("Toggle_The toggle"),
           // OBFUSCATE("SeekBar_The slider_1_100"),
        //    OBFUSCATE("SeekBar_Kittymemory slider example_0_5"),
          //  OBFUSCATE("Spinner_The spinner_Items 1,Items 2,Items 3"),
           // OBFUSCATE("Button_The button"),
          //  OBFUSCATE("ButtonLink_The button with link_https://www.youtube.com/"),
           // OBFUSCATE("ButtonOnOff_The On/Off button"),
          //  OBFUSCATE("CheckBox_The Check Box"),
           // OBFUSCATE("InputValue_The input number"),
           // OBFUSCATE("RadioButton_Radio buttons_OFF,Mod 1,Mod 2,Mod 3"),
           // OBFUSCATE(
                  //  "RichTextView_This is text view, not fully HTML."
                  //  "<b>Bold</b> <i>italic</i> <u>underline</u>"
                   // "<br />New line <font color='red'>Support colors</font>"),
            //OBFUSCATE(
                   // "RichWebView_<html><head><style>body{color: white;}</style></head><body>"
                  //  "This is WebView, with REAL HTML support!"
                  //  "<div style=\"background-color: darkblue; text-align: center;\">Support CSS</div>"
                  //  "<marquee style=\"color: green; font-weight:bold;\" direction=\"left\" scrollamount=\"5\" behavior=\"scroll\">This is <u>scrollable</u> text</marquee>"
                  //  "</body></html>")
    };

    int Total_Feature = (sizeof features /
                         sizeof features[0]); //Now you dont have to manually update the number everytime;
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    pthread_t ptid;
    pthread_create(&ptid, NULL, antiLeech, NULL);

    return (ret);
}
}
