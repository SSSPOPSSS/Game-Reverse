#ifndef LGL_IL2CPP_MENU_TOAST_H
#define LGL_IL2CPP_MENU_TOAST_H

extern "C" {
JNIEXPORT void JNICALL
Java_uk_lgl_NativeToast_Toast(JNIEnv *env, jclass obj, jobject context, jint numOfMessage) {
    if (numOfMessage == 0){
        MakeToast(env, context, OBFUSCATE("欢迎使用"), Toast::LENGTH_LONG);
    }
    if (numOfMessage == 1){
        MakeToast(env, context, OBFUSCATE("绘制开关已开启"), Toast::LENGTH_LONG);
    }
    if (numOfMessage == 2){
        MakeToast(env, context, OBFUSCATE("人物射线已开启"), Toast::LENGTH_LONG);
    }
	if (numOfMessage == 3){
        MakeToast(env, context, OBFUSCATE("人物骨骼已开启"), Toast::LENGTH_LONG);
    }
	if (numOfMessage == 10){
        MakeToast(env, context, OBFUSCATE("菜单已最小化"), Toast::LENGTH_LONG);
    }
	if (numOfMessage == 4){
        MakeToast(env, context, OBFUSCATE("人物血量已开启"), Toast::LENGTH_LONG);
    }
	if (numOfMessage == 11){
        MakeToast(env, context, OBFUSCATE("图标已隐藏，请记住图标位置，点击可显示图标"), Toast::LENGTH_LONG);
    }
	if (numOfMessage == 5){
        MakeToast(env, context, OBFUSCATE("人物血量已开启"), Toast::LENGTH_LONG);
    }
	if (numOfMessage == 6){
        MakeToast(env, context, OBFUSCATE("人物方框已开启"), Toast::LENGTH_LONG);
    }
	if (numOfMessage == 7){
        MakeToast(env, context, OBFUSCATE("附近车辆已开启"), Toast::LENGTH_LONG);
    }
	if (numOfMessage == 8){
        MakeToast(env, context, OBFUSCATE("附近资源已开启"), Toast::LENGTH_LONG);
    }
}
}

#endif //LGL_IL2CPP_MENU_TOAST_H
