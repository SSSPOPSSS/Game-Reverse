package Falcon.ui;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import static android.graphics.Typeface.BOLD;
import android.os.IBinder;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.view.SurfaceHolder;
import java.io.File;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import static Falcon.ui.StaticActivity.cacheDir;
import android.graphics.Canvas;
import android.annotation.SuppressLint;
import android.view.Display;
import android.graphics.Point;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TableRow;
import android.content.res.AssetManager;
import android.content.SharedPreferences;
import java.io.DataOutputStream;
import java.io.IOException;
import android.widget.EditText;

public class FloatingModMenuService extends Service {

    public View mFloatingView;
    public TextView textView;
    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    public LinearLayout mExpanded;
    private RelativeLayout mRootContainer;
    private RelativeLayout mRootContaine;
    public WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    private LinearLayout patches;
    private FrameLayout rootFrame;
    private ImageView startimage;
    private LinearLayout view1;
    private LinearLayout view2;
    SharedPreferences configPrefs;
    
    private static boolean ks,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10,k11,k12,k13,k14,k15= false;

    public static int py1=100;//自瞄范围初始化
    public static int py=0;//自瞄范围初始化
    public static int pY=0;//偏框修复
    public static int X1 = 0;//左右偏移

    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }
    
    private void Game()
    {
		
		AddCheckBox("自瞄",2001);
        AddCheckBox("无后",2002);
		AddCheckBox("防抖",2003);
		AddCheckBox("聚点",2004);
		AddCheckBox("除草",2005);
		AddCheckBox("范围",2006);
		AddCheckBox("黑天",2007);
		AddCheckBox("视角",2008);
		AddCheckBox("瞬击",2009);
		AddCheckBox("跳远",2010);
    }
    
    @Override
    public void onCreate() {
        super.onCreate();
        initFloating();
		Game();
    }
    
 
public static void RunShell(String shell) {
        String s = shell;
        try {
            Runtime.getRuntime().exec(s, null, null);//执行
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    

    public String LJJQ()
    {
        String sb = "" + getFilesDir();
        String str = sb.substring(0, sb.indexOf("files"));
        return str + "cache/";
    }
   
    void ASeekbar(String seek) {
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(convertSizeToDp(15.0f), convertSizeToDp(5.0f), convertSizeToDp(15.0f), convertSizeToDp(5.0f));
        if(seek.equals("自瞄"))
        {
            final TextView textVe = new TextView(this);
            textVe.setTextColor(Color.parseColor("#FFFFFF"));
            textVe.setTypeface((Typeface) null, 1);
            textVe.setPadding(convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f));
            textVe.setTextSize(1, (float) 12);
            textVe.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
            seekBar.setProgress(50);
            textVe.setText("Fov: 100");
            seekBar.setProgress(0);
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        py = progress;
                        py1 = 100 + py * 4;  
                        textVe.setText("Fov: " + py1);
                    }
                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }
                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            });
            this.patches.addView(textVe);
         }
         
        if(seek.equals("偏框"))
        {
            final TextView textVie = new TextView(this);
            textVie.setTextColor(Color.parseColor("#FFFFFF"));
            textVie.setTypeface((Typeface) null, 1);
            textVie.setPadding(convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f));
            textVie.setTextSize(1, (float) 12);
            textVie.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
            seekBar.setProgress(50);
            textVie.setText("偏移: 0");
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        if(progress == 50) //当等于则为零
                        {
                            X1 = 0;
                            textVie.setText("偏移: " + X1);
                        }
                        if(progress < 50) //小于一半则为负数
                        {
                            X1 = -(50 - progress) * 10;
                            textVie.setText("偏移: " + X1);
                        }
                        if(progress > 50) //大于一半则为正数
                        {
                            X1 = (progress - 50) * 10;
                            textVie.setText("偏移: " + X1);
                        }
                    }
                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }
                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                    }
                });
            this.patches.addView(textVie);
        }
        
        if(seek.equals("右偏移"))
        {
            final TextView textVie = new TextView(this);
            textVie.setTextColor(Color.parseColor("#FFFFFF"));
            textVie.setTypeface((Typeface) null, 1);
            textVie.setPadding(convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f));
            textVie.setTextSize(1, (float) 12);
            textVie.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
            seekBar.setProgress(50);
            textVie.setText("偏移: 0");
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        if(progress == 50) //当等于则为零
                        {
                            X1 = 0;
                            textVie.setText("偏移: " + X1);
                        }
                        if(progress < 50) //小于一半则为负数
                        {
                            X1 = -(50 - progress);
                            textVie.setText("偏移: " + X1 * 10);
                        }
                        if(progress > 50) //大于一半则为正数
                        {
                            X1 = (progress - 50);
                            textVie.setText("偏移: " + X1 * 10);
                        }
                    }
                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }
                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                    }
                });
            this.patches.addView(textVie);
        }
        
        this.patches.addView(seekBar);
    }
    
    void AddSeekbar(String str, String str2, String str3) {
        String str4 = str2;
        String str5 = str3;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout.setOrientation(0);
        TextView textView = new TextView(this);
        textView.setText(str + ":");
        textView.setTextSize(1, 12.5f);
        textView.setPadding(convertSizeToDp(10.0f), convertSizeToDp(5.0f), convertSizeToDp(10.0f), convertSizeToDp(5.0f));
        textView.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        textView.setGravity(3);
        textView.setTextColor(Color.parseColor("#FFFFFF"));
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(convertSizeToDp(15.0f), convertSizeToDp(5.0f), convertSizeToDp(15.0f), convertSizeToDp(5.0f));
        TextView textView2 = new TextView(this);
        textView2.setText(str4 + str5);
        textView2.setGravity(5);
        textView2.setTextSize(1, 12.5f);
        textView2.setLayoutParams(new RelativeLayout.LayoutParams(-1, -2));
        textView2.setPadding(convertSizeToDp(15.0f), convertSizeToDp(5.0f), convertSizeToDp(15.0f), convertSizeToDp(5.0f));
        textView2.setTextColor(Color.parseColor("#FFFFFF"));
        SeekBar seekBar2 = seekBar;       
        linearLayout.addView(textView);
        linearLayout.addView(textView2);
        this.patches.addView(linearLayout);
        this.patches.addView(seekBar2);
    }
    
    void AddRadioButton(String[] strArr) {
        RadioGroup radioGroup = new RadioGroup(this);
        RadioButton[] radioButtonArr = new RadioButton[strArr.length];
        radioGroup.setOrientation(1);
    
        for (int i2 = 0; i2 < strArr.length; i2++) {
            radioButtonArr[i2] = new RadioButton(this);
            radioButtonArr[i2].setTextColor(Color.parseColor("#FFFFFF"));
            radioButtonArr[i2].setPadding(convertSizeToDp(0.0f), convertSizeToDp(5.0f), convertSizeToDp(10.0f), convertSizeToDp(5.0f));
            radioButtonArr[i2].setText(strArr[i2]);
            radioButtonArr[i2].setTextSize(1, 12.5f);
            radioButtonArr[i2].setId(i2);
            radioButtonArr[i2].setGravity(5);
            radioGroup.addView(radioButtonArr[i2]);
        }
        radioGroup.setLayoutParams(new RelativeLayout.LayoutParams(-1, -2));
        this.patches.addView(radioGroup);
    }
    
    
    void AddText(String str, int i, int i2, String str2) {
        TextView textVie = new TextView(this);
        textVie.setText(str);
        textVie.setTextColor(Color.parseColor(str2));
        textVie.setTypeface((Typeface) null, i2);
        textVie.setPadding(convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f));
        textVie.setTextSize(1, (float) i);
        textVie.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        this.patches.addView(textVie);
    }
    
    
    
    
    private void initFloating() {
        rootFrame = new FrameLayout(getBaseContext());
        mRootContainer = new RelativeLayout(getBaseContext()); 
        mRootContaine = new RelativeLayout(getBaseContext()); 
        mCollapsed = new RelativeLayout(getBaseContext()); 
        mExpanded = new LinearLayout(getBaseContext()); 
        view1 = new LinearLayout(getBaseContext());
        patches = new LinearLayout(getBaseContext());
        view2 = new LinearLayout(getBaseContext());
        mButtonPanel = new LinearLayout(getBaseContext()); 

        RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-2, -1));
        relativeLayout.setPadding(3, 0, 3, 3);
        relativeLayout.setVerticalGravity(16); 

        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 17;

        
        TextView textView = new TextView(getBaseContext());
        textView.setText("Falcon");
        textView.setTextColor(Color.parseColor("#FFFFFF"));
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setTextSize(20.0f);
        textView.setPadding(10, 10, 10, 5);
        textView.setLayoutParams(layoutParams2);
        textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mCollapsed.setVisibility(View.VISIBLE);
                    mExpanded.setVisibility(View.GONE);
                }
            });
      
        TextView textView2 = new TextView(getBaseContext());
        textView2.setText("");
        textView2.setTextColor(Color.parseColor("#FFFFFF"));
        textView2.setTypeface(Typeface.DEFAULT_BOLD);
        textView2.setTextSize(10.0f);
        textView2.setPadding(10, 5, 10, 10);
        

        this.mExpanded.addView(textView);
        this.mExpanded.addView(textView2);

        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mRootContaine.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
        startimage = new ImageView(getBaseContext());
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension = (int) TypedValue.applyDimension(1, 50, getResources().getDisplayMetrics());
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode = Base64.decode("iVBORw0KGgoAAAANSUhEUgAAAlgAAAJYCAYAAAC+ZpjcAAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAACAASURBVHic7N15fKRXdeD937lPrdr31ta720vbjZc2ZgsMDGEJiVmS2FlwCEvAEMADhAQySYgmbyYhITDEwNiNkzhh3sxiMu+8IQnZSDCBhM023u12u93tbrWk1r5LtTzPmT/uU5JssF3qRVVSne/HZanV6tJVSarn6NxzzwFjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYY4wxxhhjjDHGGGOMMcYYUwap9AKMMVuLgjCA8JvAf8Ld3YNkh5H9bchMO3XTi7SklbqEks4XybgUKS2S1oC0E1JOSRcdaReSVkhL4FKofx0IJCInATkNozyOZVXyIuQkJCdCLhJyYUTeJcmFefJSIEeGpeICc6k6ZnpaKd49hR4cRtmP8jDKACqglX7sjDFbhwVYxphnpSDcgWMKdzxFEJ0mXddMaxjQ4pQGoA6oQ6iPhCantCi0CK5ZhJZItRVcs6DN4siokgACwMU3AZyCE43fJggavw3xf15930ggilAtvQ5EKBFChKLIytsUIVL/fkWFvMCcqM5EyrRzMqVEMwLTqkxHMIOyEDgWwogljVjIKDPFDJOnCiwcbKVIJxFfI5IBokp8PYwxm4MFWMbUMAXhOtzdP4xrzuGaA5IL0FCfpqEQ0qTQ7IRehJ2K2yPoTlR6EBqADJASSEaQEpUEgqv053SWFCVUtOCEvCoFIKewiJNJp/pkpBwTjY6JcEKEqVyOuYQwm69jjidZ3tVDSCvRf3oYHbAgzJiaZQGWMTXmyM2ks800FPM0paBflX3OuQtVdR/qtiPapEqDCPUC9YoksOeK76dEii4LzCPMC8yHyJhTPYJwOCpGj7uIowmYGoP5/e9lwbYhjakd9qRpzBZ15GbSWUdDUWlKJdlOgkuI3CUiugelDye9GtGAEEDpJqVtOLN+CqigoUIIhCh50DHglCJPikRHNOQhV+TxQJgYg/n9YyzadqMxW489kRqzyT00QKqnh+x8nvogRXek7BLndgF7negekD0obQhZlDQiAfazv9HU3zQPLAvMgZ5S5HGNOOqC6BgRx3M5TiSEWc2z2P8hli3jZczmZU+yxmwiccF58vERMtkM3QHsBZ6nuAOIXATaDTSg1CO2tbcJqOC3GlEWEKZQPaoiD4lG9xFwmCLHwwUW+vvJy/WElV6wMaY89uRrTBUbGMD95r/DjT1MR+jYobCPwB1E5CDoTpRWROrxW3xm61DQHDAjMKrK/Tju1ih6IHIcZ5ZT/bPkbGvRmOplAZYxVebox2mua6Mfxy6B54XqLhd0L7ANpE0gpaxs89nP8NanoBFQBOZRPY1wEpWHIqJ7A8fhhDDYcZJRGaBY6cUaYzx7cjamsuTox2lKt7HNKfsjcdcIeimwG5FeUepESMYn+YwpiUALKDlgEvQ4Io9FUXSPRnwvHXGic4xxC7iMqRwLsIzZYEOHqCvmaZE0+wQOOnFXifI8FXpRGhBJYT+bZn1KWa5FYFIjPSzIPeKiu0Pl/kKS0V31zFkNlzEbx57EjTnPdAA32EQ62cTeMAquUfQaJ3IQ1e0IzSBp7GfRnGOiFBVdUBgDfVBUvi0u+lZRuL+/iRkLtow5v+xJ3Zjz4KsDJPZ3sSNMcoUo16jIC4DdqtIhkPa9pwTsZ9CcXxr/pwgFQacjOC3I9yKNvhXA3ZNDPHLpAPOVXqgxW409uRtzjpz8FFka2ZdUro7UvQKnl4H0oTTGdVTWxNNUAwUtAsuojgLHBPk6Ev0LAQ/1vJ2xSi/QmK3AnuyNOQsjn6A+qmOHpHihivthIi4XoV99Hypr6GmqnxKJ6LLChKoeRuRfky76ikYc+do/MH79F20r0ZgzYU/+xqzTkZtJNyTpCR2vCZx7ZQRXCnSDZLF+VGYTE4gi1YLAjIo8CvpvEkV/kyhyb6eN9DFmXSzAMqYMCjL4R+wNlNdpJK/AcVCQdpQMglg9ldlC/HgeVVWhCDqH8jjI1zWK/s6N8M3eARYrvEZjqp5dEIx5BjqAG+/lgqK4V6nqDyNyAOhCydr2n6khiqoqFESYEvRYFMnXCaN/DBr4ZvdbWKj0Ao2pRnaBMOZphv+ETgpco4F7AxEvBfoFyahgQZWpdX5otWpBhElVfUBVvyTwT9/4CkesXsuYVXaxMAZfV5UJ2B4k3esRfaOqXOqQJguqjHkWSgSaQzgBfB2iL2Qi7m+7kZlKL82YSrMLh6lpDw2QaunmNRLIW1R5kSBdQIBI6WfDfkaMeXYal21FwKKIPqyh/lVU4Nb+9zFR4bUZUzF28TA1547rCF76cq7SpPsZRV8jIjsFMnGfKrCfC2POlMYvCsA06DdA/8/CEl/adxOzFV2ZMRvMLiSmJugAbqiTPk3ySkHeICIvROmwYnVjzisFnVf0caf6/4vwD4U57tv+IZYqvTBjzje7sJgtTQ+RHCyyM0jyenBvBy6wYcrGbDhFVRHGUP5BwuhPFh3f+2/DzA1Yby2zRdlFxmxJdx0i2eu4ANyHVPkRJ9Kt1gTUmGqg4rNa9wjuswkX/n3nO5ir9KKMOdcswDJbytTttOQiXhaG7qdFeIVtAxpTlRRUgQXQe1XlS8tR9JdTwvGrb6RQ6cUZcy7YRcdsejpAarCbnc65V4G+SUSuEqTZMlbGbAqK6jKix1H5u5DoL/PKvXut1YPZ5CzAMpuW3k5mtMiFIbwO3PWqXCwiacA95z82xlQbBQ1RTovwDxD9RZ3wraZBpm0GotmMLMAym87JT5FNNnJ5iLtB4EdQtiOSrPS6jDHnjKI6rSLfEwn/OFD+qeudjMpKGwhjqp8FWGbTODZAJt3D1Rq4t4jyapReRBLY97ExW5GCqsCcit4TRvo/UsKXtr2T05VemDHlsAuTqXpHbqapLsM14K4X4ZVxxsoCK2NqhkYCc4p+TyK9Qwt8ued9nLCMlqlmdoEyVWvkE9TnGzmYCNxPq/I6wTJWxtQ2VZQ50O+I6H9fzvO3u36R0yIWaJnqYxcqU3WO3U4mucQVknBvFvgxoD8OrIwxBoFI0TnQ71LUL0iBv+t+P+MWaJlqYgGWqRo6gBvt5gVR4H5O0deB9ABJEPs+NcY8nYJGCnOi+l1R/fN8yJd2/iJTlV6YMWABlqkCd72LZM9BDkjgbkD1daqyS2ycjTGmPCqqYSRMieq/aqT/0+X5556bGKv0wkxtswuYqRi9g+D0BJeEgbsB4SdQtltgZYw5QwoaoUwp+q+i+qdL8FVrWGoqxS5kZsMpyKnP0iYpflYkuAHVA4hkK70uY8wWoRRBhyL4MlF068wIj1w6QL7SyzK1xQIss6GO3Ew6m+FVTuS9qLwYaEBEsO9FY8w5papKAdFjIvJnSYn+rPMdDFV6VaZ22EXNbAi9jmD4FbxYk+5tKK92QpdiLReMMeeVio+05hG9V3FfyEbhX7TZtqHZAHZxM+eVDuDGe7mggPs5hOtUsQJ2Y0wlhKCTqH6DSD/v5vh69y+zUOlFma3LLnLmvFCQ8UN05+EnxLm3qnJpPIjZvueMMZXiC+FhLIIvSRQd6h3mfhmgWOmFma3HLnbmnFNww7fxRjT4IOhBRDLY95oxppooIegpXPTn6UU+3n4Ts5Vektla7KJnzhkFGfk8+yPchxGudUqzigTY95kxpvqov2ke9CFFP9l7ii9aNsucK3bhM+fEk/+V1lSSn47UvUuE/SBJ7PvLGFP9FEBVJwT+0oXRp7e9h4dskLQ5W3YBNGdFB0gM9XNAVH5dkFcr0lDpNRljzJkQNIyUYwHR7yaX+QvbNjRnwwIsc8aGDtEROfcuBx8A6cC+n4wxm5+qakGQryQT4W989W+57/ovElZ6UWbzsQuiWbe7DpHsD3htqPJhVK6x04HGmC0mHrujJwX5AsvRZ222oVkvuyiasukA7nQfOyPcewV+RqEbxFV6XcYYc54o6CKq/yain5Zpvma9s0y5LMAyZTl2Oy2ZPK+KXPBBUZ6PkKj0mowxZoNEoEORRv9NI27vb+MJud62Dc2zswDLPKuvDpC4ZCeXREX3EZRrEWmq9JqMMaYyNI/yIMinc8nwr3a/jelKr8hULwuwzDMa+z0a863BdUj0K6KyB7HZgcaYWqeRwqzAHZFGn+x7F0espYP5Qexiab6PKnLyVi5NBu5GhetF6FCrtTLGmDV0SVS/FYr+V3eKL/cOsFjpFZnqYgGWeYr7PkF9RyP/Xpx8CJEXgp0QNMaYH0xDYFDhdomi23vexUkRy2YZzy6cBvBjboY+Rz9J9wsIbxOkFwgqvS5jjKlyCrqkKv8sUfiJoXv45tWfp1DpRZnKswDLoHcQnJriZSLyUUFeipABse8NY4wpj6KqIvqEop/LRNzediMzlV6UqSy7iNa4oUN0ROreEgT6NpCL1M8QNMYYs24aAVPA30YafbJviPtlgKjSqzKVYQFWjdIBEic7udIl3fuc8DpU2hCskN0YY86OKloQ5H4I/3BhiS/ts5mGNckCrBo0+jkaio43SBD8B0WvsPYLxhhzzqmqjgH/SzT6g94bOVHpBZmNZRfVGjN1Oy1LRffLqL4NZBti7ReMMeY8UVXNO9FvoPqrPe/iLqxnVs2wAKtG6ABuZBtXR0n5NYnkFYg0YF9/Y4w531RUQ3Uci6LoU33KF+RG65lVC+wCWwP0ZtJDWX4cdR8W4QDYlqAxxmwgRVHQMZT/EUbRH2x/D6cqvShzftlFdoubup2WXNG9O4L3otJrhezGGFMxCrooov/kRD/WdZIH7JTh1mUB1hY2ejvdhbz7tAg/hkgd9vU2xphK81uGwhE0+rWeIf7SgqytyS64W9TQ53kNIr+NyuV2StAYY6qK3zJUHcXxx+Fc9KntH2Ky0osy55ZddLeYIzeTbshyk+Lei8p2BMG+zsYYU32UCHQe4e9zy9HHdr+fw9gpwy3DLrxbyNghevLiflUcP49KI/b1NcaYaqegBUHv1kgHeuCrcqPNMtwK7AK8Ncjg57ncSfCHqL4EERvSbIwxm4uiOqIa/efeHH8kN5Gr9ILM2bEAa5NTkKHbeL1E7ndwXATisK+rMcZsRorqNPCn4Xz021aXtbnZhXgT05tJD6fdz6vjPwqyHawFgzHGbHIKuqgRfx246Fe738mxSi/InBkLsDapwc/S7lK8B9z7EOnCvpbGGLOFaF5U/zFS/di/foX7rv8iYaVXZNbHanU2oROfoTeRcb+uIu8XkRYsuDLGmC1GAkT24tyVF+zVI8/PcPKLD9sJw83ELsybzNjnubAgbgDlDYhksa+hMcZsXaoR6KOgH4ubkhYrvSRTHrs4bxJ6HcHIaziIym9FKv9ORNLY188YY7Y+H2QNovrJdD1/2n4Ds5VeknludoHeBI4NkMn28uoI9zGg1JndGGNM7VBUZ5HolkSeP+x6LyOVXpB5dhZgVblHf4/GllauC3EfFZG92ElBY4ypYbooyv/M5aLf3vV+O2FYzSzAqmITN9O0nOWDgrwbpCvucWWMMaZ2qaIFUf0XRG/qfSePVHpB5gezAKtKjdxCV5Rwvwa8GaQN+1oZY4wpUS2K6D2h0w/0vYNvic0wrDp20a5Cpz7HdhLuI+J4G9hJQWOMMT9QJER3a6S/3nMj/2hBVnWxPlhVZugQOyRwvyGOnwOpx4IrY4wxP5iAdCtcMf8GjjVexRN33mlBVrWwi3cVOXY73dmi+0QIPylIptLrMcYYU/0Ewkj1qHPyoe7B8G9lgKjSazKWwaoaJ2+hL6nyGRV5fRxcWfBrjDGmHCLQqvDC2UY3cu1BPfxnd1qQVWl2Ea8Cpw+xNxL3Oyq8HqyBqDHGmHVTFFX0KEQfG1b+99U3Uqj0omqZXcgr7Mlb2Z8I5OOi8tq4gah9TYwxxpwZJUL1uCK/O0z4ZxZkVY5dzCto5DZ2hyqfF+Tl1p3dGGPMOaFEgg4SycDkSPjnlw6Qr/SSapEFWBUycogDocitgjzfMlfGGGPOIQWNUB1F5OMLS9GhfTeRq/Siao1d1CvgxK1cHTj5rBM5qEiAfR2MMcacWwqqwCgafRzltt4bWaz0omqJjV7ZYEO3cTARyB+IuKstuDLGGHOeiB+vJttE3K84xy/ozaQrvahaYhf3DXTij7gsUPm84K7BWmQYY4zZGKrouET8bs9w9DmxmqwNYQHWBhm+hV1RIP+vE3mBZa6MMcZsLFVUJwjdfxxy4Z/a6cLzz7YIN8D4IS7WQG4VkedbcGWMMWbjiSDSroEOdEvwZj1EstIr2upsm+o8G/kMu4sJ+QRYnytjjDGVJCIiDYJeMat64tqrecw6vp8/FmCdR+O30FdIut8T5A2IJLHgyhhjTGUJIs0IV7U1cvSFGY5+8WEbEH0+2AX/PBn8LO2Sdp8R5Y2IzRY0xhhTTTRS1aMq+u6+U9xpA6LPPavBOg/GDtETpNzvO7jWgitjjDHVR5wge53IZ0718XIdsHjgXLMH9BwbO0RPwbmPqvBTitRjwZUxxphqJOKI3MUB8rtjfbxE7Xp1TlmAdQ5N/zmtRXEfEuGtWHBljDGm2glO1V0dIr//5C1cUenlbCUWAJwjQ4eoA/cfEd6PSFOl12OMMcaUTTVS9DuB6M92v5NjlV7OVmAZrHNgaIA6hHcj/AIijZVejzHGGLMuIs6JHAxVPj/8X9hV6eVsBRZgnSU9RFJ7eT0qH0DowrKCxhhjNiFFkoK8PKp3vzl8M52VXs9mZwHWWdAB3Kjj5SLu1xDpA7HgypgzpOpva19f780Yc5ZEEgI/FWX4pZN3kK30cjYzC7DOwmAfl4UafAyV/YjYY2nMOml8W/vnSFdflm5h9NTb2r/TNfejinVMNOZsiWQR9043xTsqvZTNzDIuZ+jUn7BdivKHID8Wd2k3xpRB8U88K8GQQgTomsBJSy8j/3c+PSUoCiI4QEQREZzgb87fr6x5HbEnOWPOkCrRYKT6wf4h/o81Il2/RKUXsBkNHaJDi+43EF4NFlwZ81xKgVQpywSKqhBG/s9hpBQjoRgqxZCV19dmrEq5KUERgSCAQJSEg0QAyYR/mXBC4OJAS0rvLyvBlm3kG1MWEaTXwW+f6tFJhTvFEsTrYk816zRxM025jPsowvtAGrDH0JhnpGuCqtKtFDQVoziYCiFXgOUCLOX9y8U8LOf92wtFCONsFqVsVQCpANJJyCShPu1fZlOQTUM64QOwhAPnhMApTlYDr9IPrQVbxjwrRTVSkW8RhTf13cg9lV7QZmJPL+ugh0ieFt4difstkGbs8TPm+zylUB1Q9dmpMFQKkQ+YcgXIx4HUQg5mF2FqQZmcF6YXlMkFZXYR5pd8wFXKdJUCrETgg6iGDLTUCy310N4ArQ1CRxM010MmAamEf79UfEsmhCBQgnhrcSXAkqe8MMasUqAI0T/ml/V9u95vPbLKZc8n6zD0ed4M7hOIdGOPnTEr1p7gW6mhWpOlyhVgqQCLOR9QzS/BXHwbm1PGZuH0NJyeUSbnhOlFZX4JCuGajxG/XPuDl0pAUx201ENHo9DVDNvbYVuLUJf2ma2GjA+4GtJQn4FMygddyQBEhEBAnGW1jHkWqmhO4H+ns9Evtt/AbKUXtBnYU0mZhm/h5Rq4WxC5CHvcjAHWZKtYDarCSCmEQqGo5Ip+2292EcbnYGQahqaUkSkYm1WmFnywtZCLtwfzkC/GGasy1yDitwIzSR88+aBKyKaU+owPtvrboa9V6G2D9kZozPr3T5eyWk4J3NOyWliwZcwaKqqzwK0yE/0/3b/MQqUXVO3s6aMMJ29lXxDIfwe5EiSo9HqMqQal4Cpak60qhMJyXlmKt/7ml2FmEUZnlBNjcGRYefSUD7aWC77+6nwKnA+4elphX49wUR/s6BA6m3zWqz7OcmVSvqbLB1t+GxKr1TLmKQSiCJ2SMPqdhTyf23cTuUqvqZrZKcLnMHwzneqC/4LqFYgFV8asrbGKVAkjIV9UcgWYW1Ym52F8Fk5PK0NTMDwFI9PK6WkYnYHpxY1baxjB7JLfmhyfVZ44DT2tSm+bz2r1tsK2ZqGtAZrrIJtWUgkhGWgcaAki/nO1IMvUOgUnKq0auA80pKPDCl+2k4XPzJ4ynoUOkBjqdf/ZCR9UJIE9XqbGlbollFonFEIlVxAWcsrMAozNwrHT8Niw8tiwD2gm532GqxqagAq+R1ZdGjob4cJe4eJ+2NXpA662RmjM+NOI6SQkg9WMlgVYxgD+ZKGq6HeCor6z+z08WOkFVSt7yngWpw7xPsT9loi0YI+VqXGl5p9+OxByBWUx5zNSp2fgxBgcHVEODyknxn22ailf6VU/M8EXv/e0+gBrzzbY1SX0tkJnM7TGhfHppPieW2samRpT4xS0gOrf5Ar6i7vfy0ilF1SN7KniGQwf4hXq3G0ge7DHydSwlXYLkVKMIF8UlvLK/DJML8DxUXh4UHloUDky5DNWuULls1XlcuJrsDqbYFcXXNInXNgr7O6CruZSRktIJlYL4a1DvDGA6rzArcvJ6Dd2v43lSi+n2lhN0Q9w+ja2hSK3Ce5SbF6jqVEr3de1tB3oC9NnF/1W4IlxeGRQuesJ+O5R5ZFBmJj32a3NRPGf20z8eU0vwsKyEik4ZHX0jpSalMpKFsuyWaamiSRVuDhV1OM/ejWP/NmdNk5nLQuwnubox2kO6tynReVVcVG7PYWa2rQyaFnJh8JCHmbm/Xbg4SH4xiPK392rPHgCTk36rNVmVwhhah6GpmBsGhYLfvROOlkavSO4uCu8syDLGBHIRirPa2/Ruz71JU5WekHVxAKsNfQOUkvwXkFuRCSDBVemRpWyVsUQckXfq2piDgYn4LEh+N4x5RuHlSfHfFZLN8t+YBlUfbA4Puu3OwFSSfxkNiBYGSYt1srBGEREaBHo/+i1fPcTf8VEpVdULewpIaYDuKFurpPAfQKkH3tsTI1aDa6U5YLvtj48DY+dUh486eutnhzzvayic7whIOK7s2eSq7MFkwlWTvKV5hkWQihEvjFpaWZhvnju674SAWxrht1dcOVu4Yrdwq5OaGvwJxFTSZ4ydseCLFO7dBn4AlH0a703Ml7p1VQD64MVG97OVRIFH0bp87+aGlNbSsXsK5mrgq9LGp+Fw6eUf3lYueuoPx0YncNIpnQyL5XwHdY7Gn339a5m/3pjxm/RBQG+RYT604mLOWVizvfbOj3j1zW75Nd+rlpCFEO//Tk85Uf6+ABKKEY+yKqPIJlQ0glZKda0IMvUJsmgep2Ie0IHok/KAMVKr6jSbIsQOPlHtAWRfArhhxCxoNPUJCVuwbCmmH1oCh4dgm8/Bt9+3I+6OReBi4ifBVif8W0Sdm+DS7YLl+8UnrfTcekO4dJ+4YJuYU+3ny/Y3wF97dDTAr1t0NMq9LYK3a1CT5vQ0wpdzUJ9Glz8zFbKxp0txT8ei3k/rFoRkgE4JyQC38bBOfyWoQVYplaJZBT2zzfo/Y1Xc+zOOzfNYeLzouaDidHP0VBU98sqvAIsuDK1qdTfqhDCUl6ZWYSRKXjwJHzrsYj7jvthzOdCKgHdzXHA1Aa9rT5b1dYgNNf7oCsbzxXMJP023dpGn6uDpH2WbTkeIj2/LMwtKRNzwugsnJyAwXHl+JjPwp1toFUI4cETfuzP+KyylHNc3KerW4MpH3RFsFIAb0yNEYEenPzOO/p0ZADur/SCKqmmA4q7DpHMKz/u0LeCa8DqrkwNWg2ufOPQqQU4Oe5rre5+QvneEzA6e3aF7MnA11O11EN/u2/oubMDetueOhcwlYR0QkgESiIoFZQLIhrv3CuKrBnT4zNupS3NXFFYzPls08i0L8o/ehqOnVbGZmFmCRaXz7yVRBj5wPOuJ6AQRYRRvDGoICiSEhKBz3hZJsvUJBEHXBGo/NLp26Jf2fZOTld6SZVS0wFWt3K1C9wHULqs7srUolJwlS8qi3nfOHRwAu4+qvzzg8rxUR+UnGlw5QTaG2HPNtizTehrF3qaoT0Oqpqyvlt6Ju2HLQdrgipXCqqkdGJPWfkdSP02XaSKRkKEEoYSD5yG9gaho0nZ3uEHPE/OCcPTyslxODaqPD585jMRFR9kzS9Dvhih6tY8PkomKSQT8Vgee1YxNUkCRN8UKQ8cuZnP1OpQ6JoNsE7fxrYQ9z5RuUzFmoma2rJS0L4mczW94LfVHjypfPMx5d7jZ37/gUA2Df1tcEm/cNkOYU+XD6waM/4EXjoJ6QQkEhC475/5t/Z3nlJx+eob/OfgRFAHqKABqAphpNSloCErtDUo3S1+C3F2SRibgeNjvkP7vceVybkz6zqv+NOVdx8F1AdZrjRKp14RJyScZbJMLZNGFfeL9enofuAfKr2aSqjJAOuuQyQjdW9V4bVIbT4GxpSCq6V4nuDxcfjOY8q3H4cjw2d+v41Z2NPlBynv2Qa7u0o1VtCQ8bVVqQQkgjhLFfeXKgUo8U7gcwYmK38fJ7ZK/9aJD26SgZJKCNmU0pCGhiw0Z6G1QehpVfb3Cw8P+g70gxO+xmq9ZhbhO4+DSEQq6dZ0fffbheKetlZjassORD46erve3/W22ptXWHOnCBVE3sirgF8VdX1Y9srUmLV9rpbyvuZqcALuO6587WHlgROwcAYJfSc+iDmwA156iXD1BcL+fmFHp5/z11wvNGQk3kLzGatAVsfOrPSSYn0BycoIm7XZr9I2o4Mg8Cf9UgmhLu2DvNZ6oaNJaG0Qsml/MnB20ddYrVe+6LcLE4Evyq9Li8/MBaVgS2xItKlR4oDuMJKG9/+4fvUP/7K2WjfUXPbm5CH2JFQ+gspeC67MVlGqAXqui/jqXEFdacVwctzPEvzmY8pjQz5gWK9sCrZ3wGU7hMt3wr5uobsFmuqE+oySDHzxd+CeFkCVAqr1f8hntPYxcPGfA/EBTxQJ6YSSTfltykwKmut8oX1fmy/sPzW5/kBrfA6+8aiSL0LClQrz/d+lk37L8OlrM6YmiGQcybAfQQAAIABJREFU+nMZ5Ws6wP8nA7Uzr7CmAqyxP6YxH7p3K7xIrN+V2UJKNUTPdP0uBWCRQhifuJtd8qcDHz2lfONR5cEnYekM5glmU3BJH1x9gXDVbmFHB7Q2QGNW4jYLvtO5e3pwtQFKGTEVCNSvwTnftyoRQDqhNGZ9i4i+Nt+1/SsPKEOT66vLUvWtIL77OLTU+cBtbU2ZJJUAC7JMTRJFmgndb450Rw8DD1d6QRulZrYIdQA33cCbQD4iQpM9zZmt5rmCF1WfmckVfXA1PAWPDMK3j8C9x/0213o1ZODKXfCSi/wYmb3boLPZnw7Mxn2hAleZ4GqtNQmzeGizX1ci4deYSUFdyr9MBkKosLC8/rqspbx/bBWoTwn1Gd+iIhGUTkbylPmFxtSQ9ghp+fC1+vef/Gu2wGj451YzWZyT3VyVFLlJVTqx5zezxTxXYKX4ETP5ojK/LIzPweFh+PqjEfce98Xa69VaD1fthRfuEy7b7juptzX4ovJUQnBOcVI9WZu1RfEiIAErawwC9Vt7ImRTPpP1Lw/DfSeUwjq2TFXhxLivb8vG9ViBKzVL9QX9DuwZyNQgCZzo61V5APj9Sq9mI9REBmvws7QHCfcxRF6FSLLS6zFmI622Y/BZmbEZeOI0fPMx5ZuH/Qy/9fS5EvE9rK7aDT90seOy7cL2eFuwPuOLyYM4WKnGAchPKYqntH3pa8TS8YDpupRf9ELOt3hYb13aUt5nC9NJ3y6iPr3ajuJMCvmN2RJEUiJy4a9cq9/5g7/iZKWXc75t+QBLD5GcT7h3C7wLkfpKr8eYjaQKqkoxFJbyMDEPjw3DXUcj/vWwnzW43iai29vhBfuEl1zkeN5OPxewtd5na1KJ1UzNZgggVk8wqg+y4mxTOumDxYaMsJhXRqfXN2onUp8VXMj71hAtDb4eLVmFmT1jNpCgNCFc+pHX8jef+DLzlV7Q+bTVtwhlNMnzKer7EWmq9GKM2UilE4NhKOSKyvySnyf4wAnlO4/704PrDa5a6uGqPfCii4QLe/zJu8YsZOJ6q1JWaFMFDvGaAwFJxGN51tRpLeaE6QXf1X49NVnLBXh8GHpblY6m1RFATgSX9Ccbjak5IqJwMJ+Qj+ih6Ffkxq1bj7WlM1gjt9AViXzSIVcgsqU/V2OeTvEBVj4OrkZm4JFT8LWHlAdPrH8eX0cjPP8CePHFjkv6oLcVmutWi9k369bXypqlVABf6p/lC9QzSV+snivCxNz6MlnF0AdloQqNWT/MOllqsupK8xU332NmzFkQfJJ773yg933ySzxe6QWdL1s2g/XVARIkuBaVl6sFV6bGqIJGcTPRHEwuwLFRePCEcmR4/afjmrJwcA+86MLV4KqxzgcfvoDbv99mDhRWOsE7SCGQAq1X9nZDKiGEIUzOKYPr6JOlwOCkH0zdWg+djUIqgES8TViaWWhMTRERlA6N5EMjt+g93e9htNJLOh+2bIB1yTYuVnX/AZG6Sq/FmI3k666gGCm5Aswtw9Ak3HVU+bfDyvTC+u6vMQMH98JLLnbs74fuFr8tmE2ubnlt5sBqrZVsllOSCV+HVeqIlSsIhQi+fWR9DVmLIZya9AO0u5p9HZYfFVQ6wUhZo4GM2ULiSgJ5cZSQt0P08Uov6HzYkgGWDpAZCtwvicj+Sq/FmI2m6lsyFEJhIQfjc8qx08pdR5UT4+u7r3QSrtwNL7nIcWCnD66a64RsstR6YOsEV2uJ+JOQkgDNxJ9gj/+ckwEs5pQnTpd/f2HkDxd0PO4D1sYspNdk/8RmSpiaJHWg7xy6la/0vpu7Kr2ac20rBlgy0s31CK9ni9eYGfN0K6NwispiDsZm/eDm+56EoYn13ZcTuKjHd2i/qA+6mv2JuGxSSSS2ZmBVsprJgnQCyKjvJRbBUl6YWQLQuOdVefe5lIN7noi3CpuEurT6U4UCCVkd62NMDRGB7RrIr0/crG9pv4nZSi/oXNpyvzeN/TE9Gsj7BWmt9FqM2SilbUHfrV1ZLghzS36I8z1PKPcdV2bX0andCXQ0wZV7hAM7hO3tPrjKpFgJrjZjQft6lUb8pBK+l1VHI+zZBi+4QHjJxX7eYrkPgQKT8/4U57FRZWwWFpaVQghR5AO4dR7qNGbTUySBysuXM9ygd2ytpMiWymDpzaSHQ/dLCM/DakdNjVnt1i4sLGucvfLB1cmJ9bVk6GyCF1woHNjhWzG01EM2vblPC54pF2eykgk/uLqjyWet8kUYnhSm5pWFXPn3NzIFDzypNGWFhowfBh3EW62Bw565TK0RoFHEvWdkMrqTLTSrcEtlsEayvAjhnSCpSq/FmI2mCsUiLOWV8Tnfrf2BJ/3pwXK3scDXGF3SDy+9GC7sFdoaoD4tJAP1PaKoneCqRMQXpacSQmPGb5fu7RYu3y1c2OtPBpZrdgm+cxTufiJieMr/ebmoRNFqaw1jaoqIA7lInbtp9HM0VHo558qWSceNHaKnKPJpwV2E/Q5oasjq1iAsFZTpeR9U3fOE8r1jyug6qhqcQH87vOwS4co9slLUnk6Wxrxs7dqrZ1NqoOpYHQEk+JYXY7Plz3NU/MiiSKG7RWith0x8aCCIB0LX6mNsapoT6AtFj3/qr3mw0os5F7ZEBkvvICg49/OCvAQLrkwNKQVXkSr5orK4DOPzcHREuecJZWiy/PsSYEcHvORi4ZJ+oaPRn3ZLJdSfqKvhC38pa+cEgkBJJ4XmOj826MBOYf92qFtn3vzkONx3XHl8xGcclwu+b1npa2pMjREVulwgvzB8C7sqvZhzYUsEWKOzvFCVt4NkKr0WYzaa4rMoS3lfRD04DodP+YaiS+sYQpFOwYFdwtV7hV2dvku7byRqWZWSUqf3ZADZJLQ3wZ4uOLBDuKAH6tLl39diDh48qdz/pO+TNbfk67rCyAIsU6skUOT56tzbHxpg05f6bPotwq8OkGhrkE8L7gXI1ggYjSnHyiDnSMjlYWoRjo7AvceV7x6F0zPl31fg4OJeeOnFwv4dwrZmaKqDVNL3g3IWXK0oBZor24Tit/aSAcwv+SC33DqquSXIh9DVBJ3NQjYFyUBwgW6+mY7GnBOSAnakG/R7n/prjld6NWdjUwckCnJhLz+pIi9HNn+waMx6ReoL2BfzMD4Lj55SvnNEOTFWfhZExG8NXrVXuKhP6Gryo3FSCT+Q2K7x308EEs7XTjXXwc4OuGq3cNkOP7ewXGEET4zAkSFlZBpmFmC5oBRDK3Y3NUtE6HdO3jd0iI5KL+ZsbOqg5P230KdB8EmUPf4UgjG1QxUKkbCcU6biwvavP6Lce8xvF5arvQF+6GLh+XuFPdugvRGy6TiTYluDzyIu+md1WHSuAONzPotV7jDtYuQHQDdloanOB2iphB+hU8t1b6aWiUPpDkSPNBzkoTvv3Jwt4jZtgHXHdQR9e3k7yA2IJLFftE0NieJxOPmCMrcEw9Pw0Anlaw/7E23lcgIHdsIrn+e4uN+3H2jI+J5PzrYGfyDVp24TOllN82m8rTezCBNz5TcOXcxDvgDtDUJ7o8+MpQL/NajFthim5glIOoKmgxm++qkvb84O75s26/NDL+dCxf08ImksuDI1ZGWYc6gsF2ByAY6NKo+cUsbX8TQkAj2tvkB7R4fvUl7KnjjbGnxGTw2uVju9N2T8rMZL+oRLtwst9eXf59wSPDwIh4f813BhGfJremNZ0bupOYIT5AUu5V6vA5szVtmUi9brCFzK3SAO63llao7iR6v4ju1wehoePAkPnljf1mBLHbzoIrhsR5y5SosPruLMlWVNyiP45qyZpG/KurMTLt3ut1uDdTzDzi3BY8PKqQllesF/LYuRonF0ZUGWqTkiDZHqDcM9XFjppZyJTRlgDb+aF0fKT4Ks41C0MZvfSvYqEpYL/kL85Jjy0AllcKL8wujA+U7kV+wSdnUJrXXxnMEa73d1JkqZrGTCb6+2x/MKr9gl7O7yDUTLEanvjfXIKT9DcnYJcgUhimRzFqAYc/aciBxQcW/Vgc032m/TBVhHbiYN7h0Ku7DslakxPnsFhaIyv+xbMRwdgRPj5RdVA7TWw6XbYWenbyjqi9qxuqszUApIE4E/eVmfgW3NcNkO4ao969sqnJyD7x1Tjoz4gwtLeaUQNx81pjZJnYi+8WQvV7LJrvmbKsBSkLoMrwF+WHxhuzE1Y3UkjpIr+iP9J8Z8J/CJufLvpykLl+6A/f1+FE5jFtKJ1YJqc2Z8kCVkkz6A3dUFl/UL/W3lB6350GewDg8pp2dgIVdqPmod3k3NEpDdCQneN3EzjZVezHpsqgBr8I9oFZH3CHRh1wJTg1RXu7aPzsLhYTg+tr6eSXu74ZoLhB2dvploJglBYJmrs1E6SOjiTFZ9xre/6GuHC7qFpmz595UvwvFReHLMn0RczmN9sUyNkySqP1bI8LJKr2Q9Nk2ApQO4hPIzqLxYkU23F2vM2VBKTUWVXEGYW4ahSd9Y9PR0+feTDPwpt/39/gRhQ7rUrV2t9uos+cdPSQRCKhlvFbbCvh64oMcHsuU6NQlHhn1d3ewy5ItCqOpPFJ63z8CYqiUgLerkA4O30V/pxZRr0wRYw51cpARvARqw7JWpNWuK2xfzytSc3x48NeG7gZdDgP522LXNj2VpykA6Kb6w3X6kzolS49Gk82NvmutgzzbhwA6hvan8+1nI+YHdR08rUwu+FissZbEswjK1SHCq8kJR3rRZ2jZsikV+dYCEptxPgV6G2O/Ypras1l75MSqzSzA85bcGZxbLv5/2Rl/YvqNdaM5CNiUkAstcnWsi4JySSgiNGaG3DS7uF3payv/NMFfwW4RHh5XxGV2pxYriQdAWY5naJHUgPz/cz/ZKr6QcmyLAurCfA065zj+49qu2qT2KPzm4lIOxGXj8tDI4rhTC8v594HzR9YEdQndr3FA0qTgRq706x0rd3ZOBkk0prfXQ1+prsdKp8u9nYh4eGxaGJn3LhuWC3yK2LJapYSIiB0TdWyq9kHJUfYClIKLuzQq7K70WYzbaatd2yBWF2SUYnFAeeBKGpsvfHkwGvhZoX6/Q3gDZJATOB1d2rT4/nAjJhFCX9tnDi3rhyl2QXUeQdXJCeWLUN5OdW4qzWHEtljG1SZKg1419ht5Kr+S5VH2ANXiIa0Bfh8g6ZtQbs/mVEhWR+gvrQs6PUTkyDA+d9E1GyyECfW1wYY/fpmooDRN2q6ffzLlV2nYNnN+KbamHC3qEa/YJ29vLf8yX8vDIoHIkHqGzlIdiKLZNaGqZKLKvkHHvvutdVHW7pqoOsI7cTDpw7mdBdmPXAVNr4giruKbv1dCUL35ez8zBnhY4uFfY3ik01a3WXtnW4PkXCCQTSkPcfHRfj7C7S8ru7q7qA+r7nlSGpkq1WEoYWU8sU8skjerPdR1kR6VX8myqOsCqS3Mpqj9qI3FMrSldPCOFYhGWcsrorB/q/OR4+dmLbMoXtj9vp9DTCvVpSCUU58SK28+zlQ7vTkgnheY66G2F3dv8HMhyTS345qMnxmF20ddirTQePX/LN6aaCUi/c+6nqnmETtUGWEOHqBPnflZFtmPZK1ODSrVXy0Vf5Hxy3G8XrSd71VLvsya7OqG1rlR7ZYHVRvEnCn0NXF3at23Y1SVc2Oe3ass1Puubj47OwPwy5Av+RKFFWKZm+fZ9bz/Wxd5KL+WZVG2A5eCAwBuE6t5jNeZcK10zQ1WKESzlfEfvo6eVx4Zhbrn8+9rW7C/oXc3+gp6Mi9ttfPDGEZTA+TmFDVnob4PLdwo7O8sPdBdyfqj3iQmYmo9PFEZq3d1NDRNB2JFKuOuqtS9WVS5q6BB1Ee6nVdlpv2ubmqN+azAMheW8MrPou7YfHVZGp8urvRH8NtSFvX7eYFMW0km/XeW3ruzHaqOI+Mc8mRDqUtDVDBf3CRf1CvVlFj+owuAEPHxSOTXpa7EKRSGKbISOqWWSdMINYzurM4tVlQGWRlyJ4/XYQGdTgzQOsAqhspiD8Tlfe3V8HHLF8u4jlYBL+n1rho4mqEsLyUBwYlfjSnACgSjphD9R2N/uvzbbWsq/j7FZeOBJ5WRci5UrKmF8EMIK3k3NUvYU8u6dlV7GD1J1AdaRm0lr4H4c3RydWo051xQIw/jk4KLfGjo8xLpqrzqbYP922NMltNRBOqkEga5kU8zGc05IJnwtVls99LX72rhys1iF0NfhPTkGM0t+67hQtDIsU+NEEuL0DUOH6Kj0Up6u6gKshjoud6I/gthAZ1N7VsfiCMt5X3v1+DAcHvLZrHIEDvrafd+r7hZ/AU8EQmCRVcWs7YuVSkBdBjoaYe82ob+dsts2LBVgcFIZm4H5eHxOqWWDZbFMjRJFdiHuQ9VWi1VVi9E7SKm4N6vKHuzkoKlBq41FlYVlOD3ji9sHJ8qvtalPw85OobdNaGmIBzoH+J8o+6mqGMGfKEwEfhB0ewPs3ibs2SZld3cPI1+Pd3JCmZj1Q6ALodVhmdomvrv7m4c7qmvnq6oCrLEF9hPqj4rIOoZJGLM1rGav/Pbg7BKcnvHBVbkjcRIB9LbBjg6htQHqUkIqoQRi8VWllbrmB6VB0PGJwl2dvn1Ducbn4PAQnJqMx+cU/IlTy2KZGiYgvaTdu+64jjLzwedf1QRYR24mXSy6G6zvlalViu9tVAxhcdk3mBye8tuE5WprhIt6YHs7NGX8ycHAYT9RVSQQ3xerPuNPFO7s9E1gy93BnV+CR08px0aV6UV/8CEMrRbL1DghQPnZF72SPZVeSknVBFgNKfYqXGt9r0yt8tkryBVgehEGx+HEuLKYL+/fO4FdHXDJdqGv3V/Ak4F1ba8mIv5/gfPBb2MWelp9LVZbQ3lxcDHyxe5PnPZNZxdzStG2CU3NExB6xblrK72SkqoIsPQQSXW8VrC+V6Y2+e2duLFo3p8YPDamnJrwAVc56uLaq91d0N4ImSQkA0FELYFVRQTFOUjF3d3bG2HPNti7zQdd5VjKw+Ckr9GbW1rNYkW2R2hql4AkA5GfPH6InkovBqokwBoN2Y4EP2MzB00tKtXORCq+uD3nL5xHhpXh6fLvZ1sz7OiEbS1CYwZSScE5EAuvqoqI+L5YgZBJ+XFGu7uES3cIrfXl38/4LJwc9ycKF3O+b1qkYnVYppaJopclhTdVeiFQJQFWmAheCXpJpddhzEZbuRiKH32SK/iMxPC0nz03t1Te/dSnfd1VX6vve5VNCQnnMyXVnhNWVh+HtS8jfeaXT39bafDxZgouAlGSgVCf8e009nUL7U3l//vpRTg5BkPTq8XuUajEvUeNqVFSJ8hPahUUu1c8wDp6iOaI6E0g2UqvxZgNJ3Fj0ciPPlnMwcQ8DE0ok/Pl3UXgoL8DLu73xdL1GUglNZ45WFlrA5+n30qBUmncS7jmZRjFBf+R3/oqhhCFq2+PSu8Txu8Tv1/p754pOPu+9VTocSmNK0oESiapNNf5gvft7b4AvhzLeThyWnlsSJmY9z2yCpENgTY1zyFyYPiVvKrSC6l4M89MwMtQuYYqCPaM2XCl1gwh5Ar+VNjQpDI4qWXXXqUSvmP7hb2+eWVmzczBjaJKXGPqa8kojZPW1T+jiq68PX597Utd+2f/j0v3Ed/z0z6q+BaDlFogxPVmcbd6IX49fknppeoP2DaN18jGZvycSHyiUGlr9H2xupqV09M+cHw2YVzs/sggXL5L6Wnxsw1TCXBa/ZlLY84TEaVZA/dmvSP6R7mesFILqWiApQMkTqu7XqHFfuEytcrPHfSFyxOzcHQETk34rE05sinY3gE9LUJj3WprhvN1crAUL62Nd7Q0Ew9fS6asBkw+o6RxGwpdk1XSOIO1+jKMVt/+lGzTD0jJyJrgygk48f2+gkBx4uvPnKj/O6fx+/k/+0DMBzgi4OLoUOKP95THLf5cz/ljGX+8RHyisLkOdnbCpduFXEEZL6M9R74IJyaU4SlhzzZoqoNM6LOX3/d5GFMjVCSB6stOTHMx8FCl1lHRAGusn12q/HtFKr5XakwlKEoUCfkizC/7MSj3PamMzJS3yyNAdwt0t/ghwnUp32zUF7efozWuDaRK/ytlqeKMUxRnoKK4Uarf5vMvi/EWXxhv+RWLEGr89vjvC0V/Ei5fVMJw9X4i9fcdRRIHWXEGSvxsv0DiYCpQgjgblE1DJqkrj0PC+YAz6SAI4teD0utKEP+9D8o0Drri4C3Oin3foyln//iWYlTnIJ2Axgxsbxf298ed2ufLqymbnocT47Bv2gdpdWlIaCl7Z0xNEhW6E+rerQPRB2WAYiUWUbEA66EBUlHkPozQWak1GFNpa3tfzS767tyPD5ffmqE+40+gbWuGhozfHgriq+q5zF6UYqpIQSOIWFMLpaV6KSWMhFxhNWBaLkIu7+uFckVYLkA+79+eL/rPMx/6Au2lvLKc94FVceW+12TA4kxWKWsVOJ+NWg2SlGQCGjMS9wDzt1TSBzDppL9lk5BOxX9O+McslfA9wxKBD1AD5x9HiV+WDgs4eEpwdbaP8er4HB8ctzfC7i4fNB8eKi/AWsj5fmknJ4TOZmjOxgGkte43NSzuqfkj4718BnisEmuoWIDV1M3OULhWsKHOpjaVWjMUQj/IeXrB11/Nlnly0InfUtrX6wuk69Kl7NWZZS6ekqnSpwVVcSDos05KoQiFSAmLkA99vdhyAZbzyvyyP9U2swgzS8rsoh/7M7/kW1As5f375go+yCplt8LQB2tPKUonLtpeu77S2B9ZHT/j1gxTTiSUVJyhKm2/ZZN+K7UhCw0ZoSnrt9MaM35kTWPWn8TMpiGbVNJJ/1imEhoHauoHZsdZMCerH1Oels1ab9Dlx+cIyYTSFHd372sT6lL+sSzHk2O+rUd/u9DZBJmUnz8ptk1oapagaH8e9yYl+n2pwNGPigQ3OoAbcbxBkW7sdyxTg0pBRBgHJ7PLMDqrnJ4p/z6yKdizTdjdKbQ1EgcFa4u6y1/Las3UmrXFW3TF0A8UzhdLQdRTg6T5JZhbhvllP6B6ch4m5/0pyIl5HzjOL/n3L4SVa6Ug4jNW2ZTSmPXbaS31Sku97z/VUu/fVsqA1aX9LZvyt0wcePmMlz8BuLK1uBJsKaLld84vvY/ELRsyKX+isLcN2hooO8AamYbDQ8ol/bCrU2jI+HmHah38Te0SEUmh/MTxW/hfvIfjG72AigRYE9voQdxbsZODpoZpXNy+mIexaTh2GkbX0Vi0MQt9bdDZDA2l02Px8f/n+riw+uuc34LztU7FEAqhUCwq+RAKRWW5AAvLMLMEU/MwMatMLsDMojKz6Lc2ZxZXg66lNVuC+cJzn4bbKKpxgFjwQd9IIt5CTPjAKZMsBVRKXRpa6qC53o+waW+A1kYfiDXX+VN/2aTffkzFW4vJwGeifHG9v5W7nVgqyk8n/bZvb6uwr0eZWiivF1qh6LNYg+Mw2++DxWxcj2fF7qaGCegl6YDXArdu9AevSIC17PhhB3sr8bGNqQalfk/5os/unJyER4dgbB2DnVvqfPf21nrIpPx2mHuOC2lpXt1KH6pQKapQKOpKTdRS3s8/XMr5+p7ZJd81fGRaGZzw3cOHp31QVQwr31PqTCj+sc8X/ee4lsT/c+KbgbY2+nmBfa3Q1+7ro9obhNZGqE9BfdbXT2WSkE4oyYSQDJQg3lIUfOG88v3biWs5gWTCB3nbmv1pwtMzykMny8v6zS764vjJeaGj0dfkJRPP/T1hzBZXp8ibhg7pF3pvZHEjP/CGB1h3XEfgRN5oY3FMrSq1NCiGPjs0swjHR33DyHK3hDJJ2NXlx+L44nYhCJ7ammG1h9RT66miSClGq1mqXMHXRs0s+u29iVmYmFcm52ByAabmlal5mFrw7zO/7AOTrar0uIUKIT6rOLMAg+NK46DPDrXWK+2NPpDpbIKOptXsVmOdUp+CdEpXCu2D+JSjiwvnS0Hc2tjHCSSdkE0p7U1wQY9wcgIeG9KyHu98CKMzfsxST6vf/kwnBXWcnzYTxmwGIiKw30X6IuCfNvJDb3iA9dLXcFBVXojVXpkaFuFPyi3n/bbbsVEYmy0vU5EIYGeXvwB3NvmtoGSg8X67PHULcKXflBCGvjA9X4RcXlnK++1Jn6FShib9NtOxUeXUpN9GW44L0cMq2earBGV1a7HUm6q0tdiQ8Vu0/e1Kf5vQ0wJdLUJHE7RkoS4T12+lSgXzQqC62n/raf22nPPBcnNW6W31A6Dr0uUFtKp+fYMTys6O0veG74kVONsqNDVLVOmMnHsdRFs7wFJ1PwP8X/beLEaONMvS+66Z+e6x78EggzuZzD2zqrKqurprprtnpgfQaANqniUIUL8NoAH0nu8CZoR6kFTCSAONHgR0QXoQ9CBAM71UdVd2ZmVWLszkvgXJWBj77rtdPVwzdw9mkOHuEcFK0v8DBINBupv9bhYe/4l7zz1n+EWf18Hhu4C4klQLrS23U7Jq0eKGtkxispG4fXrYvK/Skbg9jt1pGH5GXlSxlqpqbb+tolWiVraUpU2reixuGKmaXbWvC+XjuwavAio1+9gpGTGeW4W7eWW0D8b6lbE+YbTPbBeGeoSBvNknZFOm90r4DeLjNVe0xMhbJgm9GSNvo712v1oh32s7cP+JcnHcPLXqbUJHrhy6GCKSCDX8Rxv/isG+f8nqizrvCyVYn/6CBKr/CPGcsahDd6IpGiduDz7ZsGpRq+jNWHtwYtDMKZOJRiWkMZ1IJFI3srQbaalWtoxEPVxWbs1ZtWq7aJW0YqW7K1WdItR4ctIqkekk5FI2DTgxIJwbV86OCZMDMNxr9yybsscZ2aJudgpxFcseM5CF8QHh4Yp5hB2EzV24+wTm1uBiCfqqkbO/myZ06G6IB9O7vfwz4H97USd9oQRrQvkzPDmNaw86dCliAhR7Xy1tWCxOq9rAvW/mAAAgAElEQVQrEatqnByEoUjc7knkpB42KmPFirBbMk+t9V3TVT3ZgLk15cGi8mjZ3L+LLRqaOrSGamj3crto1/vhsrVeH6+YQH6yXxjtt8zIgZzSm7WpwXQCax9GpaZ4orAvJ5wesfs1s9QYUngWQoX5VbvPGzs2AZlNgTq3QYfuhiCSC0P+06X/Rf+vkf+KNsaJOscLe9vd/jkp8eW/QMk4euXQjYi07VRDpVS16tXjFeX+olIoHfRsQzphrZ+xfiGXMT1WqOalVYkE64UybOwoS1u2wd+Zh5llCxBe2bJqVuk7ZJ/wLDQLwb9VfdmTU/jdRbFiVa2FdSWfgb6sMt4PJ4eF6WGYHhHG+m0iNJfWqN1r0TwJ36pgFyYkat3qtyYe98NOOWr1bhoZ70mb8arnv/gwaweH7w7EE/igUNPLwG9fxBlfGMHqzXOiWuUDaccB0cHhVULUHqzWhGLZPI4eLNlHuYVgZ0/M5fvUsG3IgdfI+StVrGqyVbRsuicbVvW49li5+tB0Qt8lSNNfzMncyGIcVB3H03jR5zi8GoiE+/FEZCOqJ4yc5gsR2dwTRv1CX91eVEO7L1tFmF+D23Mw2KOcHYMrU+xpH/ZmzVE+FVg0UDoBU0NwegSuPvy2pcR+UIUn61bFmhy0KlZaBQ/Fd7/dOnQvRIUhr+b9k7/4Wfi7f/5LWvipezi8MIJVq3j/CZ7LHXToXiimcapUrcq0vGXVq+UWyU9fDs6Pw9iAkEwYmdgqwHYktJ5ftYrY3JptsE82zBl+84U6vxg8iSftjDTFeYAJ30TXzRmBycD+nk/FcT9S1wz53rcjaWKyVAsbJCsMI1+xGmwVlK2CGZ2WmiJ5yhEZrUTatHLFHvOi3eVrar5iu2WYX1e+eaScGBRODcPpUeHEIAz0QDZhrzWbMqF8PqUstniO9R1rAU8Pm29XNqUkPEF9p89w6F4IEogX/sk//CP+V37J3HGf74UQrIX/kdFQ9D8XlQAX8O7QhdB69cq8r7YKNq031+I8i2C6nekRoS9jhGF12zbpuTW4PadcnzXPpLVtq5rEeX4vCnFwcT7K0xvptQm4oR6hN2v/bsJuIRUYeUr49pyGX9RTpCo6cD17MDrXflmJocZZiUI1ivaph06Xte4yv1000rm6beR2ecs+dktG1F7EJVPMHX+naBq8L2eU/hy8PW0fp0ctuDkZ2L3MpIxge3KwDgtsoOHBonJuzMLA+7JWFfO9huGpg0MXwkPkzUpKfwT8n8d9shdCsCoB3/NUrrj2oEM3IwytWrJdjCpOa1Z9agUiNj2YS0GhosytChs7ysNluLNgn5+s27GPmyDEsTDJqKWXSpp1RD5taxzuNQ+m4R4Y7LHNPZeKvaAapCqOk2luA34rQDnO6ttnHc2WFM3B0GFELqthTGot/qcSObcXKrBbhI2CsLplmYnLW7C6ZdE/W9FU5W4U+WOk7fgmLGvRsRfX4dOqueSfHbWP0X4hnYByRRnIWTzS5u7B97hQhgeLJoy/MmXtx0wSEs6uwaHbofQh3p/pz8P/R/4FLf4E7gzHTrD0Q7x5vP9MkN7vshjVweE4EapSC6Uubn+0ojxcbm30HhoxKqWqVax2i+b8fn3WhOvHba8gQBBYLM9o5Fw+lDefp/68RB5PVmnJJc1gMxsRr2Si0RpsBCPHZpvR1Fw9oNo+GwcwsXeDECjNVMsIVuPfjGhFodWYY70STViqUKtFDvZxeHUFChVht2RkarckFKK/bxWi8O11WNpUVqJK13axtQpSJ1Ca7B4WlC/7rCV8dtReZiohjPXbQMNB05+hWoV0Zsmic3aKNq2YCiy6B9dKcOhWiPio/mg2zWvAF8d5qmMnWEvjnEP5iQo+rv3v0KUIVajUrCKytAk356zCUGrRJiGMdDt3560KtrSpzCxbW+s4EFeVkoHFvwz3wGifMNYHE4MWETOYt9iYbCrSWfmQCITAU5KB1Ctd+1enYuIUTbbF2/6e8ors0VzVHwNNn5/6kaKy5/+sshW720tkvip1zVa1BpUQqtWIdEWarHIVNnaElW1Y2hQW15WFDeqEa2PHKl21Y2rFbpdgezFy2F+DXEpMR1ZpneDFJOvJBkyPQH9FqCUskBpwP40duhWCcNpT/piXnWBVfO8fe3BC3dvZoQtRb2M1eV+tbCl3502U3s5m+WjFdEPlyDz0OKpWnhihGuuHiX4zyhzvh8Ee6M8JvRnIZ0yQno4CjhOBTTT6TUTK87RRrfK+bbWw3w+D+N9EGoTl6XBk2efzHnLTpNeKi1vN/60KCQ8UjXRbElUXGxOJMfEa7oHJEuxWYKcobBVgs6Cs7wjLm2aDsLBmBGhxw/RUR13c2i7CzVnwxHINEdOVtYrNAjxZV1a3hKEerQ8ReLhWoUNXI6PIn839Qv+n4wyAPlaCpSDzqn8CnvO+cuhO1J3VlVJF2CqYxubhirZkzdCMeCLuKBEL05OB6XvGIhuI6RHh1AiM9VnMS6yhiqf+9lanBE+stefFByVq/zW1otrZ0I/isfJUoaaexddUOVM0qnpFrUWN2oqhka5qzoxbK7V4GlEoRpYYq9vK/Kows2yC8tlVi6rZLloLT4+oslULLXS60sFQ+VbBdFhnRm2asDdjmYixJ5aDQ3dCREQv+yFvAx8d11mOlWA9/jec80N5K2oPOjh0JVShEja8rxbWrMX0+0RzpWoob5qq0T7qYcVDUfuvJ226qlic7vuxR5VVp4hE6jGNssrR3vbfdwX7ETGJSl6qDVW9KuAJIZBUCBNCTZUwErvH+q3RPmFiAM6OwdIpYXlLrSW3Bk82ownFTWslvshpzmYUynB3QTk5ZKR5qBfSSctAFCd4d+heCMhIzZM/0b8IP5F/fjyeWMdKsBIh/zQURvmu/aR1cHgBiCsYtdAc1jeLpt+ZX+usGnEUEKylN9ILb54SXj8JY/1mRjmQb8rJS0S6qkhT5ftxlWovmaIuTm86x0v4bt/TvhQTy/vRFyoQIKhvVa5QlVpK6AmV/iyM98GpMhTKwtYurGxHRp/rZir6+X2bTjwucfzzUAstpufOgvLmtDA1ZDmJCV9cALRDtyOpIn+2tMR/D2wfxwmOjWDpz0nNi/yJi8Zx6GZY7qCJ25c3LIj38YrpfV4kMkmrSI30miu4tQDN1LI/1zD5TAYNTVXgS6SnkkjXtFdEFcvTX0XsSxo1bisKvkJCzc8rk1RyadNGDeZhqA/G+4WT23BySDk1Itx7oixtWC7k6vbRt3qfh1IVHi2bFmu7aLYZ6YSi3qt57xwcWoMI6OWqz2Xg0+M4w7ERrAc1JpLwnoi49qBDV0Ixa4Zy1XQ5s6tw/bGysP7iolt8z8TaFybg8gnhzKhNAQ7moDcXi9WFZKAEnkQi9UhP5T0lMO/S/bj+uptevx99rQK+LyRCJUwI2VDpyQiDOWWsH6aGhEuTsLotPF5RHi7BtVnl5uzxWj48jeVtWFiHjR2z2sgkhcBXwtDus4NDF0JE6fc8fqQ/43M5huicYyNYqR7+CSpDvKq/4jo4PAfWHhQLdq4IG7sWvHx7vrU8ucMg4ZtuaiALU8OWdXd2NBatmyN4NpoAjO0UYk1VrJ1qdlB32Iun5WU+RrLUs6nEpNp1jStbAzkLXR7ptczB0X44OQyPlmzgYWPHvLeO08tst2jea3NrprfrySrJUHC//jp0NUT8GvKP5/9U/w9+yfJRH/5YCNbcL8ii3p+gpN1PaIduQyxoDlUtfLhs8TUPl22c/ziRTtjmfXHSKidTg+ZdNZiPgoTTZliZ9GNdFU3EqnurVJ3i6esVD+dZ/I+QjFuIVcsSHMyb9cVrU7C4LjxaVu4twvVZc+M/rtZxNbTvvweLFh49kLc2YeBJY7rSwaELIcj3xdez8JIQrHKV6USSd8WZBTt0KRQII8NKcwW3YN/jqFJIRJKG8nB+Aq5MCRcn4fSIMNRjpCqTNNF6wjeLBa8piuZpjyqHzhBfQ1XqE5ZxYHUcfJ1L2/TmaB+cGICTw8LJYdPGffNImVkyq4fj+D6ZX4Vb89Yunhww642kD65D6NDl6JcaPwQ+OeoDHwvBSgX8QGHcNRgcuhVhaNYMhbKysgWPV+zzUSOVgJNDcG5cODcOp4dhMnJa789ZZE1MrExfJftMAjocJZqvqR9ZQHhqfmGBD0lfySSN4PRkrJo0MSBcPgG35+HmnHLviVU7j1KjtVWE2/PK/LpwoQS9VfM2810Fy6GrIclQ5I/W/rX+u4H/hvWjPPKRE6z7/5a0lr0/BcngGJZDF0KxCkS5qmwXLdT5/iKsH6H3lWDhyufG4f1zwusnhVND5riejytWgUXX+F6U79ekqXIb6otDHA+kChIR3cAXkgkjWvmM6bQmBoSTQ3BmVPhyJuSLB2b3sFs6OqK1vAXza8pmwaw5sjWbGHWeWA5dDEHke4WUngM+O8oDHznB8oucl4C3FWcu6tB9iL2vQrVIm81duL+o3JwzsnUUyKbgYtQKvBRNBo71x9NhEbHyTXhtk4DiNs/vAGKCqwieD55KZIdB3e4hm7QhhLF+j8snbCjiqxkbkDiK3MlyFRbWYGkDRnqgJ6OkAqlHOrnvE4cuxSgBP+W7TrA8+J4qp1ztyqFboapUa+bcvrFrUSWPly3f7jAQjDi9eQr+wevCxUlhsh/681a1slagVaw8eZVdql5uSJSP6GE2DwkB31N8T0gllFxU0ZocsMnPobzy2X24/tj0fIdBtQaLkdnt5IAwkBfSCRt4cHDoVgikQuSP7v9b/R/O/Jcc0a/CR0yw9EO8hcD7B0D295QM4eDwe0eoll9XKMPajvletZs7+DTyKZgeNS+rN07a57F+6M+aJUMqEPxYvL7PdMkLi2qxEs2rcYwXgPqAgSckxVqHgW95gZlklP/oCwM9MN6vXH8MD5fMPLQT1EJY2rSW9alhGOtXsimp50o6muXQjVDEE9G3kiHTwM2jOu6REqz5CaZQfRPxjjWCx8HhuwiNg51DC3LeLsLaNixvaccER4CeLLxxEn54UbhyUpiI2oH5tFU8Al8QT6PzN0KWjWE0Psd/Wu6ehRwjiqige4KZ939+zFg0Okd8HNnzmIOeL/FR4DlrPfg4PPcc+z1f2ftaaboqbZ+jfhyeev1N52q65k8/v/naWXuu8X+BJ3gB+CIkIqLVn5Mo+1D56KYRrU7jlta2rW19fhymR4XerJIMjOAprk3o0KVQGSfUnyjckiP69exoK1ge74rKFO4XIYcuhBJND1ZNmLy0aRElG7udHS8ZwIlBeOOU8M5p4dIJ+7o3Y+3AwLefAZWqokQiaol/LmgTWTJNWF1o3fQYsJam7e3a8MOKf76IGp+oP5aIXO1/HBGp/19EJZ5xrv3Xuud1aHT+pucTPX+/8z9rHfs/P3qtTeeQxqv8Fh2sH/s5r0P2eUzzNd9zPZrWEaN+nOixIkoqAC9r3wvpJORTUo89uj1v4dLtWjrslKyC9WgF1rdhMGf+aYEX2Us4LZZDN0JIisp/9Nkv9N/x5xxJmNWRESz9EG8u5IcIvUd1TAeHlwmqUFMo14TNgvIoCtntRJzsCVychO+fE94+LZyfsI2wJyMkondtpWqi5XIVqjUjPfXazH4bpO75xH59tHrLqmniMBZA7/kcPz5mEPVzPuMXP93/f+Rbf3nOMVpB/QJ868Xue+T9z9/0T9J0lTSiYE9fg6bHwT7tWGn+q6DaIJJ7HibUjV+DAJJRuzDwTWMX+JBOKn05mzb85Db8+rq5s7eLxXWzDlneMiPafMYyKD0cuXLoVognom9M1RgAFo/iiEdGsD7aIHXmhPxAIXFUx3RweFkQtwerNSiUIuf2JWVm2QhQO/A8ODsKPzgvvH9WODtmMSu5tBJ41nwqlpW1HRvjX9uBYsWqZ/XNXp4iD7q30iFR9USfIgsW7mxWAs37bBg9rlYzEhlXOXxRxGuQkNiJ3PO+Td/iaxSToIjH1Z8PDRJ3aDSdfD8yE58nJjX19Yi9hrhV1nwdQlXC0K5jvYEoDSd8L+KatXDv+eLrqVG1rFaLrgWgIfX75UfXPvDNI6s3owzmzCcrlRRyKbVKVsI+aiEUq/D5PZhbNbf2VqGYfcjjFWW8X+jNKUlf8CW6H45kOXQfRJUxEpzmu0awzlzijCpnEXHGwA5dhzDaWEsVZasITzbg0bKy1GY0TuDDuTHTW71/1sxDR3rNkDLhUydXWwW4OQcf3bSolWrVyJLnN0hBvZgTISYaMdGJ/x6Ti5go+F7s1WSvKSZNin1dqdrzYjJQr3rRRJDiyo82rk/zeaWJlMQfMffqGPtUluICW0wQNdz7gOY11ElidBBPYnNW+79aRKBrYeN1xI9LRNYYqlDViIhG50oE1n4Lo3/X6DnV0Mh37Pwe+Pa4ZGCToaO9wmtTwjunYdBXUgkh8LR+f8NJq3D1ZuA3N8wFvh2StbgBt+aViQFhpNdsIhKBWBWrg8vv4PDSQySrof5EP+R38iEdjpI0cGQEK/T4oSDDuPemQxch3mRVrU23W4TVLSNXj1atstQqRCwn7seXhO+dEy5MGLnKp23TFREqNaVUFTZ2zVvrL7+2jRUikhTraJrW1kwkBNuE4ypNXW/TVPFqrmLFhCBGqNFztXGu57XdNGJNMXnaU9mJz9lMsI6iehW3SqOqUEyaVPdek/iTyJ5/+hYBjP+99hRJjB+LGDFKBHbukAbBUqJ4Is++roaNdcVfN1+3+Lr3ZGC014YlpkeEngw20BAInqdI1h6XSljeYaliFbaHy61rstZ34MYsTA9r4xyBWXy4KpZDl8ID/5/dGaz9G2DzsAc7EoIVhTt/gJA+iuM5OLxMiNtCpQqs71qo7p0F07m0Ck9gfAC+d05475xVroZjcpWQegVEVahVTde1tr3XHT6uMLU7XBaToBi1+h/PRyfn2vP8oyBTB+CZv4Ie5bnVJvqeNdVXrkK5hXXV718Iq9v2eXEddopR1RAjYUHkWSWiIPH3ns0yFspmC9IKKjULf773BN44ZVmW2aQRQgeH7oSA6OVchhN8VwhWIqC/Gsp7irq3pkOXQaONUSiWbWO8v6jcW9C2TCEHe+DdM/D+WeH8WHPlynQxzWeLW0ubu+3ruxxeDqgasdosms6qWdclUTsxrjzGFbtyVXi0oixttl7FKpTh4YqyuCFMDEBvFlJJ8DSqZB3T63Nw+I5CgH48rgDXD3uwI9FLVeGSqp5y3UGHboJteGLGojVlt2wu2TfnbIKwVT1MMoArJ+D75zwuTsBQD+TSkXmo12hX2TklakeaeelRhgE7fLeQTkImwZ4JTmjo5XzP2oP5tDDUA6dH4Pvnhdem2qtCrWzB7Kr9clAsQ62moPv0fh0cugKSpOb9WD88fAHq0ARLQULl+yr04xiWQzdBrKIUhkqlKuyWTDh8ZwE2W6xe+R5MDcK7Z21jnBgw/U068W1yZbCKWci3p9UcXi1kk/bR8PJq0ovFdg6ekEpAT9q+d945LfzRFWG8v/XzrG3DzJJ5au2UrHVY087NcR0cXnJ4Cj9dmyB36AMd9gDr/5o+1HtPEGfP4NBdUNBQqIVCuWphzosbVgloFeP9pru6OGF+RCZmfha5Mh+luIKR8BuCdodXC4KR6Gpok6P7kZ06yfKNkPfnYHIQLk9aCHiyxd+/C2Vraz9eUTYL1nYO1X1jOXQvRDi9W+O1wx7n0ASrkGdClLdx1SuHLkQsTC5VLIh3ZcuIVivwPTgzCu+cMePI3gxkkjZxth+5qiOaWksn7BgOrx4UawNXak3WEs/4fohtIjJJy6Y8MQivT8HZsdZahbUQHq/A41XqBCuegHRFLIcuRQ8J7w8Oe5BD/3gW4Q2E0cMex8HhZYPZCii1UClUzPBzbaf1tl02BVNDwolBM5NMpyDhyx5rgP3OGrtt10XODq8kKhHRqd/rfRhPs51EMhCyKYvROTUMZ8fMeqEVbOzCwpqytQvliuVpPj1d6uDQPZCEBx/ozzjU4N6hCNaHH+Kh3gdA/jDHcXB42RDvO7EWqlCGtW1lc5eWN6V8Gsb6zVQym4KkHzmgP6d6JZFHUZwZ53Qyry4qNePPiYB6y/hZtzs2RU0mzAV+pK9RFW0VS5uwHWmwQqfvc+huCMo7N79H9jAHOZRK/r+eYDBUfUPESx7mOA4OLx1ichMZT5Yq1l7ZLbXGr0RgIAfDPUI2aRvjs3RX9ecAnmikuYGBHujL2Ln3nFOPbrrQq//RlD7T5Mb+bat4Ghk4Tf/d7O8Z64uOcp3PQtxCbV53fV3P+vVyn9fRbIvffB2O7Dp7tpzYbT4RwFhfNPSQjnICn0u8I/sGz4LAe7ONBID6eg/AbgmKZaUaiptOdeh6iDDe28e7wK86PcahCJbCKYGzhzmGg8PLDI2czSs1c21/ltnk08imYDTyukpFUSqt+A55IqQCpT8Pb54y762Hy0qlaucuVWwSbHnTxPadbpS+Z23L3ozpelIRAQw1FkE3qib1al7YIF5xFmHc2ooJlYg9d7dkPl7ru7BdOPpOlO9Zq2y01yo6XrT2+CPh2b9B05qji18Jba1B9JhYZwdGguLMya2iGYFuFTu/ztkUDPfYte7LmgN8NTRyNT0iXJkSyyIMwPOf//0hmHVDwlcyCbP6yKYacUEHoRZ9H9dd7zt7SQ4OrwrS+N5/rIS/7tS05FAEy/M4GyIjTgbi0K2I413inLlWNloRq0r0560SFfhxdaKpTPKM53mekkwIfVnl/DjkUsLGrlCpGfHZLiqrW/BgSbkzb+Ll3adtxFtAPg0T/cKZMTgzAv05swMQMXIRv06p/7E3isZvqno1V6vCEEo1ZXHd1nZ/USlVjtYwVTAPqckBeP2kGWjm0xIFLltYduA1CGMcdxMTrFBjx3T7tzhnMr7PpYq1gmfX4JoopWXzj2oXPWm4fAIuTAiTgzCQk6hFrPRmzNtqpNcIrhnOqrWInzP8ICieJwS+kk4I6aQ29FsHQKPv4T2RQg4OXQpFApHwvc9+QcCf00boWQMdEyz9EG8e7x3BxeM4dCEE6vZEUbZc4Lc+1Rd7GPk+Ta2og39VERESPmRTwmivkktZ1SquPhTKwlYBpkeF0yPKlzPK1ZnWfblihGqvZTAHp4aFsX6riCSj9daz+Ig6bbJ3Y44rWM3HC9WE2zsloTcN5arFurQTUNwKFCiUbA3DvXBmVBjujT2lbFV+XJ2K253sdUavB2B7RgpjklWpwlZRWNxQSlWb0qt1kBc02gevnzTfqvPjwmDeSK3vN7ytMknIJoVUMrbkeP73h8R/igVCxyHTLaOJKNtf2n9dDg6vECRUTp4pkYEXTLCAQFXfFrykm2Ry6Do85artRdqXoMWZk7i1WAtNc2MtmRYqWAAepBNK4AnZtFKrCaGqhQfXhGJFmRiAEwNCPiOUKiHXHrVXyapULddORMikrH012BNX3AQvqrZJtOa9a7fn1UtDKCFCLbRq1doObBeNQMSao6NGqDYNl/BNjxR7jCUDQcRiYGy5as5iTWtF7PXEhEVVza2/qhTKRoI2d+2+l2tW0WsHPWl45zR8cMHjyknzQsulIud+39bmeYrvCb6njfbx86w7iL8lG729gx7/NJpJpoiZuTs4dDNEZbyU1QE6zCXsmGA96GMyLZzSI4rbcXB4mRDzB4l0UwlfySQt9uagjoyqjcUvbymFskRTW/ubSe53Xg9QEZJeFJ0TNMwoayFkazaun05AqEqpZKTii/uta8SKFYtPuftEmRwU+nKmaUr4QjppWh+rUsW7cPNu/PS/SVS9EsLQiMtWwbRjj5ePr1CytgMLa3BuzNaQCiCTignit9dqRcRIbRF9VuzeVGp2rauhsrED9xeFa49Cnqy3t37fg8tT8P45jytTcHIQ+nJinmZ+Q4cnEQGMq1Z1Pvg8qK0xVChVlZ2iTbe22u6LtXN1MtfG63JweEWRBv4I+N87eXLHBCudYxoY6/T5Dg4vMxT2tJGSAWSSJkBvBbtlmFuzmBITx2s9Z/CgqsMeTc1TVQrfi1uVpr05pebKXQ5hfk15vNL6a9wuwjePIJMMSQYeuSQkAo2ObyQlbg/W1/T02rWhcwpDpVyx6s/jFeWbRyZyPy6s78D1OWVqSDg5rPRlIQP4Io0W5n7XOm5/SqO1GTv1L23A7Xn4zc2QLx/YvWsVyQDenIYfXxSunDBD0P48ZJJaJ33N97IdghOL0quhacS2i7C6rW0NEPietYCD6HtH2il/OTi8ihA81PszCF8cwdIP8WaVy55IXyfPd3B46VFvw5jeJRnYxFY6Sctz8Ru7Fg69VTANTiVpbSGpH/vZz61n0u2zLDF5JqCEeZgKrWL0eMXah8ttFLtXtuB39yDwQlKBR4ht5r0ZJZ20iTWvXv2JK3vWIlSN2kyq1EKhWIHVHbi/CNdnta1IoU5QrMCNxzAxEHJuwqM3E7dxozXH1/Cpi2guDYpGLddCWVnfgUfL8PUj5ePbys259siViJl/vn9GuHJSODFkk4OZpEXaiGi9GtgJr7FKmxH1QtmmSB8uw/JW6xWsoR7IZ1wEk4NDAyKg7y78d+TG/1t22n12RwTrwTTJVMV7X5TA9ekduhFxxUZEIoKl5NORkJrWqgY7RZhftc1wIBfH5Bg56XSDq1ceQkgEQk6VatZG/j+4YILsv76m7JZaP+bSJnx2D5JBaBl1KtRC6FUlk5C6R1MsGqcpOy9s0oVtFmxy8PMHyu02CUqnKFbg5izMTCtDeWvFxW75xOadzTcrspQIQ6FShd2IXM2vwVcP4T9cVW7Otjc0IGJWDK9NCZcmzQC0P9cgV17ETjstGMVCfRtysArh7Crce2JrbwX5tA0z9OdsTb48p8Ln4NA9EIXRSpYJ4E67T+6IYHkFMpqQd+FwNvIODi87RNQE7oFtUn1ZG5FvxXagUIH7S3B7wTbcfJ+tzU0AACAASURBVDoax/cUOcDz6CB4kWFTIhByaWWkFy5OwG5JuLeo3Jht73hPNuCTu1YhqdTgwrgw2gf9OSWbEpKB4vuCHwnHTXdlAvyYXC1twp0F5asHlnv3oqwA5lbhq5lY5A6+byQ2GZjthUSUWFWoRdW2Sk0plKzN+HgFbs7B39+yicx2ieFgDt48BW9Pw7lxs17Ip4VEoPU23GHIFVi0Tbkq9cDxewvK3QXzRDsIvgcnh4VTQ5ElRKQHczosBwcQ6MVjihdFsNJwsqo62fFPBQeHVwSCkYpkoPSkbfMcyBkhOQiqcGfeTCH7siZ2TiWiNqGAeJ1vvNCorqUTQk/GJgt3y/DeWauePWpDj6UKsyuwsQNPNpR3TpvR6ZlR6M0q2RSkEkrCsygfUaXWpF1aWLfXenXGNv7aMUwOPgvFCvz6upHehC8EvunBsmlrh8UzkGGokZ+YsluG9W0jgl/cVz65rdx50lnV7dw4fP+8tQZH+6AnE1euYkF768faT6NXC6FcEbaL1v69v6hce2x+aK0glYCpQZgYbCKh3uEIvoPDqwMJ8LwfQvjX7T6zI4JV8znrCX3qfsFx6GLYoJlGInchn1FG+83jaGmzNdPRQhm+fqicGxdODinZSNdkJGuvVqiT9XmY4D2TEGpZODGovHvGo1AKKVVgsc3h4+0ifH4fNnZN67NTtNy7/pxZDaSTSiKqa9dCI3Rr29auuvoQrs9C6QhNRVvFZgE+u6eM90M6KeyUmhzqraNKpWoEaqcI67vK/CrceQKf3bWKXydu7SO9cGVKeG1KmBqE3qwNQnjybVH7Qai7q2tD61ZTm3DcLZum7cESXH0Id59ArcX15lIwNQSjvUIuHbdQG9U1B4cuhwSiP4rfdu08sW2C9c2HJPG4okgbMaIODq8mJCJAicBsGsb6hPMTsLihLVWxwIxCb8zatFsqYe1G31cyCBKRlUORLM/MSTNJq66dH7eKx/oubN1UCm1WZao1uP8ENneVa4/h5JBt0CO9Dcd3T4ywbBaU+TX45pGRlFavyXFgfQc+uWPE8PQIjA9AKmH3L6xBuaZs7Fq1bX5NebxqGrn1nc7I1Xg//OCC8Oa0ObX35YjsGKQe6t0Omlt2Gk2HVqtKsSxs7FqF8Xf3lN/c1LY0YkN5mByQJp+zg01NHRy6CSpyaf4XOsSfs9zO89omWPlRcoL3jvO/cnAwmIu7kEspY31w+YQwt6Ks7bQWAVNTuPfEKizZFPRmBD+aLEuLabrQQ1SysHZjMjA39vF+25xjn6i7T1rTjDWjUjMisrAOXzxQTg1Zi2m834w0Pc/iY1a3jajcne+scuWJbfixK3kttOtVqTQsFFpFqKalerKhnB2F02PxMa01WKnAyjbcW6StScv9kEuZS/tPLgkXJmAoGmJIRuTzMFN6sd9ZLVSKFSOxi5twb1H57V1zx28VAoz0GdnszdoUbHBA6LiDQxdiEI/XgF+386S2CVbCp0fhtXaf5+DwykJMKJxKmK/RmRE4PyncX1IWW6zYbO7C1zO2CedTdkyPxkYcO8R3uufFU3OphAU4V2sW1bJTtE3/2qPWTUifRhiaVmllG+4uaH3MvxpNte2UrZrVDnzPKmKnRuxzJtr4FTvuZqEhQF9Yb08wv74D1x7bc33fjE9rasctlmlrwnI/pBPw+il4/yycn7D159INE9rD8JZ67mVo7cytSN927RF8dtcIczsY64fz48JID/SkIk1a7LV6iHU6OLxKUKVXxHsNwuMlWKHHpA9DLqbKwYE4+i2yahB6M8qJQbg0ATdmaZlgKaaH+u0dtTaS19DC5DMmOPY7bBfGG6YHJDxBk2a6eXrUxMwKrG0rD9sqfu9FtWZeW1ttZh4+CycG4b2zwtvTMDkoZJKNnMdKDbYLsLSlfPkAfnND29aSFSvHYxORDOB75+Anl601ONFvAwypRMOc9TATg2FoZqKFcjSZGRmf/t2NkM/uGVFvFdlUI2x6qNdc7hP7GJ46OHQ7RCRA9VK7z2tf5K6cQsi2/TwHh1cQdYNNzMAykxT686anujhhUTDt6I5WtuDTu0o6YZ5Nlg2nkBZSmK1AJ8L3+jo9SCBkUspg5J/01rSwvmM6skfLrbU1jxODOVvT985Zu3UwHxmERgSrWjOLi9Ftywlc2TIx/Xbx97vuZACvnbCJwTdOxaL25vzGQ5IrVaqhUCwrW7uWBHBzTvnsLnz90L532sFoH7x2Qjg53JgejMXtjl85OOyBKHq+3Se1TbB89U4j4giWg0MTBKtQJAPT34z1w5UpjyfrIatbUGnRlqAWmgP3x3eUbEoR8erReKCkArNBgM4267hVmPQFUkqIid5FhJ4MfHTTNu1O24WHReDBpRPC98+bMefkgGm6EkGjXWpZe0ZcylVhq2AVna9mfn/kMJOEt0/DBxeEd04baenPH74qFE8NhhoZtkaVqyebcO2x8jffKF/OtK8ZCzw4PwYXJ4WxPsilzJfL9x21cnDYByLIeUXbmiRsi2Dd/jmpUJiWQ2QYOji8ipCoVRh4JhQezMPZMVjaFG7Nt5cBqGpTevmU2UCEahu09gBpI1m+R71y1vZaabQ0cyj0xRmGZrgpAncWTD/1IhH4Fifz7hkjWdZeE9IJy+qLCYqq5SEKwolBm6Lb3IX5dWW2jet8ZOv2TM/20yseb5w03dhgFIMTa5o6RlRlrIZQrCgbBXOVv7tgmqvP7tF25JDvwdlxuHJSODVikT3pBATe4UxPHRxecQzM/pwT/Aset/qEtohSOktOVM+6t6CDw7chUVxMKhDyaWVywKow7y3BdrH12BKwStbXD00btVuKJuYmov9MK8lA7M3rtU+y4nev70MKsexCqJuSjvfbZOBXM/B4uXU/pcPijZPw09etAjTZNNWWiMhV/XWK1CNuBvNQG4FSRdgtm9v6g8U2zWo6RDIwHdtbp4R3zwiXTsBYn7nyZ1MNctWumWgMrVeujFxt7sKTdfjqAfzVNyFXZ9onV4IR/z9+A96eFkZ74+oVjQBsBweHpyFANsjxHhwTwfJr5BGZdu9CB4dvo9nYM50U+nLKySEb11/fVr540F6GXTW0SbdP76h5Y0kcRQP5tAU6+2L2d4chWUmRemh1IoCetNCbEfqyIR/fhgeLnU8YtoJkYHqg758XvndWODliJqDx5GDcGmxUsOzvySAiWT1wbsxIlgClinlvHRfJEjHN0tlR+OCi8M60cGoUhvMWlpxOGLmKCUtn5Moql9XYiiHy57q3YHYev73TWgzO08il4fWTRmJPjViFsJ4e0OFaHRy6AkKqWvPegvD/bvUpbRGsms+4HzLU/socHF5u7BdR8iz4npD0rYox1KNcmYJqzaNcDfn0rhGnVlFTa9cVK0qoUaAyggdIWkkiNl3YQbswfrzvgQQ2seh7RmoCH3Ipj6Fe5cYj81iaXztaIXkcgnzphMXuvHtGmBqCgZyQTalpl/Yx5GwEbUdtzpRlLV46YQHXiQA+v6/MLBmhParMQ0+sqjY1ZJN3lyeFixMwNWyVtFzaqpeBZ8MEnXpdWXizUK0ppYpNZi6sw9WHym9vK5/e7Yxc9WTg/bPC+2dNIzaQj3yv/M7DxR0cugYqgaDn1OZAWvqp0hbBkpArCM7B3cHhGYhbV3EAdE/GNmQR2NwVHq+2p8cCaxM9WoaPbyn5tOmvYlIFkITOSVZEVmJDz4zX8PTqycDkkPDapHJ7QfjqgfL5A1jZPHx1SDB/qPfPwh9cEi6dMLF1X87sA2JR+7NeT1wtxDP9EMBEpH/ry8LZMeHjW/DRbWWtzTbafvA904e9NW1t37OjwuSQTTzm01ZtSwT2OO8QZldxHE41NMH+dhGWtkxz9Xc3lL+51plPlyfw3hn4h2/AlSkY6YnDxc0oN/6+dXBweAYED9VTn/3PBEBLJi9tEaxAvAshpDpanIPDS4x2WyeeRHE3SYmct5W3Twu7FWv53Zprz4dJMYdx72uLeglVqI3CcK+RrnSk/+qYZBGFDytI1DJK+OYsn0/ZhOFQj1Vrbs2ZgWqlZgaiu2Uz6KzWIr3WU9U+ETOwTASQSRiBOjEElyaEi5NwcUIY629YGiR8a4ce5CYekyzxTAjvRYavgSdkU5BMKMN9wp15ZW7VyEq85krN1hsfx4+qdn5UMQs8W2c+bdWp0T6YHrFw68lBsVigrE0JpgLB9w/fZtMmQXupomwVzOLjqxnzR/tqBgodkKtM0kT4P7ggXJo0jV0+Y78ABE0VQtcedHB4NiKrm4mhBD5HTbD+6kOCGpwTJNHh+hwcugJxNcAXAV/JpoRQ4dx41NJKQrWm3JwzMXurKFfNvLRYiQOVYxJiNeu4GtGp8F0AFbNssIqWkIwyFnsyMNonnB+HD85bzM5O0SwDljdhcdMIwU5JKJS17tyeCCAXTVUO9QgjfTDaC6P9JrAe6rGKU7295jcMRVvZ8BtaMiEl5hOWiNqzfVlz1V84IyysK8ub5hW1um3r3i6acSeRniubNFJlmY2WHzjaawHNvRnozUFfplGxSiUa642z+w5LrmohlCvKVhGWtyxC6a+/sdby2nb7lcNM0rRtP74Eb58WTg6ZfUTcGnSROA4OrUFBFBntK+so8LCV57RMsN46T7ZY0Cn3dnRwOBiNVqGQENu4Y5SrQqFsxp6356wC1CriduGvrll+YBhGGzsKEUnxtDPhux0nIlseeKp4CctCjLVOAzmYGDALh0JJ2C3Bxi6s7wjbJdgtKbsloVy1158M7LUP5ISBvE3Y9efM2yoXE5Ug8mCK2mudONUTtWWTYmQn4Vs1rC9rJGl6xMxUN3dhfdec4LdLEcHC1plJQjYpZNNGKAfz9vx0wj5S0UcyMHLiexpdL+nYMgNicmUmojG5Wlw37d1nd5WvH8LqVvvkKhWYoP1HF4U3p2GqKXDaObY7OLQNQUmVA97hqAnWTol8oIy7CUIHh9YQb/x+ZN0Q6yI1bLSxwlC52tJbtYFKDa7PGpkRMWF3TE48tP71Yd6rElWyRI2w+L5typkU5GtKLWq1laOQ5HLNKmyV0KNStf9XNW1YEJGddLJBVIyk2HXwvNZaggeuFxsASPhxQLS1DvNpE3SXBqBUhlJVKFVt/XFYdBBNUCZ8W1sqsK9TiUbrsL7WuoD98L5Rse6pGgrlqpGrlS24Mw+/uq58ek+Z62AiMpuC984YuXrnNPXKVTZp18WRKweHjpDQ0Hu31UnClglWCkZqIm6C0MGhDTSL3pOBRbsM99nXIRK11Uz43q4L+aMV+OR2nF3Y2DSzKASNCbzD7KN1fRbgRbYICV+oqaKhEKpSC4VaqNRCoq+ppwXHawo8q/jY5yjyJ678SOd2Bs9arxBV4RJWHUsnzPIgbFprrBeLn+dFOjbfM/uL+O/1+BjZez0Pu95mzVW5ai3WxQ1z8v/svvLJHYsuapdceQKXJ+HHl+Ct03By2CpXmSZPMQcHh/bhga+qb+jP8OWXHGhe0xLB0g/x5mucR0gefokODt2FPS2shH2heTgVwvfO24b3t9eVO08aLatWECrcnANQkgkIosoEecg0VbL221DbsZ2oV4fi5wh49geqVpdTNZ1ZHO2iTz3fi1p3DUG1HBlR2W+9MfxorepBoBJN6Um9chVXkOKClBCTQqmTtOZm61GttaG50vq04Mom3JhVfnPTbCY68fJKBjG5Et6YNs1VXy6qXPlyKPsIB4duh4p4ioyu/mEtxy85MKCq1QqWF+Jd9MA/5PocHLoS9XahGMkS0XrGYMITdoqwvmvBxe0I3ys1uDVvWqFUoEhEeAZyjUoW3t4A307H8fdMBhIVqTzqhCr+4aCq7FWAfVsT9iKqKM3VLI3+ovF6kL3k6qnRR2n6y1EvVVVRlTq52iqYoH1mGT69C//fl8r6bvvH9T0zXP3p68L754TTkddVNtkwPnXkysHhUBAPHdhN0ANHRLCugTeoXFDwnQbLwaEz1CfeAAIhn1JrEY3AD85bdeGzu8qdhfZIULkKX8yYfUOxYhYO8fOzRI7vXqMaclTkpn6cp0nIt07w+/+h0Uy26uvZu+gXso7YRLSmEbmKpgVvziq/uwcf39a23P5jpBI2pfoHF4W3p4VTQ3HYtCNXDg5HiVAZEJ9cK49tiWD19uKrJ+dwFSwHh0OhmWQlAhv5V4U3TkE2LaQD0+M8XG6PZO0U4csZ6pE3qg1NVsPnygmbf5+ITURrTSaiq1vwcAn+/hb8+6+Upa3OKozvnIY/uCy8eUo4PWoTkNkkJJsiexwcHA4PgV4Relp5bEsES5JkBR1U9zZ1cDg0YpITeAKB0hNlI4QK5YpQqcFvblrUS9jGZlsL4ZtHZlJZqpiVgMG8uJJN73b3Tn6xqGuu1Aj0TskqV3fmLVvw07udkat0wmJ7PrgAb0aVq8F87IZ/NIMODg4Oe5BU5QTw2UEPbIlgBSl6Q+jBvU8dHI4EzSRLAiUOoBIxYrRTgqVNbTv7r1iB64/NRX4gB423rO3cCT9qF7pN94VhD7mqKNslq1zNLMHf31L+LiLT7ZKrVMJI1Y8uWsbg9EiDXCUduXJwOA6IiniinGnlwS0RrAr0+LTWc3RwcGgN9XahJ6QSsfjZJgl/cE7YLVk8ytJme8L3msLtefjLr42g1UKJXRMgZQJ0z2tjjNChY8QmojU1E1EjzjCzCJ/eUz66rdxbbG96FEzQfn4cfnAe3j3tyJWDw4uCKB5403Dwm7YlguUJPSj5Q6/MwcFhD5o1WamE+WSFCldOQhB49GetwjG72t5xd0vw8S2LhakbekYWC5JUAp5t4eBwNIgrUqEKlagtuLoND55YCPVHN22goV1yFfhwYQI+uCC8NS2cHI6mRpvJFY5cOTgcEzxEp1t7YAuQkFEQ54Hl4HAMiIXovtgGmUnaBNjkAJwagZHezibAagr3FuCjW/D5A+XRCqzvQKFi/kuhdm7Z4PB87MkWjMjVyrbFHH05o3x8uzNyBWYYemIQTgwKg3mLHEomLI/xKE1bHRwc9oGFcozqz0kd9NADK1h/8TN8PE6jrZExBweH1tFszGmGncZ44k0y8KIA4pRNCraLcg1+e0fZ3LW2UjI2HwUySSXwBQ+3IR8l4mnBUJVyzaqJq9twdx5+d98qV3cXoHqgD/T+iCuSRCQuDIUwVMJQUZEjt+NwcHDYA1Gk94GvA8DC8x54IMH62Z/iLYTeWXVvVgeHI0NcOVIalY5qTSlUbHx/bQeWN5XlLShVrLpVN8xsE+Uq3JiFkV4ll7YA6rhqliYmWWZG6nA4xCaioSqVqrBbtjbtoxX44oHyl18r9xYsHqdThKGZ0j7ZgJF1IZW0WB8FNKEW5NzUJnS31cHhaOEJ+bTPIIclWHdKeNm0nhbX0XdwOFIotllWa1CqQqEMm7uwsG7u7F88gOuPbHNud5rwaVRq8Pl9q6qoikXIRG/pDICPq2QdEg3NlQVJ75ZhbRvuLcKXD5SP7xyeXAFs7MIX92FtW1nZhrd2hEuTMDEAvRmrdiajwGsvctp399XB4Qih5MOAgYMediDB6vNJVJGpo1mVg0N3I9bmNBtOFss27be+C/OrcPeJ8ts78Nu7ysbu0emk1nZMj9WTDskmvfp6yEIasQ0Ztxl3gvi+hpigfbcM6zvK3CpcnVH+7oZy/fHhyVWMYsVI+OKGsrKllKtCqSKM9kF/TulJQyqKyPG9SGzrpgodHI4KWUKGDnrQgQSrXKPfS9J7NGtycOheqFp1I1RrB5YqZsWwugNzq3DviXJ73gJ/7z2xatZRa9BLFfj0HlTDkGIlIlmYD1c66UhWJ2horkzQXixLvS349UP45I5yY9a0WEd93rUd+N092Cwo95/ApRNwfkwYG4CBnJJNQSqI7qtEmZDu3jo4HAoqBKJMHvS4AwmWphgQyLhhIweHzhBvwBpCVaFSVQol2CoauZpdgS/uK5/cMfFzJ1l07WB+zaYJAz8knzKljir0i5IGJ3xvA/XKlUK5phTLsBZVrr6aMUH7VzOHb/E+D5sFI1nXHytvTsOPL8LlKWFqCAZzkE8rmaQ5u9erWbj76+DQMVR8xJs8yAvrQIIlHrlQSbk3o4NDe2gWstdCpVoTShVrB65uw+wq3J5Xrj6Ea49thL/TybJ2USjDb25aResHFyzLTgBykEHBCd8PRDzxGapQriqFsrC6pTxahc/vKX9zTfl6BorVF7OeQhl+dxdWt5QHS/DmKeHsmFk6DOQgl1ZSCSHwFU8ciXZw6BRiQ7x9Bz3uYIIFPQLOA8vBoQ18q2pVEQoVs0tY2rSA3y9nlF9ft2DnSvXo24EHYWUL/uprZX1Hyac9kkG04WZj4bvbhJ8Fu79W+atUlULZROcPluHL+8rf3lCuztjwwotENYS7CzC3qtyeV75/TnjvrHBqGIZ6oDerZBKQCGx6NJ4ydLfYwaF1qBWCBw963MFO7kpGIeHegA4OraGRPadUq0KpCttFZXUb5tbg7oJy7RFcfWhaq3YCnfeDJzYxZtqu9p5bqcHNOfjtbatWqcYbrpIWO7gjWXtRJ8+qVKpY5WpbebwCVx8ov7mpFrrdAblK+JAM7L6UOyRnik0w3piFYkXZKMBrJ+DcOEwNCgM5yGcglTCS5TfZvrv77ODQAhQBPfwUIULOszhaBweH56Cx8VpLsFyFQknZKAjLm0asvpyBryNidRRaq56MOb33ZqxFNLNkE2btYGMX/uaaslOOyFrQ8MlKJQBvb+SD24TtHldqds03CiZov/rAYo2+nLF/bwcC9OdgegTGB4SVLeXBIixvdl7ZrDVVs27MWrTOO6eV0yPCcAg9aTObTfhC8FRskrvHDg7PgRV/ew562IEEy1MGVPCPZFEODq8o6pNkobVpSmVhu2Sj+vNr5n/0+QNz8n60fDTnHMjB5Sk4OyoM5IXNXcUT20zb3ZSXt+DjW8pgTsgk7PVI9FMkGZEsZ1rZmBas1KBYFjYKyvwaXH8MH98xPV275ApguBdePym8eUqYHITVLeHrHuXqQ8uhPIxVR6Fs66tUlVJZ2C3BmQoM5aEvJ+RTkE5aaoDvu3ahg0MLECD76F+ROfkveeavys8lWAryRBhw1SsHh/1RN5eMiJVVNZStAjzZgPtP4Hf3lK8eKrMrVi06LPqycGYUXpsSLp+AiX4hmVR2CjCQE0Z6lS8etF8hW9uBv/5G2dhVfvKah3faXlweSCcE39No8+3OLTieFqzWzIphY9fI8tcP4VfXQj692xm5GumDH12wYYNTw1aVLJRhfACmhoRP7xpB3zhkxfPeE1jZUm7OK1dOCK9NCecnlPF++57KpISkNuKTwBFqB4dnQZRUOkc/dEiw+BBRpb9Lf546ODwXzYG+lciNfado5qAL69ae+WrGNDlP1o9GxJ5Pw5unrN1zadKqHT0Z8EUoVKAvZ18XK8pv77Zf+Zhbg52S6XN6MlKvzAmQSgji05XO4HEwdjWqXG0WLKrmxix8dCvkywedkav+HLw9DT+8KFw5KQz3mAarFsJwr33dl7XHfXbPhiQO8xrWdmD9HswsKYubSqHsUSxbsHhfTsnF1Szf2sVOf+fgsD9UJKEJzT/vMc8lWL+8gvxkwxs52mU5OLzciHVWoUKtFmmtoorG4gbcX4Sbc8o3j5Tbc7CyfbjziVg7cHoELk5Y5eHChEWj9GUhnbBIlFIFEgGoCltFqNSUW3NGmNrBxq6ZY4Lyw4umgBbUnMAF/ChouFs23ga5UooVawsurNlwwN/fCiOjz/aP25eFH5wTfnQZLk4K431GjhOBhTdnkpAK7Ot82h7/9UNlbu1wpqWKTZD+9i6sbIU8XjFyd3qUqJoVTRomBF/Usivpnvvt4NAKBFK1Cv3Pe8xzCdbPriHzk9rn3lkODg2dFXE4c6gUK7BTjLVWcGNO+ewufPUwqlodsmwlwIkB+N554a1pOD8ujPZCf96qWamExaGATaD5osSUqD8H//4r5Tc321/H4xVY3LBpwp6smDYnErsnA4tfgVd/022uUpYqsFWw+3pjTvn0jvLJbfM0axfJAK5MCX94RXhzGsb6oDcbuel75q2VCJSEbwS6LwuTg8KFcSNGn97VQ5uXrm3DZ9vwaFlZWFfeOye8dkLqLcNcWkknhEDtfseVzFf9njs4tIhUeIAX1nMJ1jXwBuRgrwcHh1cdDRG7UqsJ5ZqyW7I4m8VNuLNg1YXrj5U7R+TG3peFs2Pw9rTw1mmrMIz2GrHKJCEZmC7Ki4yMPMGMQUWRaBpwq2C6m1tz7dtBlKvw2T3IppRiSQhPgPSbM3gqAN8X0FfTjLRuEqtGpEtlsSDuDfjmkTm0f3qvM3LVl4V3z8AHF21IYbwf+jKN7EAR8NQqR54ofmTdkE1Bb0boySqDeeHGnPJw6fAu8YubllG5sm2VudemzDdrrC+qZqWEVKDmAt9l1UsHh2dBISlK5y3C5CACcmCgoYPDq4x6OzA0Q9BiRdkpWdzM7CrcmYePbimf3zdx+2F9rQBOj8KPL8HrU8KpEasqDORsk00GFmfje0ao4r3O8yABZFNCrPh653RkOZxVPrnTfiXr0Qr8v1/Y603GnkkKZCCFtQtf1c02tmIoVUxztbABt+eU392Dj+9Yha9dBD68fRr++A3hylRDQ2cO60aSARAb3fZ8u76BB4GvpBNGsiYHLHfw+iP48oEZnB6mWrqxC5/fhzvzyo1Z5UcXhddPWdtyIK/k01ZJSwRq9xxXzXLoboiSJHh+TvNzCdYgpEpK1oncHboNcSuwbr0Qaa12SiYUXtqAxyvKzTm49kj5+tHhq1aeWGVquAd+cln40SVhehgG89CTkT0bXLwR7/EuAohIViYiWeGI/U81hOVNi1CpPT8+aw9qoTnPf35fGcxbm9DEWEAaUoE1jjzv+cd5mWCEWqnVoBiRqyfrFsL92V2z2ljabP+4+ZRprT645Y5YEAAAIABJREFUYFWiyUHoywqZSFTuy/6EpS449yDhC+mkEZ6BvDDSY63F8JqtsVTtnGhVa1F49H0LrV7fgfMTMD0iVs3KYSL4RPQ96OGqWQ5dC4UEFZ5rNvpcglXM0ye1FsxIHRxeIewxDK1BJbQolJ2C+UXNLClfPYSrM8qteRMMHxbphDltX5kS3jglnBk1EftAHnIpIZWwKoYnDRPQ/eAJ4EXZVilhIFTCIajW7Emf3DZRdrsu4Y+W4T9cNd2PqrWKJNJ7JRNAyCtBshrVSqEYaa7m1+DWrPKrG8qvr3VmtZFPww8uCD+9YtYakwP7k6tmchTfZ8GIbVytTARCMlDSSTMLHeoVzowKN+fMN+vWLFTaINFPo1iGT+/CtcfKpUlrZ759Wjg/bt5Z1SaDUi/2R8MRLYcug+CF3vPNRp9LniolhpMBiaNdlYPDdxd7DEMj64XdMmzsmPXCzJL5Hn12z9zYO40zaUbCh9dPmpD9zZPWHhzMN7RWiUhUXs+NO2Ajk0iPlfSBdPS6sI084QlP1pX7i+2tsRrCg0U7rk26RefqjdYT2Em8l3iTjU1Ea6GRjK2iVe9uzcInd+F39zojV7Eh7A8vmMXGWD/0ZyGTiknzt9fx9GWMiZbvga/gJakL4HMpGMzBxIDQnwffU27OHj4HcbcEV2dsgGOnCOWKMD1ivl3x+pN+VGFz1SyHLoOC+HqIFmE6IFWzX64cHF5pxNNiyl6t1VbBNtm7T+D6Y7NeuLNg4uZ2c/+eRm8Gpkfh8qTw2hScH4fJAYmqVlYZCqJWjETap1Y2sLhV6IUmhCet9a5eLRTWdiB1U7k93167UDGC+avrVtGr1iSaJjT/pFRCXlrH98a9V0oVYatogu8bs/DrGyF/d6NzQfv75+BHF4U3TgoTA9bSyySFhNeo+sXX63nBy55YJUsBT23AIfCERACppJJNWbVzpAeujlke4uOVzvy5YlRDeLAEW0VldlV545Tw+knh9AgM9zZrs+x7wYu+SV+y2+/g0DbEhrUzz3vMcwlWKCQlxL1bHF5p1DdXjbVWwk7JDENXNuH2Anx2V7k6o9xfOjyxEqz19/pJ4fvnMDFxf6NqlY6myXwvngxsemIb54gnCxOBkGuyOa3UrOVYqljeXTuSnWoIt+agUlHyKcilpf58ERPgv2zVjOYhhlJF2Cooy9F9//Se8ts77ZMrwQKVX5uKMwCl4VvWRK7avUYxAVOsXZyItFmBb5N+mST054WxPmFiQPnkthGtdvMpm6FqmYgfbcPCur0vtgs21Rprs7Ip8+wK/Egf2EKl1cHhZUb0Pnxuh+/5UTlVUngvddXfweGZaLZeCFUoVzVqDdkG+2DR/I6+eWQ2B0ub7VV8nka86cYxN1emTNdyYtCqGtnYesFvmtQ6xJuvXg3xgEDIAqrK6REIa8J2wSo2s6ttVrIUZtdsclKB988J3gSmyRIhgb404/xx5TIMlXJUuVrchNtz8NHNkN/c7GxasC8L754VfngR3jgpjA8YETkMuWrGHqLlY3YOnhB4SjIwspNLC70Za0neWVAW1mGr0LkIvhaaie5mQZlZVN46bZrBk8PCaJ/SmxFSCa3bh8RZlt/17wEHh06giqh6SXj2D8/nEizPIwi7NXjM4ZVGnVyptbpKkfXCxq4RqQeLyt/fVv72ulUvjsJ6oT8HP3lNePMUXJiwikZ/Lq5aRdYLYpUJOLqNKdbuJAMgLYxEO6wi5NLwl1dNrN8OShW4+tC8kzzPWlNeVDHLpuwHy7Om4r4riG9pXLnaLhmxvv8Evnig/O0NmF9r/7ie2PTdH16Gd840jDszkYmoHOEwQCyMj+0yvJQR9GQQabPyNjBxax6+eqB8NWO+V52iFhrhXN40i5KlDXj7DFycgJFe+37OpoxkJZw2y+GVhiCi/vMe8fwKlpKSRu6ng8NLj3o4syq1UCyc+f9n781+I8uvPL/PuTdW7kwymcxkLlVZVaoqlbaWND292I1uYOZhYL+OYMAG7LbHkN0zEGb6xY8uwE/+BzwYzYJ5cBsDDGC7p2G71d3qlkbdakm1SCrVXrlUJpNkct8iGOu9xw/n3oggk8uNlcng7wOxRDLjLhG89/c79/y+53ui5cC1XXi8AR8tKZ8smUZpowcVgmM5mJuEX3tB+MZLwkvzZi5pWhzIxvqV+Km/x5NRrN/yPRMlj+aEUNWCRhEKZShWLJPVDqHC8pYtn45moVK3Fi8z4xZkkVJQeS5T4I1l4aiQoVAx64XPVuDHnyhv37eMT7uMZq1g4bdeFV5bEK5NtTi0R3YLvc7qxPvyAPEUSVkmK+VbRmksZ3/z8bwFeu891q61WaHC4pYtqW/sw9Km+XK9GJnhjueVXEbI+IofNY92QZZj6JAulghFyKjLYDmGgNY2N6HGFYJWHbV7YIHCR0vKOw/MSHJzvzdZq+koa/W1F8xP6Pq0+VyNRuLglB9lNSLRVD8noTiTlU0BebNZ8MSE72nflvzadXwPFT56AoFGrVs0fg9moCcpmnqcUwTcg6LVob0WFTMUShYk3H9qLWh+8IF2lLmSKHP1e18WvnZHuDljAc1IFFz1O6MXX0OxAW1erNIwm7ZAfmrE/KzuzNnf7P3HypOtzpcMw9CWijf2lY+WzM7h11+27OyNaZgaNeF9Nq1NY9xD59pEXZbLcdEQBNHMaS85PYMFaRGkB/OMw3FuHPK1Cs0wNC7D39izSqsPn5gT+4dPzKG9GwSb1Oan4Uu34LdfFV6+DrMT1hIln7E+c1YhaEX58T2mIdgdF802Gv2sLdGJnvQamrPUca+JvvE8Ie0ro1lBx5WXQjvrWgB7B8pKmz0U98vwwWMs5R2J3FXFji92LC9qGK3x+2go4/v0XoXDs3bLazTKXlZrUChbcHVvRXnrPvz0M6sebJd8Bm7NwG+8IrxxU1iYMZ+rXNpsE0QEjd9/v98rpodrLBt61ksyk7aAZ2pUuDphmbWfP7R2O92I4Ct1y/6+c9/aR63twesLcPuqVTTa8qg2Kg2Pq4h1wZXjQqKnx1BnBVhZcEuEjotLa7PeeqS1KVaU3SKs7loZ/lv3lA+f2LJJt1mrlGcGoa/cMBH7qzfg5gzMjMN4LjIM9S0ACUJr6tua2bG5pznb2PwpzXmU+LVHf3f8azjyu7goWNXsH7JpYXpUuT0DlRck6j+oPGqzWrJcgw+fmD9Wq/VAGEbaI59Gz8TW81GabVdOeh/6zPtI8nm0vNfW1yiEoVANrEn3+r4VM/zsM/iz9zrLXGVS8bKgx1fu2N9/NCsNr7BQxQLnOEOph98HPXiv8efYRKIHC3tt2rO/gwikfW30Nbw5I/zyYcgHTyxI6qaIY2MffvQRPFhVHq4Kv/aifS43o2CzWWnotFmOIUHoIoMlZMUePh2OC0WjOiwuv69DuarsHcBmwQS6D9dsOfDt++Z31S2CBVKvL8Abt61R8/Up02B5QC2wqrtKnUZQEW9oqzvNKdYSEpZtae69mQmJXwOHbRaE5o4br2md1VsI1YLOQM1za3bClnf2y5bJarcdTKlqbYPyaVuaUjWrgMkRC0L8I5VzrcNK/L7sHFtTHEc+jyPv45nPo/FeW9NkHApI6oFlMHeK8HAd3nukvNWh5krEloFfnBPuXlOmRi1LE0Tu/9U42Dz0tp59H43z5pn/O/bzan1fraGaiOnr4s+jJXHZuBd8z9r2XJ+2/oaqQqhWYbq22/1DxtKWVRruFJVyTShVhRvT1mppLM7gRgal8X3gAi3HRUOAULvQYKWETKDPpUbV4TgRVbNdCEOlGkC5KhTK1lvt0Tp8smzeQJ8sKev7UKp0f0zfMx+rmzPWuiSbNn3PXsm0Pmm/xdMqmuxix3Uk1udoc+UnmvCaMYdGqWRtaMlOQ6Q14xG9+MgcHgeg9YCoLYxtN5GzZZ2N/fb1OXsl+OAJhCj7Zbg7Z0LvfOQ83noOXosmR7X53uNgoRE4NTbTZ4KMo6+xCMY+S42Cx/gf44GsHth5ru5YteBb95TFDpsl59NWwDCShWpdGs2+dw9otrkhyd/j2QD4KHr0+3g3nrYEKfbLMGy+JqT1c7avemhdCMJQGM0qC1dsqbdat8Cz2yBrvwTvPYKtgnL/KXzljvVhNL83ZSwnDW2WFz3FuyDLcZFQe97tYokwJP1M5tnheE5pBA2hUI+0Vgdl2Dmw8vvFTeUXD+Fn96zNTa1Lw9BWculI0JwVanXTdu2XlIwP2YwtHcYTWxhNcnEDX8+zAMv3mu8jDA9P+K2TT+vk2prwaWTCmjP5qTdvfB5B1BaoFlh7lIMq+FEblk4qzdZ2baLeLtiS28KVlgALm/A9mu87POacO53f40DDxPv2eYuCtJi21gILIpa34N0HtjTc6fEyacvO7ZfM2mNzD1LRqBoHMyKHg8njiP+mh87jhA8i/rvFePKsKW2crQrVrqXGLqW5DdhrimX7G+TTwkTedFTdaLJiyjW49xQWN+w62C7AqwvWbmdmXJnImzYrmxLUa35GLtByXAgEVLtZIlQvK4hbInQ81zRF7Ja5qgVmGFqImjM/XIMPF01n8umyefcEXT6hH+Wgap5JuwemX8q0TLJx/8A4o6Itv29Mjl5T7Bhoc3KGpqYp8u6MgsiTz6V1mfCZ37W87zimCVozPdgS5n7JvK46ZadowdrSlk2kflRF1zrhN5oZS+tyZvOzOZpRasSR8Wt4Nv5ofU3rZN06aQehnVtcQdrNpbBfsurDpzsaVYU2/05BaF+xP9hRjjvuSVm04wKweJfxZxgfRzz7jI8GWK1Bnkizv2WoFnTul7r/ux9HpW7ZrLVd5eGa8tU7wis3rMpyZgxGc0o2LaSw5ZJ4wnGBluM5p8sMlpBxbaUczzON4CqEeijU6kqpBnsNw1DLWP3HD03U3o2I96zzKFbsy2FU62Z3sdkDL7HnlSCEnQP7cpxMLYDFTaswXNmxpfmv3RFuz5ltyXhOyWeFTMrkc04E77gIaDetcnxxTu6O55NWP6MgVHNjr5sX01ah6Wv13iP4YNEEzL3wtXI4HJ1TqVkWuVQ1e4zXF0ybdfMKTI8qY3mrbE2p2Uwox2f/HI7nhM6d3APFdxksx/PG0QrBah0Oqsr+gZXdP1w148Offmpu7JX6eZ+xw+GIKVXh3gqsbJkA/jf2rV/jrVlzgZ8YsabVmZSJ4GORvstmOZ47uvHB8jwqWEeNU6M0h2MQtGatQlVqdSjXTUuzuQdPdiy4ev+x8vETeLDWnpeTw+EYDKFa1eKny2ZfsrmnvLpgbaRuzgiz41GPzkaloW3ngizH84TAqYrFs3oRVo+tjXY4zoNYKB42K952D+DpjlUrfbykfBQJ2fdKbknQ4XjeqQWWzVrahPurypdvC195AV69EfU0jPp1Zvxmla0LshzPDdJFgCVCTbWrIhuHoye0WgpU60qxAttFeLJhbW7ee6R8smxtb3pdBeVwOPpHGBWIfPjEDG4LFeu48NI1M0OdHlVGoy4IflRt64Isx3OAKpwqQDmjVU5YQzync3ecK412N1GD5riH4KN1+OUj5aefKp+uQKHcmVmkw+E4f4IQHm+annJjT/nSbeHLt4S78zA3oUyMWJAlLpPleB6wKtdTnQJPD7Dq1MV3GSzH+dEqZi/XLLha37N+Z7/8HP72U+WTpd6ahjocjvNB1e7vrQKs7lhVcKUO4YIgYtbZkjZPNWfj4DhvutJgiUcZJXQJLMd5ogrVmlKswsqWNWj+2X14+x482XJCdodj2AhC87ArlJXtghCG1kjc982MVNImfHdTk+O8EOlyiTCEmi9OK+w4P+JeeZWoR9q9p/Cjj0N++qmZFjocjuEkUDMH/smn1jD8yriQ9a3lku8p4kvDtd/hGDRR44kulgihdnYLUoej9zQa1apSC4RCGdZ24P1F5e373QVXmZQ1582kYLeY3Ccr5cH8NFybtMqmVGOwj1qStDQWjhs6gz15e9Jc7uyNTqybjn295Hk5j0Fw8d9r3Ocyvjbjljkpv1mh22gLGV2z9cB6OpYqsLxtvSaTPnWL2H0TL/N3wu6BaS1nxq1f4ki2GWS56Mpxnqh2kcHyoUzUi9XhGBTN4AqCQChVld0DeLKpfPREWd3pfN/ZNNyZhflpa8tx/6nyeCPZ4D8zDl+5Lbx+C65NCuN5mzxaG+weGu9b+hDGfQZDOguwjp/au5xcehYvyKHvut3l87KPk/fc5eY9PrF2dqmt37Q0fo57EgZRk/G4b6FiAdZ+CVZ3rVn67oEmbgI+NWKtcEo1q/otlpO/r5hQrZ/oz+4p16eFq9EDTjrV7MHowizHoBFFQWqn3X2nZ7BC6viou3gdg0SwQCRuQluswOoOPFgTlra04zXr6VF4/Sa8PC9Mjlhrnc19YXHz7B2KWNbr5ozwynVYuALjuWZz3+aZP9t+WORoi96TWhS3/swxv2v3NSdtp0e+P+01Z+3nuP21u5+z3kcv3msvXnNx36sF9e3vJ1TrlLBXgvG8sL6rpNqwnZ4Zh9cWBBHYOVBzcN9p/yGjXIUHT80r66V5YSIv5DL2gBM3B3c4Bkl0S3W+RBhCzXNGo44BE9sy1APrWbZThEfrVi3YSePgfAbeuAVfvSPcvWZajnqgLG/ZUkOix/8oozaaU2bGhJkxGM9HT9HEA7wemjgk3lCitZboNce+4dY5vPU1rfP6ofvwuNcoz96resprNMFrzjpHPfKaLt7rie+5k/cqHXwe7b7Xs95Hl6/pw3t99gzUrl21kzj6Co0CrLRvxr6jufaCo7kJ+MINuDIOQSi8cBXefaDcXyVxFixmvwQPV2FlW7kyCiM5SPsWvMUfg8MxYE4tsTq9VQ7UkAsuOnBcSEJV6pFb+/oefLpiRqLtDMpelHX6wnX4nS8Kb9wSrk1aULRfEoplxU/4NB7PUbm0kM/YfkcykE6dMapHy4O9eUq5KDPI8/JeL8rn1QvOfq8nBkYSx1/P7kPVKvcqdcilTbfYzoQwkoO5SeHWDGTScHXCHkxGc9Z1Ya+UfF+1EB5vKPdXrZXO5ChkU4rnietV6Bg4IqphVzYNUMFpsBwDpOl7JZRrpvdY3FA+WISV7eTi2kwKXpwTvnwH3rgpvHIDbkzb4B5PNKM5a8GRZB4WgVwG0lEDWt8D3xcT2gIicjjhIC1JiZbfceTn416TZD/HvYYTtms99kn7Tvqa+LPo9ByH6b0O6vMYxHs96TVhCH4opDw1F3VpXRI/m9heYWLEviZHYDQrTI9ascj7i8rjdRPRn4WqCex/9Ui5PinMT9mDTjql+L64pULHQLF7Jexc5B4IFd/5YDkGiBJpr+pKsQwb+2Yq+mg9eXCV8uDGFfitV+E3vmBPz1fGbDDOpsVa7ZRteSGdSpZbEuLKJVuSkJZ/iQf1+HdHf2793dGfj3tNkv108prTtuvVawbxPp6X9/q8fB79fB8Ih5cN2wywagGgVlwykQcZgdEsTI6YWH16DL5fV5Y2k2XGCmX4cBFemDMt1uSI3dMpz4ndHQNH6camQWpsa5a6u2gdg6DZEkcp12DnAB6vw4NVE7onZW4SvnFX+PId4fasLUuM5SCTEhC1p/KW6r8kA7tik0UQKqEr+3BcFpQoO9vUc7VTZDKSseAq7dsDTSYFaT/KhnlQqQpru1CpKRt7ye7FrQI8fKosb8PshJDPqD0sCS7CcgyMSPd3qmHQ6RqsNFucscbocPQKxQKsWmBaq/Vd+Oyp8mANqgmvQt+D21fhay9Ys9jZcRjLQy4l+D6EGlX1RU/iknSyiMS+YWhrK06Y6LgUCMQKQo2+woSiEU+awZXvmW9Vyrel9biytjJvAdNeyb6SNGoP1To4PFqH+Sl7eMqmFV+kkV1zS4WOvqOohqcHWN5p/xgUKWI6LIejryiAKvXQjD/3D8ya4d6K8nQ7eUCTS8PdOctczYybziqXFlK+Npb2BGk+6HrJH3pVsYjMDd6OIeaQGF4BPVzplDR4iW1WAo2CMhE8sXsxlzYfublJePm68NqCcHU8+Tlu7sNHS9ZOZ7cI5Zpll12zd8egECEQ4dS69lMDrJs3CUB3e3taDsezmLjd7BPKFdgtwdKWmYAmbeTse/DiNbh7DWYnYCwnZNMmSJeo0ijWlMTZMk+STxgC+CKH4ysXbDmGiGcCFAFEmw4SbdwvYJnoar1FrC9EQZZppybz5in3hevCwkxyfVehDO8/Vj58omwU7DhxMBefqsPRT1SpKpxqe31qgMWHhALrPT0rh+MEgtCWCHYOrCXHwzXYLCTbVoDrU+Z19cKcVSnFRoStovTG+N3JMt9xGg83kjuGHT0ceLX9THHMPSLY0mEuY5WFN67Ay9et0jAJYVRR+PGS+WLtR8uLYehuScdgEKh4cGoC6tQA6wdAqOJa6jr6StNYVBvaq4+fKJ+tKOWEvlepFNydh6+8ANenYSQrZHzF8w5XCWpkyKhYQBcExzy1H3eO8Xm61ueOIUaOZqgiJa/EDxdtBDCCLdmn/Gif2vy9eCCipFPWW3B2HF69IXz1jjCeS7b/IPLFerhq1cYHFajVW3qCOhz9RKiqdrFEuP4B6gmbvT0rh+MwVjlo2qtiGZ7uwifLytJW8gaxIxnzvVqYFqZGIZfWSEx79HlbDg2+bcdLTj3ruExEa4OmkWw+aCTF85oVu1Zcoo3dipi9Qi5tmatbs8IXbwkzbWixdg/MxuXJpn1fratpsdo8T4ejbZRy3e9iifAf/ntCNHQBlqNvxMaitRAqVRskV7aV+0+Tuzx7nuk47swKV8bMZyeTirRXHBcTSbOKsA39lTXAbU4Qh79xOIYQBVqKQoTkgUtrkCON/zZTWfG9mUnZPXtt0vSTVyeTa7FqAdx7asUwGwVrKh0EELpMs6PPCFqtl7vIYAlocMYao8PRDXHZd7Wm7JetOujJpqX8kyBYv7M3bgk3Z03PkUubJUMsan92I7ViwDaDI//EHTocQ0pD3W60awHXsHTQVi1kcyeemHlvrMVauAILV+zhKAmqsLhhGe+1bcuAV+pWMBOqy2I5+odCRUa70GABELCFa5fj6AMalW/XIu3V6i58vKx8uqIcJDQH8X176v3S7ah1Rs5aZzT8cJ496qElwnbkGqE2Xa0b27gB3DHMRBms1uu9nUs+vr9UIg1jy7/Fui7PMxPSkawFWS9fh5ttVBRW6mZIvLil7B5AuWpjipNiOfqIAuUXHnXhgwWQTrHHGR2jHY5OaGSv6lZ2vbgBP3+gfL6WXBs1koWX54W7c9YOJ5+GVNzO5tgB2n4ZC+vbecLVeKZwOC4LR4xG2yWWAGj8cHLkhouXCX2v2U7n7pzw9bvmkZWUjX14vGGVhXul2BRYn6mAdDh6hUJR3jw9+XRmgBUqJVDn5u7oGY2n2shYtFy3QfHJpnJv1XRYSZmftKfdmQkzFU2n5JnKwWdp9shpK8DiSF82h2PYaTEa7eTRIvbmNQ5rsJq/tYxzxrd7eH4KXr3hcXuWxEuF5Ro8Xlcerilb+5bFqgfi7ldHvwglgXzqzMtXQ4p6RkNDh6Nt1CoEawEclGGnaN5XG3vJKwfHcvDSvHnoTOStGqlZsZToFLrHJbQcw44cFxYlJOFGnpidQy4NM2Pw4pxVBWdObebWpFa3DNaHT2B5x3qXVoPkY4nD0RaKgpxZAHh2gJViX9QFWI4eEi0bBIFQqio7B7C0BYsb1uQ5CZkUvHodvnhTmJ8y/UazcvCsqOdIJWBCjgp0W3blcAwnUdlgx8tsctwtcvgekshnyxMhkxLGohY6d67C9SvJtFiKPZx9sqQ82VD2DqBSVYJQnGWDo/cIepaLOyQIsFIBeyquH6GjN8RC11ChGijFMqxsw2crypMtqCdU+43n4PVbwis3hNnxWHulCbJXnVdEHd3e4Rh6Wo1GO93+uO+PwRMl5Sv5jETu7sIr8/Z9ksPXQ8uCL28p21F/wnqgzt3d0XMUVU/CM7vcnBlgVYtsi1LszWk5HIBaIFWp2dLg52vKB4vKZkJrBk/g2hS8PA83pmE8D+lU9CR85taRyF06Xd1za4KOS0SL0Wi3V36r0eiz/2b3r+8J6ZSaFmsSvhBVFKb8ZMcoli3IWt9rit2DsP2CFofjNEQJwoDls153ZoBVn+ZARNd6c1qOy0w8voVqT5ulKmwV4P5T004ktWZI+XBrRrgxHfleZSDlS0N/dSIt7qCdTxZHBLou3nIMM0eMRtu/ceTQ93KGmsu0WEI+Y4UrL80LL80LYwnb54RqGfHFDRO7lyo21mgvIkSHI0KFip/izLjozADr4BGhIp/35Kwcl5tIe1UPlEpNKZStrPrBmjVrTYInlrW6Ow8zE2Ku7X6k00gmvcISvJ0uGxw+iHsodgw1R4xG27/g9ZifTrhRo1/7YnrKiTzcmrVM9cx4svgoVGu19dmKsrwN+2UzMY6zWA5HT1AKQcD2WS87M8Bag1AIH/TmrByXmdiaIa4c3CrA0rayeqZUsMlEHl5dsAqjZvYqbmOT9CxaXaXbRU/90eEYKo4ajXa7q1N2FN+PnkDaV0azMD1qzu63ZiGbSXac3SJ8smw9CmMtVhBGWix3vzp6gAj71ZCts153ZoD1u/8zAfAQN5U4ukAj86sgFOqBGYuubMPienLfKwFmJ+DVG8JCZM2QSVmrjeTBUmceWEe3dzeD41LQpdHoIeJB4LTDSWw8KmTS1qNwbhJemBOuJexRGISwtAmfr1tlYWzZEHactXY4DqGoFCZqPQiwRFCBJ6g6N3dHVyj2JFmuRdqrVeXeahttcTwTvN65KsxOQD7SXnmiydNRLf0E281gtTbJcXIOx6UgNhpt4xY7RGumOO6NkyDMsYpCIZ+1Dg0vXRPuXjO39yQcVM24eGXb2udUqrHY3YVYju5Rwu2Z75ze6BmS9CIEfHMsbcNf2+F4ljA0Q8CDCmwW4OMnysNVMxtWfxdJAAAgAElEQVRNQj4Dt2aF69Mw2che2b8lHvy7kZMch4u0HMNOlFXqp9HoocNFcZjvQTYFEyNwa8ZaYk3kk+9nY8/ab23s2ZhTq+OWCR29IBSRxyS4uhMFWBVlX4VC16fluJTEgvIgVKp1K6Ve3YFHG1ZKnYR0Cu7Mwe1ZuDIK+az9zovKu9s8I6D9CkBnNOq4dLTYNHS6/VlGo8dvJqbFSlkhy9UJy15fm0p+3+4WLUu+uAG7JajWlSDKxrUGWc7CwdEWSkgYfp7kpYkCrEyNPdQFWI7OsKbOSj0USjUb7Ja3lc1T+5A3EeDqOLy2ICxcMafnbNQWJ4km49mzOfpdZ9s7HENPi01D1768bVglmLM7+KJk0zA+AvNTpr3MJPTEOqjCg1Xz2dsumi1MPdBnGsknba3lcESECJ8neWHCVpoUEPZxs4ujExRCFap1pVAya4YnmyZ0T4LvmTXDF65bI9jRLKR9wYtGxfYGR2c06nAk5mgGq4vLX+RskftRPE9I+zCShtnxSOw+lezBKlRY2YH7q7C+a7Yw1Zo0xO4ua+XoAAUNEB4neXGiAGs3oCaqi6CudaajLeL0ez1QKlXYLsD9p5a2rye8mrJpuDkj3L4qTI9CNi2kEtsyHEfvjEYdjqEmymD1huQi98YWUUVhNgOTo3B3TvjiTTMYTkI9sAzW4iZsF6FS16bxqMPRCUJR9OwKQkgaYGUJBfkUcJWEjrYJsYHuoApre/DpirK8rYk73Y9mYWEG5iZgLAeZVLPnYGepfY3/1wFy6o8Ox1DRYtOAfdurnZ79qijL7HtW0DKes3Hg9QWrIk56620W4PG6Zc73S1CrK2GoLovl6AhVttVLJplKFGB9Y5pQlQdqc6XDkZhQrXKnWodCBZ7uwMNVE6AmIePDC3OWwZqIjEV9T/CSLm4/Q3NEdUajDscZtBiNdmEb19xVBzvxPGyZMGNazDtzwu3Z5P0JK3VrnbO4GVk21IQgFDr3nnBcYtQT2QrLPQyw+BZhSPipB7WuTs1xqYirB+tR9eB+CVZ3lbXdZMuDAsxPw+s3zZphNGctNGLX9s6yV02j0HbH11YHLBdXOS4FRzNY7dJ6jyUwGn3m8I0slhmPjo/YmHB7VhhN2J+wXoelLXi0Ztmsck0jsXun3hOOy4uqari9EPYwwBJQD+6rqyR0tIFVD5rPVbEMm3vm3r6fUNzueVaWfeeqmQ3m01FbnG6qfuTYb7vZjcMx3GgXyR454ft2dyN27+fS1sHh+jRcn7K+hWeh2Lhzf1VZ34Ny1cako9WEDseZKKEiD+U7JLLHTrzQEvgUEF3u/Mwcl4k4QxSESrUm7JVNf7W6Y9msJPie+d/MT0nUFkfwPe2upLpFtNvu+HrsVi7ScgwzCoh0ZTR6eFG+/aY7prVUE7un4vY51p9wPKnYPbQs1tqOUixb65wgVOeB5WgLEaqehG8nfX3iAKvuc4DyFJdUdSRB7QmxHgilqj05Plyz5cGkjOfgxrQJWkeykE4pnnRTAdg8uYZAvu2dOaNRxyWixaahd88S7e9JEHxR0ikbC+YmrH1O0v6EAHsHsLprvU9LFQhcFsvRHqpQDar8POkGiQOsF3+fsoh87qwaHGcRa69CNffkuLHzJ8vKWkJzUbDGzjeuWEl2Lh2J27s2BTw8ora/KzciOy4RLUajPaGrZULB92wsmBmHF+eEhRkTwCehUoeVbXvYixtAB6HzxHK0gep+Nsf9pC9vqxZLw/C+KtX2z8pxGQmi6sFiGZa3rO9g0sbO2RQsXLGlgJGMDaJ+TxyXuxVhHd7IOUA7hpoog3X457Z3EH2nUT1iB6chTU+sTMq6OVybghtTkrgBdD2ApzvC0hZRNWFzmdDhSICqsDw7nkx/BW0GWCgfCSTsHue4vCihKkFgg9jugekfthNaM6Q8uH0VXr4uzI41+w72Lphp6SrYRasdcE++jiGnxaah+XPbO4iQqB6x85vGE3vYykfGo/PTtmSYhCCEp9vKZyvWpqtUhSAQQrdO6EiCoqIs0YYfaFsBVtrjQdQyx+E4FhONms9MLVAOqrBTNHuGesLLMpux9P/dOWFqDHKp5vJgT9YqpIuyc2c06rhMtNg0dBuGNH2wOrxpovvfi4xHx3JwddLaZyX1xNouwmcrytqeUqpCNVA0agDtcJyGigaq8kC+1acAq1BjD3Sp/VNzXCYUc0qu1GJhqbJdMMuGJIxk4PaslWJP5CGTtupBOu4fePjsuisEdEajjkuEAt0EID18AImfryyLZdKBmTHhxWvCzFiyQ4VqQve1XdNh1eoQuOjKkQBRqp6EH7azTVsB1gEUULmPm1Ycx9AQt4dCrS4Uy7C+B8uR5iHpRTOeN+f2uHrQvK96JLSVVk2IMxp1OE5FsIxvpzdfl0ajx55S7ImVgSuR2P36NIm7O2wXYG3Pim8qdXvwc3YNjjNQhFIY8Mt2NmorwPriOgcoj1ubqzsch9C4lpWoelB5sKbsJ1Tu+Z6l/GfHze8mk4rMBHsicAfpUQLKrQw6Lg3Rg9N5Go0e2qW09CfMw60Zs3PJJRS7Bwrb+9au66DFdNQFWI7TEChUc3zUzjZtBVjyJqESfo5oQi9ux2VDsZR7tabsl+HJJm1VD45mLXs1NWZC1pQH4vUuoDHfxOZaYzv7dUajjktHbDTK+RmNHiVeJsykYCwL1yZNTpDPJD+n7QNY37MHv2rN2TU4zkQVXXzx92kr9mm7ZW5K+BzloN3tHJcDVSuHrtRNf7W8razuJDP0S/lwaxZuzpj3VTYNvm8XaS/tEPQYHVZynNGo4xLRQ6NROea7tvchhy0bcmmYGIW5KZgaTbYPxZYJV7bt/0s165fqgivHiZgW8ZN2N2s7wAqUJ+AqCR3PEpuL1kOoVGGraPqrasKai/EcvHpDuDMrjOfMC8v36HGWSA/bM3Rp0+BwDDVHjUa7uBe7KSA8iifge0o2LYxlYW5CuHHF7FySsFWAB6v28HdQtYfCUJ32xXESGqrwWbtbtR1geSFbII/a3c4x3MT61TBU6nUoRvYMu23kOidHrHpwbrIP4vYG0lIu3tn2Dsel4ajRaFe76o3IPcYTIeUr+UjsfmtGmB1Plu3eL8HjDRO7H5RjHVanDRcdl4CSBGFiB/eYtgOsJx4FRN9pdzvH8BOqEoRCuWYD2HZBKSb2vLUU/9ykWGucjJDyBRHteUwjrX4PXRknOhxDTtdGo60IaC8ctaK9xQ2g0zA1ArdmhYUryTyxaoFVOG/uWwarWreHQ3d3O05gO6zzfrsbtR1gffPblITwPVGttbutYziJn0tDNXPRUtUGrrVdKCdsrOR71l/sypgZCGZSRH0He53B6rEGyyW0HMNMr41GmzvtCqtTkWY14YgJ3W9cSd6b8KBi41ShbAFWPZCGXYPTYzlaUZWlp2ketrtd2wEWoBryQIU22vY6hppoMApVqdVtwHqyqSxumNloEtI+XJ2wsutsxgIuryfGokeQZnAVQluLFtry3yO/dPSB1slO1fR98dfRf3P0iR4YjfbrGUTExoiUDyNRA+j5SSGbUIdVC2BjX9ktKqWKCd3Dbp69HEOLJ/r2N79N20mlTgIsgpCHGrKFuxYdEaoQBFCuWzuKh6vweDOZwN0TmB6Fq5PSyF71prHzcSdq/xcqEHY+ObsLPxmdBkCxaW0cWAWhGULGX0F42LvIBVp9pJt7UU/4vkfEAVY2A5N5mJlorzfhVsGWCguxq3v81OVwNNF6EP6wkw0TxvqHSRfYCSflQ0HvKpIwIesYZuJJsFqDQsmeDAulZJNeNg3Xpmx5MJ+FdOR9Bf0IsloWO9pc95Bn/uvoJXHxQRilFYOWwCoIo55xKILgeeCL4vkSVZQ1/5xCn4Lzy4hgDkB0bjTauMUaLr+9+eNItG8PIR2J3SfyViyzvJ1s7ClFy4T7pcjVXS2z7SY1R4ygBRHudbJtRwHWtSKVlUl9O4R/IO5avPTE2YMgNC3DftmyWOWECdXRrDkxT40K+bQ9kfYtgwXEU3FnD6pHpho3kZ9Kkr+hZaqaTXfrYRysK9W6XVO1AILA/maeKCnfSvIzvpJJCamUkvKsZ6WINFLzLtDqkobRaIf3y6GNWitLehRk0RS7Z9LKeF6YGbdrJEhwwpUabOxbxXOlZnYNGV+jWc1dPA40hB0/w3InG3cUYMmb1J9+N3wvVK+MkNQ/1zHEhKrUQ6IKQmX3IEq3n4EnMDlqBqMzo5BLg+9LnydGbWpD2j7OMUajbhzuiDjDYLoqIQiUWihUa1Cqmsv23gHsHJiur1wFREl5MJIRRnOm2ZsYUUazkM+YL1LajzR8Ho2/j/sTdchRo9EuPkg5/J+eIVFgnY1a58xNWsP4/QSe2wdVM0Pe2IODqlAPlLBFc+YC9MuOIujDf/GYzU627ijAAqgGPPBTuibIRKf7cAwHqqChUK8r5ZpNioWEDQVEYGbMPGwmRyGTFlKe0vvawcbZ2nHj43e0vRt1e0UQ2oRWja6dg4pSKEnDpPbzNeXJprU12SvZ9ZL2hekxZXYMbsxYef78pC0xj+eVkayQy0BKLbPhgfuTdUrDHbR7YVK/7hzB/s7plDKes2rC69NQWrOM1GmUa3adre5gflh1e1i0HbuLxkEYhvIXb76pCdIFz9JxgFXzWEzBMvASbvi6tMRi5ECVagDFsvX5KrVlzyBcnYSJEcikFM+LMlh9uaqOaLA62t7RLfGSsvmmmV5vqwBPd2B5S1ncUh6vw6N1c9vePWgWTPiijORMb3NtEhauwO2r8MJVYWEG5iaU6VEhn4VsOl46dPNlR7TYNGDfdrErPfJ40wMiuwZP1HoT5uD6tHBzRnm6A3tnNJmvB7C6C6u7yl5JIj8s8/0S9yzlUKqhhH/a6eYdB1jv/AWF3/778omI/iZIwj7mjmFEVQmi5cFCGXYLpp1JQjZlmYfJEUx/5bXoZ/p2xhZkdbZ/N+p2i8aO/6FQqip7B5ZB+HhJee8xfLoMS1u2RFipmf6qlbpGWdKSea19sqxMjMDdOeW1BeGNW8Ir15WZcSLT2qYuywVZbdIwGu0wsmr5vDVWvPcwcon34nsmdB/N2hLhwhXhoyU9M8ACK8zZ3IdiJdL6adSX0F0slx4R3RahbQf3mI4DrH/47wlX/n74ruD9FwouwLqENMvoTbtQqsB2UdkpQj1hgJXLmIN7PhOZi3rNZq79PPPOe6s5o9FuaGY8hUoUXC1uWpD044+Vn92zBrxJmoOHSkMEXyhbkPZoXdmIJssvXBd0BiYBySgp3wVZbdOt0eixG/W8NQMS2TXkMnBl1LJY4zllJeEpbhVNO1qtC/XAWX44ALsMltkjQZh+PB0HWAK6HPIhPvvAeKf7cVxc4kHXGjwLxYqyVTBRctLxaTQL43khm7a+Yl7flgYjDols21uwaJabH/mlm7ATEQfkgVpmar9sGaifP4AffwLvP4bNQuf7D0J4sgmVuomWi2XLbKR8IRUb1/bN/mM4sfgqFn13EHUMoMAgtuXwRaJlQstejueTq8f2SxakV2oQBNLwWHPXyWVGQ0L5+F/vaRsN3w7TcYAFUK2xmPX1EciNbvbjuJg0HLZDNf+rspn27SX0v0p5MDUGE3mrAOqbe/uRk24VuHckclfpRopyaYlNQ2t1E7NvFeDhOvz4E+UnnyV3/T/1GFjQtl2AtK9Mjlj5fsq37GhWBN9NmonRuApTOrzi+2w0GiOA51mFaT5rrXPG8/Y3T1LNXK5akHVQjRzdQ8AXF2RdYgQqeOGfv/kmHQncocsA646yvKLymQi/rs4P61KiWPaqWjfNTFztlWQsnRiB61NEk+Ag7BkABG2ZLNoZ853RaOc0slehBVJbBXi4Br94EPLBIomDq8O5x5OpBfDREkyPKbmMMJKNOgREQTy4iTMRR20aOti+X0ajzx5LLMjyYTQDE3mzb0gSYNUCezAsVuJKQvtywfjlRWFf6vzHbvbRUaucGPkOFTT8uaIJi/Idw0YYZ7DqpmHY3Etm0eCJidvnp8SqB30ik0j6Hr1Iy7pFZzYNh3bmSIJGvSoDoVgRVnfhV4+Vt+4nWxZM+9ZOaWbcvpI09F3dhZ9+prz/2K7LYsW0gXEZvstCJiASuXd8mbd8yNLoudP7T96aPyu+Z50gsml7gEslnOHqAewdKPsH5uieJChzDDWK6mfzHkvd7KSrDFbE26rsiDDag305LhhxuX3c5Hm7mCwbIVGANTdJo/+gJ4PJDinaHOOd0WjfiXV6YShUapbpfLyu/PJz5dPlk5eTfc+ujStj5vQ/O2ETZhDC2p6V1m/vw175eL8jVVjago+WlC/eFK6MwUhGSaekuRTt/nan05LBav7c5e769KGLCBK5/OcyVkE6nrdlv7OoB+bmvnsQ6bBCC8S9PjryOZ5jVDVUeVu+rV0JF7oOsLIen1dU7gEL3e7LcbGIWsZZW5MADiqmY0iC78H0GMxOCKMZSPnNNif9RbucWF1E1TaRVq8eKKVqc3nwk+VnLRhiMil4cQ7euCW8dI3IJ01IibXS2StZi5N7K8r7i/Bo/eTA/v5TeLCmLFwRxvNm25Dy5VDvQscJ9NhotN9ZQ0/M8yybUqZG7QFuu3B20/l6aMHVdlEpVeNKQrEWTuKCrEuHcOBr+ONud9N1gPV0krXpHX0X5D/B6bAuHarW86tWh1LN0utJ8MSqByfz9rTp+xZc9X8gk8MZrLZHfDfUdkLcY7BYhvV9s2bYOzj+tbk0vDAH33hJ+PqLwp1Za6eUTZsmJlQTJe+WhGuTQj4TIsD91eMzWTtFeLwOK/MWqI3nrdpMpEuNxGWgl0aj2nHaONn+afaptCVCYW5SWdyA6gnXWkwYRm2ZimaSXA/jpWRxUfhlRNkoh7zV7W66DrDe+BbV5e+G76DeASLOruEyofaUZ6aRZjQanPGkGCNiQtR81pr2+p5ElUqDCLGkRXDbLm60bQerNLV2OFY9CKvbVgxxUhuTmXH46h3h114QXrkOcxMwkrVWKJ6I9b2sW6VYJgWKR6mqrGwfbywZhPB0R3m6DS/OCTPjShBaNaHzkzyDXhqNSu+NRg9j+/U96wgRLy+PZC07ddo7CBQKFXvdQdUC9TCMFkfdBXLpCEXfTZVY7XY/PXmAk5CfAxs43eilwirD1ErvA8sqnNX7K8YXGMmZwWjat58HkogXO+fWJFZSjnXNcmNvAiwoCkKbvDb3zWD0ODNRT+DaFLy2AHfnYX4SJkeFsZw1eM5nYDQrjOWFyRFrsfTCVXhl3jRWxxGEtpz4dMe8t2p1uwY6DhouEz0wGn32FunXTWNVyJ7YmDKagamoZdJZMZKqdQbYKdoydjWIrk8VN6tdOjQQ1R/c/Gd0XbzXkwCrGrKiIu87/9vLRcNktA6lSH9VS1h94/vW8d6qB+13sWHgIIh9E7u+Yt0VfyZNiwbTSRUrnNhKKeXD1QkLnKZGIJ+zJcPYYiG2WUj59vvRjAmZr05Yg1/vmOsnVNN9bRXVHgJCOxc3WiWkm/tkwA8g5odl40s+ujYyCddpCmULxIslC8LdNXJpKYjwC+mB3WFPAqzbs+wJ+hOFhAocx0WndemnGlhmolDWxEuE2ZQNgKmW9jgDGYzjEVObotukd5HEGzraRpFGprNSP1ncns9YYDWWEwusfPM2itsnxV9enKlIRYFW3gomJvLH77cYPQBYM19b2nZLPwmI1lA7/qhaM8UDuHXiayMVWTWMZpMHWIoVTxxUTeoQKi7LeelQBZZ9+LQXe+vNEuG3CHw//Jmo7vZif47nH8sARXqYaHmwWkv+xJc7YvwoA2ipYRw2wGr/CdVNyh2hLTPtsctGhu9ZwB0HUCLatO9oMQhtfGGWC75nk6p3wohmHQfi4Craj5s7z6Zbo9FD+xpEHWHUNicKsEayQj6d/MwrNdOS1sP4knVdGy4ZKsL390rs9GJnPSuiCWr8QmFF6NxW3nGxUAUNraS5Wo8GpQTbCYeXfeLJcnBPi93kopzRaPtE07M0l/lOyojEWa56nEFo9ME7XPgZx2uq1takHkSVXyeMPn6c9fJABpkxvegcNRrt4jPrp9EoHA68fc90WLk0ZNInB95Hqdaby4NhfKE5Lg0KdYLwT1/+Dgnc086mZwHW9Wm2ReXniiZcJHJcdEyDpdRCqNZOrgp7hqiCMBa3N/sPDmrG6yaUc7Ny+0iUiWou3ZzksF0sm29RsaKUa1ALtGWyi+Y7bfqv1QLLOLS2aTqO0axZPeQzcdZ0MNmUC0+Uwerp7vp8D4mA5wmpSIeVSx+vzTuOemDXVNzsWd39fqkQ1c0CfNyr0oaeBVjyLQJPwr8RJaHVpONC09Bgmci9UhfqCXOXnsBoDjIZE6M2esP172xbaN43nR1PT/3RcTwSGUCm02bNkTpBF1MLYHXHROl7B2brUImC9yA0z7UgVGp1bQjm90pWmbi8dXJl4vSYCeFHshbYm+eamzzPpGHT0Ppz57saSEJIbWk5nbJgPpdpL8CqB9oIsFwG6zKhqsLD3DTLvdpjL1rlNAiUd0R0FWSil/t1PF80l2rM6bgeQqWePIOVSVmAlU3JoSXCwWBLFNKBTUNze0c7mAFkVDmahiujwuSIZbSOC4hWd5V7K9FrPCEMYTRnE6YnkS1I3YoqVnfg8zW499SCsuPwPJibFOanrPVO2jfdFgO97i4o3do0tNJno9GYpjbPTEczfvK/c6iR1KEhd3AXyCWipqp/efNDKr3aYU8DrLDIR/44D1B9CRFnkjykCCa0izNYQWAC96QZrJFMs/9gvEQ4WJpBVvv0yyRxOJFogvZESHlmu3B1EuYmhGxKKR3T3ma7CO88MIPHIFSqdWE6dnL3mnYP20W4v6q8cw9++cgsGI4j5ZmFw7VJYTQLad8CN/dXTEDkBaWdLpa1btSIcvp7D5ndizaKH1qz5EkIw1YhsbvfLxEFT/mevNk7HXlPA6xbf0hp+bv6Q0T+U2Ckl/t2PD801Su2dFALlWrCDvQilrLPZ4S0b1qJRgZrwONYd0ajA13XvOAI4lnmaDStXJ2AG1dgLM+xAVY9gM+emlKuHgg7RespN543/6sgMM3V6i58tATv3lceb5wc4I/l4OYVaSwR+nEGy3E2caavUzf3gRqNRsUyaudrrZCU1ClFFccRZ1VVXQXhJUJR/TjM8VEvd9rTAAsgJfx1XdlAuN3rfTueD1p1r2FoVVyBWlo9ybZp37IIvieR2FiiQZEBBSydJf8Pvz56snUPuInwsOAon4Mro9ay5qV5Zad4vCdWrQ4PV2G7oHy4qFybgulREy4HIWwWYG1XWduFjb3Ts6d3r8HtOWvBk8/Q9oR76VHtymh0kEHK4fNUtMXao5192Fjm7vHLgqB1RX668F/rVi/32/MAa7PCh5Np/RCRm7heqkNJ5D3YfKLVVs3C6QiRZ5EvTYNRNCrh7tspt9A8S+3oeG60bZvo4/I8JZuCiRG4PQtv3BTWdpQHa8dvVq5Ze5u1XfhkGUayiu/ZBNhseXPydScCV8fhizeFWzOWAcumpdE5QKP/HDf56gm/v3Q0jEY7DJP0hO/7TnNsajc5HrdM1NMuEMdQobAnhH/e6+eBngdAr/8TNkORvwGt4mqshhJp+U6f/eWpxMuLcbm9bSqNya7/RB5YHcdzbrBtl3iC80RIp8wy4doUfPmO8M2XhZkzWsSHasHWVgHW96ydSaUWO22fzLVJ+M1X4asvNJcHU34sgj79L+nm1IjoAagXjxUyUGuM5tjUlolxY0yKr4EBp+Ac54EK+mHN55e93nFfMkzpMPy+wHY/9u04f5q1QNpY1mtneS8MW3xmlKaAdoCVhJ1XRTmj0XaI/8bNFiZCNiPMjMEr1+GbLwlfuS2M5np73JQPX74Nv/2axxeuW/udXOS/5Ym6ACopPTQaNT+0ntQjJkAb/+3oaI33eayIzDFUaKih/ujWOKu93nPPlwgBwgz3COQjVK9Fd5RjKGkaSCat1FHMLblaV4JIRBq3oxjcheKMRgfF0bvfixy2R3IwOwEvz8Ovv2L/9tGSLQceZ92QFN8zv6uX5uHvvOzx8rxpr0aykE5JMytBUxDtOIVWwWUPGJz1QTOQOyvTeeZ+nCpg2Nn3hL+Vb9Fzk/S+ZLD+xWM2QX+EcEyNkOOi0xxrLPPkeZYxSFSZpSZqrtaa7VCe6YXSV5pDfGdjpjMa7ZR4qcb3rNn3eE64PmVZrL/3FeE3XxXuXO18/+mUBVa/80XhP/+Gx9fvmj3DxEgcXDWbRreek+MUemw0Oqj7RSO7/1iwnjhof+Z6cBms4Ufuhcp7/dhzXzJYb75J+I/+t/BPvZT8ASKzuEt0qGhqG2zS8iVeekm2bbUOlcjWIV5Csh326YQPET3ZaqfZi0jD1ctTukRY6bwVOeQzzd9lU0ImBeM5mBxRHq6ZzipoXU6G+E/XCNa8qLfhWM6yYV+6LXz5tvDKdZgdN2F7LiNRexznfdU2jSKUi2M0asdq2koE2k1W1GWwhholVA3+4kaGE0ptuqMvARZAqsivwik+Bv0tEL9fx3EMnoYTVMvyYNoX/ISVRrXAJs9aoATBkafjfg9kjSWi9o0Tm6oON1F3QzPIMj80TyDlK7kMzE8Jr90UFteVlW3Y2Dcrh2IFStVmUJ7LmGHtlTFhbhIWZuHFq8LNGRO3XxkTRrJKJiWkfDM6jY/taAPFghXt3Gi0qd+Kv+vvjR7fp/HDWxCc3AT8OBoCd4lyd+6iGVYU0aIofyW/T7kfB+hbgHWtSGllSn6E8k2EfL+O4xg8rcOj5wkpz9qY+AnD6HrUoLfRVLVfJ3ocevjbrodON/Z2jAVWNn/5njn7T+RtWe/V68L6nrK2J2zswU5R2S81/a4s02XB1fVpYXYCpkZt+5GMBWBmZNvS69L9rTpDmtYFbXNOqd5YeVCPPfraOI9G+67oZx7ufgAAACAASURBVHfZDDHKk1S9P8uD0McAS94kXPrn4f/rpbz/RiGHu06HBiG2OTCDhUwKRjL2/0moB5aNqNXFMhJRVmJwV4g2Jo12Jl1PaNRstBYZuSu7feLP3Yv+46UF31eyaRjNCZOjyuyEcKsMB2Uo1cSsGaIAK5M209CxnAVbIzmrEsymLbBqLAlGGUsXXHVIi01D/HNbH+WxgVl//xiWuZKoKXjT0iMJnpiWz4/HBhl0AY5jYKjWRfnL9XV6ai7aSt8CLIAbNd5e9vWBiMzjrtGhwsYe6+mW9pV8Vsikk41iigVY1boShNLIYg1mIGsRubepdLeXqyuM7SHxcqEKpMWyoZmULR2O55QrYxaQ14PDmQg/KqxIeTYhWlAl+J79fTwP5xHZCxo2DdpZYYge+X4Q8iuw4CqSIpRryRNpKR8yKWlkPl14NdTsiobfe+NNTuhi2j19DbDkO1SW/6X8Feg3QXrsdOM4b2KReyplyzvpqJLwrKdFVdgpwkE1mjjD9lL43WH6q04ON7gS88tFHARZZtQE6aFa5V+2IXKP3NKiCyXOPnoiUWbRlgNjdVyLG4OjG45msLrZVUOj2Z8/TFwIoaGNKeUaFKsWZCV9A6M5y4ymGwGWu4iGFEX04UGZn/XzIH1vZZPywj9D2ej3cRzngxdNiNZfMHnGYO8AimWotVSJDdLluZNx09UP9o84oxjrpTwBP9L2pX1rcZNLK7m0kMsI2bSQSVn21Pfj4Kr9ZV/HGUQZrN4gXVn8no0J20NM31muwv6BUqomDxDH89ZpIBVfU9KhuN/xnKM1T+Wv7/7T3puLttL3AKuyyzsh+h5KG3UcjueeuExerFt9LtLE+AmvqHoYLRPWoiqfSDcxEKQbZb2c+qOje45mp/wom+BJc+mm8eVJ43sXWPWBFpuGXtDfLLBVOwahUq9DoQyb+1AoJdNgpX1z/DdT2ijYdxfVUKKwFhJ+r9/H6XuAdesPKYnq/4WnJdzj/9DQzDhIlGGAkayQSlhJGCgcVOwpsxqaeLnVc7R/6GHvwHaPd9SKwl3RfScOuI77cvSZFqPRLmzjmrvq8/2iKgSBUKlblnxt1xqDJznuaA6mx5o9K30v6pLqrrPhQglRfXek3t/lQRhAgAUQ1vkBIY/cbDRcWAbLBqNcxqq5MgkDLA1hr6TslaIsVqgD0mF1noGyCcItFDouEUcyWG1f94ceZjoO05IeilCVeqiUa2btsbyt7JfPPqqIWXyYf1qsJ40KWtzNPlyIljzVP5/6g/73Sx5IgHXzH3Nf4QfglgmHCgGJqrmyKWtJMpKwlCEIYatgKfxiBWqBDEbsflT93HYGK/5/91jrGH4svhJUO5R7t27UbtluuyiEKtQCoVS18WVp2zLlZ+FHAdb0qGmwMr44c9rh5UlV+KtBHGggAZY9A4R/hFLEPQ8MFbFGJp+x9PrsOImWCUOFp9uwuKlsF6FSM+1ESJ8vkKM7b9Omodk3Udve3uG4aMT+dCLamWHBsXLH3t/hVkGohKFSqyvFMmzsw+Zesoe2lG9NwWfHzag2ldJG4YSbsIaKIFR+4BV4MIiDDSTAAjgo876i7w/qeI7+Ez+P+p5psKZHhfkpGMuevW0QwtMdeLCqbOyZFqse2NJh30e0Vh1V2xmsY4xGHY5hpcWmoesM1um/7JpQpdElYr9sbZZqQbJtMym4OiHMTkhDg9VoDt6Xs3WcAypoAQ3/5NYfUhrEAQcWYL3yHfZA/wNobVDHdPQfkeYS4eQIXJsUJkeTDUrbRfh8DdZ2lYMq1OqDaJ2jh5+q2x09B2fY5XCcPw2j0W62b6EP0UrcczAMlWpg9i9b+yY/CBKKUrJpmJ2AK2OmJ01FnQAcw4QqyKepkLcGdcSBBVgAWuVfCewM8piO/hFXcvkiZNPNPnLTY8l0C6oWZK3vWUl1pT4I09HOB83jSszdGOwYaqIMVpc7iL5TpE+PT6FaBvygYoHV4oayvpc8wBrL2fLgeN4813zPtVcaQmqK/tm1GTYHdcCBBlg3/wmbqvo3uIWVoUEALzKEHM/D3KQwmzDAAtgvWSn17gGUKi0NoNts0Nr2WffIaNQltBxDTYtNQxc7iIgb7vTuponrEoPQHtAKZVjagnurJnJPyvQYTDcqCNUqCO2UHcOBquoqhH8k3yLhwnH3DDTAAiDU/xO0jUvf8TwjYn4xad/8Y6bH4OqEpdmTUAtgZVtZ3rL2OZWamharn4GL6DN2Vm1sfOqPDsdQ0WLT0O0t2fTB6uFNEz2IBaFSqdmD2uMN5cGqUign24XvwbVJkzhkU5H/1VGtpeNioxoIvHXjv+ejQR524AHW3i5/rOg9XBZraDChu5BL2yB1dVIYT2jXEKqJ3e89Vdb2IsuGutpSIf0ItI6IvDo0Gm1s5q5ixzCjmDS40+37HKEopr2qBdYZYmsfHq3D8pYtGZ55egJXx+HGFWEiWh5M+drSN9ExBChCQUP9/wZ94IEHWK/9T+yj+iducWU4aOiwPKvEGc/BzIT5ySQZW1VNg/XBorK4qeyXIi1W35YIe2M06nBcCgTL+EY/Pk9Go7GMIFChUjPn9qe7ypNNpVRNto9cGl64BgszpiFNpxRP4p6JjuFBH0qZPx/0UQe/RAh4Hv+PwNp5HNvRe0SsMWo6ZcuE8RPhSAK7BjBh6kdLcG9F2YiMR6u1Zvuc3p7skZ87NRp1OC4LUSDTvdFoj86nhTC0sSL2vVrcgJXtZL0HwXoPfuG6cHtGGM3FS4T9OVfHOaFaFZXv3/inPB70oc8lwCo/4T1V/hy3wDI0CNZeIp+BmXHhzlWYn0re/LlYhgerltrfKUC5ptRD0F630DmqAenQaFQO/dLhGFIUEKuo695oNHbO6/6GVo3a4gRQripbRXi8Yb56uwfJ93NlHO5cNd3oSBZSnkQCd3VVhMOBIjz1vPD/Po+Dn0uA9eKblEMJ/62iB7ggayiIxe7ZNEyPwMvzwovXTJeVhFCt+uezFWV526oLzd1der9U2AOj0Y63dzguEkeNRru43uWY7zohXhqsB0K5br0Gn27D+4+VD59AJaHTYjYF16dgfsr0V7mM4PtEAncXXQ0Bao2d+evqHu+exwmcS4AFUCvwrqC/cFqsIUDiZUI1HdYI3JqBF+fMuiEpsRbrwaqyUYiWCiPBe2zd0D2R0Wijp2C7m7vL1XGJOGI0ql30Pu5FAWHDVFShFigHFfPSe7yufLCoPN1Ofn7jI3BrVpgdh7E8ZHzFc3HVUKGqe0L4R4Nybj/KuQVYL+yyh+f9c6B4Xufg6B2COR/HOqzZCbg5I1ydSL6PchV+9Qjevg+P1mC7AAdVqAdK2LM24dEI2sEscZzRqMMx1HRtNNq6q96I3BWrECxVbYz4fA0+eGIZ8MTBVQ5emYcX5oSpMcilIOULnjQLdxwXG1ENxJOf5uv85LzO4dwCLHmTMJsN/gT0F7iFlguNcMTVPWUVOQtX4NasabOSoFgPsfce2dPok8gbq1wzn5vemY+2jJ5t7M+MB92l6rhEHDUa7erylyh13NlO7P5XgkApR1WDS1vwi4fK+4/b017NT8GXbgu3Z5vu7Z4Ttw8TGgoFCYN/M/UHbJ/XSZxbgAUw81+xFyJ/jGpCSzjH84xlsayaMJ+11hOvLwhv3CKxFgvMgfmdB/CrR8rK9pE2Oj05Ue1cpH7UpsENyI5hptdGo82dtrdtw1BUqNaFQtla4Xy2orx1X3m0kbwtTtqH21etenB+CkazkErZ2OVu5yFBVUE/LlT43nmeRuo8Dw6gEv6xqvwjQV7FXd8XHhFrlJrLmKv76zeFQhm2CsrjjWT7qNZNi5WLGrBOjwmZFPgCGVGkqz5hnRuN2sO8yX0PPdG7q9YxrMRGo52mjnsQtDT9rqAaKMXIUPTxRqzZTC5sB9Nb3b0m3Jq1MSqXtrHFc0uDw4IqVHz0j1/+DvvneSLnmsECuBnwSET+VBhcfyBH/4iXCluXCV9dgBevSeKlQrAB89MV02Q93jStRTlqo9PThtBtZ7B6dFyH46LQTeDRTdeEFkKFWt0883YK8Pk6/PJz5f1F62GalLRvxTcvzsGVMRjJmEFyUjsZxwVBWAqq/FEXNRk94dwvK/k2tTAM/wOoMx694MSDsCdCyjOj0akxWJgWXluAucn2BurtgukrfvlQWdqC3SKUqtJlkNWlzYJ7xHVcJgRQ7TxR2zrDSXsi97hVVhAStcJRdouwtA3vPVZ+9JFlxZPWv3hiS4O//rJw+6owMQLZNHhRRtzd2sOC1jz43sI/ZvG8z+TclwgBagf83Bvl+yL8l/ocBH2OzpFIs+F7kE4JY1lldhJeuyEsvqBU62bHkIQgtCfVt+8p43nz2Ir1U/mMjYa+18nA2KIo6choVDrXcDkcF4nYaDTywupo+watDXdOv3FU4z6DFlwdVJStgi0L/uqx8s595dG6/VtSRrOmCf3SbWF+0n7OpMxY1N3IQ4MCK0L4v5/3icBzEmC9+M/YXfmX4b9TvP8MZBp3tV9wpEWLJUzmlTtX4Rt3he2CsrVveooklGvw8TKMZEM8EQIV/MgHMB9nzDza86+RDicLON5o1F2tjmHlqNFot7tq/udEDntdRZmrA+vy8M595YcfKp+ttBdcicDNWfjiTfPomxyNtFeeGYu67NVQoCiK8MOPlnj7vE8GnpMAC9C68JOUys8V/T2XrL3YxH8934OUr4zmhLlJ5bUF4ekOfLJiQVZSdg/g3YeW0fK9qCIxymTlMkIKBU/ODrLiiqhuZgs9vLG7Uh1DTcNotP2M79ENkt52it3r9Si42j6A1R34ZFn520+V9x4lrxiMuT4NX7kjvHJDmJ2AsaxVO3ueez4aLvTAD8M/+r03qZ/3mcDzE2Bx8wk7ywvBvxb1vokwed7n4+gNKREyKWUiD9cmrarwN7eVd+7D6m5yHdXuAfzicyWdspY8tZsQzsCUKvmM2IXsNT25jqXh6aPta6/izY8Mx6ouyHIMMUeNRtu+b5phVXOZ8fgbJh4LWjVXO0V4tG7eeD/9TPlkqf3g6uoE/N2X4Zt34eYVGMtBJm2efaeOF44LhTVVk7dSlfMzFj3KcxNgyZuEK/+Gvwjr+o4ov4uI02JdcERAPEgj5DPK1Ci8NAelLwjlKmwXta3y6r0SvPvA2lkEYdSANmr6OpK1TJYvpq+SU0fNlifyjoxG3YjsuCS0PpR0wiFP30jxfuQeigOrhhVDHYoVZacAy9vw/qLygw+UXz029/Z2yKXhizeFb74Mry5Y9iqfEVK+jU0uuBoeFEoEwf868x0Sqnz7z3MTYAHM/7dsrHxX/60iXxO4ct7n4+iepvmoMJpT5qbg5bqwvgcP15TP10xrkZTtIrzzQKmHEARQuS3cvGK+cvkMjQyXx2mDZ8sBOzQabVZGtbm9w3GR6NZo9NiNng2uwqhasFqDQsUkBA/XTND+84fKpyudBVevLcDX78Ir14W5CRjLScOWwd26w4SGqP7t9VV+eN5n0spzFWAJ6NOA74Up/QnwD9zzxcWnVY+VTQljeWV+Cl6/CcvbQq1uLXHasVzYKsBb95RSBUo1C7RCFSZHIJ+xQCvlS6Mc9dBVdLTVTYdGo4d+6a5Sx7DSR6PRuFJQQ6UeCuWaUizDxj48Xoe37it/9StlccsCr3ZZmIHffFX46h2rGhzPS1PYjptdhgqlWA/1f5E3ea66wjxXARbA/P/I2vJ39d+B/LbTYg0HEg2yKR/yaTMgvT1rVYW1urkzr+60t89CGX71GGqBUq4JBxWrEro6YcfKpk9of3F0nnBGow7H6fTBaPRopWDcW3B9Fz57Cj9/oPzic2uB0061IFgANT8F37wrfPm29UOdGrXuEim/zYpjx0VAEf3JrW/zI/6H8z6Vwzx3ARZA2uf7tUB/CvL3cL5YQ4FgFTtpXxjNKlcnLIsVhkKxovy4bEFTOxQr8P6iabnWduG3XpXGoD2RU/IqpFIcmSCOLHZ0aDTqxmjHpaBbm4ZnjEZtwTE2EK0HykEV9g6Upztw/yn8zcchP/3MMtXtBleCCdl/54vC1+9aS5wrY6a7SvuuHc5wonuCflfk+Xv8fS4DrKv/HStP/pX+H16ofxeRCdx8duGJtOf4HmTSwhhwLVTqN2C/LBxUlQ8Xzb29nbukUoPP16ziKAytlcZL14Tr0zA9ptYKIy340ip8N9FuvOrRzsVlPURbtnBXpmOYOWrTQHuX/KGlOJXIPFSjps1KsWKB1NIWfLKkvPe4WWHcCRMj8LUX4ZsvwyvzwtUJGM1ZJbPnIqvhQwkF/WGhzJ+c96kcx3MZYAGaVv60Lvq2wO+CtNHFzvHcEi3XxV5WYR7mp+FLtwVUyKWVXzw0x+Z2hO+hwtMd+Mv3lc/X4bdfha+9KNwOrN/YaKhk09LoN6bRE3nY5mO5xnqUQ79sbx8Ox4WiJYPV/Dk5sQmwtb2x4hQNhUpdrQn8vmWtfvVYefeB8vFy+5ns+LTmJuHrd4W/8xL8/+3deXxkV3nn/89za9HSUqvVi7oldbsXu72y2xizhxDygwQymQl4khlmJsaGNjjxAAGyECZtIL9hif0jBhy3zRICCYlJZgYIJAyr2YmXhM0YL+2lF6n3VmtpSVX3fH9/nCqpJKu7JbWkKlU979erW2r1rVunSrfuee455z7Plq54x+CK5lhrMEmMxOdC6o0wDYN2bb+eOVSkXDq1GmDRdQ0H+27XJ4RdanEtlndjy1x5ci4xIIlrIjoU12NlM3EDCX74GBye4422UsyV9ePH4rRDqli38Jy1sLYd2lvKQZYIml8dw7go90wpIJyrI6URrLNZfBhUKnkTQOMwVhAnTsKRwVgK697d4p7d4uH+mKJhPtpa4t2CL7jYuKAn5txrbzGasppnOS1X8+J0wlcHMnyr2k05lZoNsMzQQ3/Bl1qz+gHixZjVbFvd7E0UhAayidGch1Wlk3exaJgZUuCe3TFgmqtigAf7YGhU7DkMT9kcb9HuXR2nDJuyTKR4CJpb1J4kMQWEcw2jIk0D8ds5SdOYkX2sACOjMc/VwAjsOQwP9In79oif7YW+Y/MPrjpXwFO3wGXnGtu74wL3lS3QnFO8m9jXXdUjYQym6M8vvJo51AVZWjUdtJx7LYf6btdfgz0dWIePYtUNs9Kid4B8uXyyyGRiEtGT4+Ine2Dw5Nz3PVpal3XohDh8Iq7ruuQc2LgmpnJILKZ3KKaa01RkvBL2OUHXQGZINDqXGKuQxptRTpyMwdXwGOw7HD/bdz0kHj4Ao+NzWxJQaWULXL4dnrXduGST0bMaVrXG0fFM4sFV/VII0rebM9xT7ZacTk0HWGbo2Mf5/EhB/8HEy30Uq75M3FmIYU2TPwsyksRobxE/ekxzKqlTJuJajh89DgMnxYEB4/xesbHTWNkar5ZPnIxX2LPeZ2kNVnn/Ew12rl6VS+WUc1aJOUVYhRSODilmTgcePwz374vFmvcemftdgmWZJKZkefJm49kXwCUbJ4OrlnwcHU98arBeSdLhRHrP2qsZqnZjTqfmA5bOqzjef6v+Vhm7QrCh2u1xC6d8Z2GSxAOxJT/585Z8PFl2tBrf/bnYd3R+zzEyBg/sh76j4qE+uKAXzllrNOVgcBRGxmffX6Sa4UrbB7RcvTuLrCaj4/EGlCMn4PgI/HSPeOxQHGU+G2va4YUXG5eeC9t7YiLRjomRq1gGx9UpSWb2te6NusvOZnHgEqj5AAtA43wtNPNNg/+ALY82u9l5YpBlYCrdfRQjl2IKP3hI9B+b31RCGuLJ/WQfHB8Rjx4SK1tiLp7+Y5p98ViV/pJHVK5BiFKm4Pn1Y33H48OLqTg2HIOt+a61ghg8dbbBM8+NU4Pn98QSOO0tMbjKJRZrDOKjV/VKRj8KH7Nfqc07Bysti2Cl+3oO7d0V/sosuQLY5B+d+jKZIysWcDaLeavKWdjN4mL4e3eL3QfmP60wVojTEv3H4wLYTAaGTs5x+rEWs9k5t1gqpggngpY5nH0PDcQkosUAheL811oB5DKwvTtWgHjqFrigx+jqKAVXOSNTkaXde4j6ZKiA+Dziu9Vuy2wsiwALoCnLNwuBL0q8xowcPjFTV6yUoiGxmLLBLAZbmSSu32jNG6tWQD4rHuyPwdJ8Ui0ExSvo+VxFl+umyQ891yjKaRpKI1hzDVyKAYpnOc5gBu3NMbfVcy6IAdY562L6lRXNMRVD1rO0NwIF6dFs0CfWX8s87jFfessmwFp3NYNHbgsfGsVeAHYhHmDVHStNqCfENRSWj4FWYjG9QkersbrN+PHj4md741qOs5lumIuYgTre4Vgux1MuVjt9SOsJ5Q6NeWWNP9U+atlCtLNW9rFcnM1rLT/sVPsoJwg91bG+2DIJ9K6Gp24xnr4l5rjqWRNTM7Q2xSSifrdgo9B4gm47vLq27xystGwCLIBH7uaB7svs46A/BvNC0HWonNLQDDJAUxasxchmRFM+lsLoXmWs74AfPCgePRjvFjybqYfZErG49HjRKKZxygNUOrGXWq7yLe2lq35ZqfMSmGHS5LY28WornqHc051mG1X8zCq2ZWo7luw5pmwzh+eo+Xac6TmW/3uu0n5MVtp15fNazL6exmn5YhrXMy5VINOcg941cNk2eOZ5xvk95aTB5dqCmrxT0IOr+iYFYXe1JHzmkisZr3ZzZmtZBViX3Ubh4FPDp4o5+xXMXkDsg12dqTyBZxLIW1zwnk3iSFZTFpryRucK+EkpUeHZ3PI9qzaV2nJyPAZ0gyfBELnsZFcVlb5TOcya9rfBZAhWuQ1P+NnUr5P7PtU2nPbxs3mOM29z5uews36OhXmtZ9+OMz1HPbznU4atJhayl76WRq7G03jMj4zBeAGyi3yHXjkFw/YNxpO3wMW9xtb1sRTOiiajOUdpSrC8ZnNx2+OqThhHMko/vGole6vdmLlYVgEWQNd19O+7NfmkZfQksLX4tUvdqsz6Xp4KyGRELgMtTbCm3ejqiPmyJLHnCLO/I3AeQoBjw3DguMgmxvBYXHg7ZRtN9lkTX4mrtsqvZ2LAa7Y08dfZH+0V/elifHKmpqRc3vuYcQdn855VDkYtoLN5rRNTf8y8slDEkdrBk3BgQPOqrjAXicVA6vLzjKdtNS7qjZnZO1bEdZhNWchk/KTfUKQU0525Ub5oV7KIl9ELb9kFWAD5XPr3hWC/Avx7vBB0XTMr3RkkSEpXrZlE5LJGS04To1kdLfBvj8LuA+L4SJzOWEgCDp2A+/aKNBh7Dov25pheYmJWhRiEFdOKKUsDlYK+WGpn6hW3TXuOmZ54+s/LAdq0iZ/57Wd6I85S5aTWst7HDO9Xeb8zvV/T3/8pz68pX+a8n+mPnekxs3mt5X2Vj780TL0gSWyyMHMamLjpJISYL+7ocCxvM7wIN8fnsrCqVPz9KZuNp281zt0QawqubI13CeYyk8GVj1o1DIH2KdVta65njhVqq29ZBljrrmbwwO26LWDPEfRUuz1ucVV2IInF0azE4ohWNiNa8rCmzdjcJe7ba/zggViCY6EXOQ+Pwc/3weEToq05tqO84L3czvLt6GlFp6rSqFYmKd8hOfW1lc24yLhy1KOi5y7n+oEZAqzT7Wc6W9D4qm5MD44qzdS5V/5seoD1hOznNuXLlJ+fMsBawGM5KU3xhTAZSAGlu3bjc4ZSgFkOutIQbyg5fGLhL17yWdi8Dp60yXjSObBtvdG7Bla3wYomaC6NWiWJH6uNRwXM/nfPiL5d7ZbMx7IMsADSwHcwPg9cg/larHo3NSgpLXCdFmStbDFWtcY1Wu0t4vHDsbDsQnYIw2MxRUR5JEqCwORVdQixc5oYwapc4lJaL3KqTmKufehC7cedvYX4XZwueFjI32n5GCwfo+ULAEtKd/Da1KCrsg0L+VnKZ2P29W3r4ZJNsZbg1vXQ1Q7trXFKMJcRGS/Y3Kgk8fNCGv7K3sw8qtJW37INsHp2MLJvV7jNkuRXwDbiFzcNYfIkGxMLxqLRMcjKZ+OdR20txuZ1cN/eOKX3yIG4SHehFEP8M1dzrePm3FJSiBcLS2FlS0waelGvcX6PsaUrTg92tsKKZmjK2cRCdg+uGpKQRg0+fTjhJ9VuzHwt65GfGy/j0NBKdUp2uZll8CCroRjlKQyRSYxcKcBqb4HV7UbnCmNFUywePXQyjjw556onm4l1BJ+0GZ53oXHpucaFG2OuqzVt0NYMzRMpGDy4alwSph+Pj+lPLn4DR6rdmvlatiNYALaTYv9f8T/DmP4fsEur3R63dCpPugkGCbHETgK5jGjKQUsOOlcYvWvEJZvggT54uB8OHF/clA7OuamasrCuA87vhos3Glu7jE1roWtlvEOwpQnyGavIyG6+PrCBSQyI5EN/eSR9rNptORt1cfz2385vBSU3Y7a22m1x1VFeMxIEIYhCaowVxNAYnBiJi3P3HBb3PgL/+ojYdzSup2qUbN/OVYMRizBvWw9P22I86Rzj3PVxFKu9Jea1asrFu4LLC+rBR60am8Yl/lc+E1637moGq92as7GspwjLfvPl/LzN7ILEeHJcqukaTeUCcjMjSSCbMfLZWCh6RRO0NxudbcaaUg0ziMkT57Oeyjl3Zmvb4Wlb4NnnG8/YZmzvhu5O6GyDtuaYNDSXjSPP5azsHlw1NCE9lA36o67X8XC1G3O2lvUUYdllOyj07wo3BZLnY2yjTkbm3NyVT84Zm8w7lc3EgrAt+bjGY+1KY/2qeBU9Xox3G/pIlnMLb/M6uOJ84+JNcUpwdamGYC5rZJPJAs0eVDlicDUM9tfrr9X3qt2YhVA3oz3rd/CTjML7Qb6U2QExyo5rsqApH+8uXLMSejphWxectx7WddjEtIRzbmGtaYMNnbF2aOcKaGuBphzkM5MjVs6VCNP3RgrhE9VuyEKpmwDLQPk8f2fYt0C+EmPkXgAAIABJREFUhLmBmU39kxjkEiOfhdYmY2VLHL3a0BmnMDJ18ylwrnYkFrOwr2qNI8ct+RhYZROrmM73IMsBIEOHlOqD513Hnmo3ZqHUxRRhWedVHH/89vSGLMmFxAzv/tF1E4kTMwYkIl8qs9PWYqxs0ZxHsJJkcgqysmxHucxIWaY0BRIX3k9mdXcL65QlgM5iH/PdT62rXKtYrptZLnVZvhgpf14qj9dy1vc0zD6VWz4b81k15WIpnGzGfJ2Vm4kkjSM+a8ZXq92YhVRXARbApn18r6+Xv0V6A2Yt1W6Pqw2TQVC5lmGcqljRNLcRrHw2TnusXQmrVsQF9NlyCQ+buqaknCEbJkvqVNZtnl7ipvJn07/OdpuzfXw1nwMqOt7SD6Unbjt9H5VFlG36vgSqeOBM9f1m2gfT2lsX77lN5o4rH59pKfltKJVymlhsTvxZoQgnx+HYsDg2BEeG4o0hs9Gcj5+xbPmCxNMuuBkpgO5Xqpt638AilxNfWnUXYNlOintvDh+wZrvCsOfgn2lXySYzvzdn4xRGPsusC9jmsjG4uniTsXUddLTGK/QkATS5sB6LV/shVHT0VIxglXq/6R3iFDNtM63XtFIAcdptmKHzPcM2lc8/m21mfI75bFMZ3UwbLZne5vLjKmKjySDLpr3WJz7stPuofM1THrSQr3Wm/zvdNmfzuy99M33kSBUbVU7bYbHbGxmHY0PikYPGg30wNCpOjs1uFKu1dPduPgeZUv1QPxu7aQQMmHRL9+t5gDdUuzkLq+4CLIDe69nXf5tuFjofbF212+Nqi1nMKN2chzXtRnenOHEyBkRnMl6IZ4SulbBtg7G2Pd4VlS1d+U+MYFEKqJjayU/v7M8UCJS3KZtxm4rnO2XPd4ZtZtuO026zQO0oO5vp1HJbZ2zHjBHNafZTL+/5DAHWdOX9iFh3cGgUDg4Yx0fEeGk0azZvXWIxgejq9hho5TLmsZWbgYoSX7E+PmU220/l8lGXAZaBjoovjcA/JOgazOrydbq5M+KdHdkkltVZ0wZbuqDvGBwbPvPjC2mcIjGLi3Y7Sot487k49ZhMGSqoHGI41QTObCaCNC1iON34yFk8x6y2OcNzLOJr1SzbYbNoh2b5Wu20r6P+3nMhJCNIjBXiRcPgybj7geEYZM1GaxOs7zBWt8Us7dlEWGKTI2Su4RkEiYdN4YM9O+trarCsbgOP1TsY2Htb2CWSXzS03T/WrixJIJMxmnNiTTtsXmc80KdZBVgQs8LvPwrHh2Hdyri/ppzIZUopHyrnuSb6sFJHSMX/zWab8vzORD95qsfPZpulaMdZPMds2zHxb6a+15Qew2keP2U/pe9P9xwN+J4HQSE1CkVRKMLAiNh/TBwdiuuyziSx+Lk4Zx2sbrPSOiwfwXJTSOikjI/17Oe71W7MYqnbAAugV/y0D24F3oWxotrtcdVXnr7LJvEOp45WsWmN0bVSPNQ3u30MjcID/WLTWqOzDVa2lO6UKuX2AfxK3S075TsHg+L04Mlx4+iQePyw8egBMTrLDIPZDKxfBVvWGZ0roLmcqb0cA89iqtLVOUmY3XWymH7CdlK3tTTqOgOQ7aBgufApwRdA49Vuj6u+8oV6kohcVqxojlfbG1YZrfnZ7SMIHumHux4KPNwPRwbF0KgYK4g0pdSDlDa2GTqTmf59hm1sFtucct9LuE2tvNbpA1vz3c9Zb7MA78eZnn+hXquAomCsAIMnxaET4sE+uHd3YM+R2Y1eQSzs3Lva6O2M9QbzuXjjhwdVrkQYBxNL333e6zlY7cYsproewQLofg2H9u0K78VsG9gzqPOg0p2eETuSxIxsIlY0xWSjm9bAmpUwcnh2+xkchR8/Dl0rxZp2m+g8hGjOGdlSxznR9y1AJ26z2GY2+1nUbaid11oTQdYSPf98X2s5Zgoh1uQcLcCJEXHwBOw+GAuj37M7FkyfrfYWOGdtHMVa0Qy5jEgqks15oNXgpGGMP19/LndWuymLrS6KPZ/Jjf+Vg4OjmYKZrgBrq3Z7XJXZ5DdBRhpgeNQ4MiSODDLrhbzjRThZgDQtr+mK0yMxmaJhVlpwXX4271hcDai8GzHmZxOF1DhZgBMnRd8x+Oke8S8Pwj27xaGBiiVrZ5BJ4JJN8KztxpYuY1UrNOVj3UFPMOoMFUH/nC3oD9uuZLTa7VlsDRFg3fAZdN3LtTuHrZPxDMNKmYpcI5p+sR+Ia07GCnHh+pFBZp0iYGAEHjsMaRCrVhjZTEyqaKVFWKc9yMrDaTN95TT/t0A3FRqLdsNfzd1otxDtqJX3fN6vtbzryrVWoZx+wRgYjiNX9+8TX/2R+ObPSp8FZieXga3r4fLtxlM3GxtWwYpmi3UHPbhyINADIeh3u99QP+VwTqchAiyAm/+RsTe9QrshebqhczD/uLsSla/kjeFR2HMkBluzNV6EwZFypxV7UZvo1ErJXUq9ajnVgNDkHW8TbSj1hir9+zTbaBbbTPybqfuNzal43Cy3mfwPm/g2TN/Gyjuc3OZsX+ustmHaNhVBxXzej1m91hm2OdPr0EK8VpvhtZ7u/Sg/NzGoSiXS1BgvitFxOHESjgwZjx2En+2NI1c/eChePMw2uAJY1wGXnwfP2JawrQs6VxjNeU3WHvQzboPTEOgPenbwlRuq3ZQlUvdrsCp998s8/IKXpH8WzM4D81qFDax8ss+U7yZcITathYs2Gj/fL36yhzklujw8CN/6mdh3RDxti3FBr7FpLaxtF23N5XpsimVDEpXuZtREJBabM30Y44nDGsJAqrg+mL7N6fbDDD+b6zacoY2zeR21ss3ZvtbafD9UOURWkSk1ToeLNMB4Mea5Gh6Lx+6ew+Kne8S/PiIeOQgDs0xZUpYY9K6GSzYZW7tiktGmPGQ8uHIAKJX4ZD7DZycvR+pfQwVYV36G9JFL+Ep+g33UEr0Rs5XVbpOrriSJgc+KJmPdSnHuhthJHBkS/cfj4t/ZCIrTKYMny3dgwbkb4Jy1xtp2sbI1LvhtrkjnUA6yJjsfTfta+fPSqFXp/8xm2ma62fxsgbeZkvp8nvt5Qvr0eezHmCFCrsL7sRTbTHutlcdJ+auI09iFYlzIPjRaGrkqBVcP98MPHxOPH47T5XNhQFszbO82tm0wulbGf+cyXh7HASgIfkw2vGfdaxisdmuWUkMe+gc/zoZCwW437KWe5b2xibhIvZDGwKj/ONy7G751v/jBAzG54lxlMzG7e1cHdK+CjWuM7s6YDqKzrbQYPlu6dR0mZn0mvk5v4/RYo1T30EcFGs/0X/kpw7Ew+e9y0fFigJNjcGQoXgD0HYe+o2LfUTg4ECsZzKZc1HSr2+DpW+GXnpLwjK2woZM4apvFR6+cjHBAqa7qvpYvNdLoFTTYCFZZ11X0P36L3pfJ2jaDi2jQQNPFX3ySQFaxZtrqNji/O17h7z/CvAKsYhqnXY4MwkN9sKpNdK+C3jVGT6doaTJyCWQqFv9mKq70Kw/GiQ6y/I9yu09zxE5//Hy2OVNHfsp9VMy+zbsdc9jHKdu5EO1YwP+f6z6mb2MVx0b5pU1/rZX1LlWxUXntVTGFwdF4l+C+I2L/sXhTRyGd23R4pUwC522A51xgbO+GzrZY4zObmdpu15iExpA+0r2aLzdacAUNGmABbDrI9w70hFsDyTvBOvAgq2GVg6xcNk5tdHXE6Y5nbItlQvYdjZ3QXAkYT+HQQMwjtPdITGyay4rEJoOryjuspndI0tTOr7y6plY7rlMWR57TTjjrU/GCtKOGWMU3E29PxTKyylnZKQOemvgxQXF6cPhkXHs1Vjy796i87upJ5xjbu431HUZbs2jKmt816ABCgr4yJm6xK5nHGXT5a+iPwN4PsSbTlLw/wH82bJZ5vF09kkpThUEMj8KhE/Dz/XD3w+LOn4rdBxbu8ssm/lqA/biGV7nM/UzH6EIFnQb0rI4jV8+/yLhkE3R1GK1NIpe1yVQlrnFJD4rw272vq99ag2fSsCNYABt/hyP7Pxzen+TtEsGleH6shmUWf/tZjJa86GyLi9SRcXIcRgvi4MD8RrKmmz7dd1b7cY6lPRYyCazviMlEL99ubFsfpwZb8nFhe8bPoI1OSMMJ9v694q5qN6aaGiYP1qnc+EUOv/llPJpk7EU+VdjYykVozeIVeDYDrU0xWWJbc7yj8PjJud9l5Vy9yCZwcS+88BLj2efDBT3G+k5oa4GmrHlaBoekQgIfl8KNF+xgrNrtqaaGD7AAbnwmjw61WSLjMsNa8CCrIU1kFzJIkljeI5cxWpugo9VY0RSDrOGxmFy0ntb4OHc6ZrCiCS7cCC98kvGs84xz1xvrOqC9OeaSi+VwKnO0uYYjFc30tbGC3nzO6zlW7eZUmwdYwA3fQL/zYv0sm7Me4JJS6gY/SzSY8pV3eRF5OcjKZ2P+qvZmo2MFtOSNQjEGWvO5rd255SSTxOLNV2w3nneR8bQtxpZ1sKY93hQyGVzhwVUjEwH0Y0x/dM613Fft5tQC/zRU2P8RNiu1W83sJZivx2pkE/XaQlx3NTouBkfh8AnYfRB++Kj4t0fEQ/0xuWjw0SxXZxKLU+Qb18Dl5xmXnRcDq7XtsLLVaM6JXMZiPrfET5YNTpj2koY/6N7BpxsxJcNMGnqR+3Q91/DY/tv1x2BbEds5Q61eV7/KF+JJAnmDhNiR5DOiOQcrW4ze1cZPHhc/2xcTlA4Me6Dllj8z6GiNKRjO745ln87vhk1rYHW70dIELblYBidJStnaXSMTaBhxy1ie/+XB1SSfIpzmzy7lwPAqHQB7IbJWD7IaV3mq0IhX6JlEZDPQlIuLete0xZxZa1ca+awxOh7zXvkieLccmcWp8J5OuPRceO4FxjO3xxQMm9ZAZ3up3FPWyGYmKxH4rGBDE9K44I5kNLxv07WcqHaDaol/NGagO8j0nUh2EvjdUr1Cf58aXDnhZyyWa4wVxchYrOd2cAD2HIbdB8TeI9A/IE6MwOg4jIzD8GhM8OjrtVytyJTWFrbk4+L1FU2xQHPXylik/Nz1sGmdsa4dVrbGqcJ8Nt70cbrEuK7BSEVM30tTXb3pWh6sdnNqjX88TuGxW+jM5ZIPSbzSzJOQ1pPy3X9z7RzK67IUIBUUUjFegJExGByFgZH45+gQHB8WRwbh4AnYdxT6j8W6hsOjM08jnumORO/I3EJISncDdrbB+lXQvcomRmFXt4nVbUbnihhUtTXHbZtykC2vtcLrC7oSKYDuN/SW7tfxT9VuTi3yj8lp7L2N8xOzjyB7bmnRu2twk/XeRJARJIopjBeNsYIYK8aCuiPjMDgCR4ZjqZwDAzHgOjYUk5amYTLhaCj9KZc5mcjHBROlUcwMMz2hHVDu7GxiB9NjNZvyl2YM5pZ2H098DfPax7J4rQuzD0mT/6/Jh5X3YaYpKd0rj53ycyUGzTlj1YpYc7OrIwZXq9uhoyWOUrXmY0CVz0E+a2QzIpvYxDorD6xciYQOEMI7enfwkWo3plb5x+UMHr+VF2ST5BOYbcbfr2VLWtjOoRwclUe10lD6k4pi6c7DscLkNOHIWCwgPVqI/xfCZDBFxdepFX4rvpyh7WcqlTKbUioLso/JeOGs9nG6Eb2l2MeSvV/z3EdleZxTvVabIcDKZWIx5tb8ZEDVUhqlymViItFMApnSVODEdKD5yc9NkKHhEPhQrhj+tOs6hqrdoFrldxGewcP9fPeC3vAOSG4CW4ufZxxTgx4DrLToV1kjhDi6taJJFFOLI1xpHOkqpnF6UaX1WJWjEirvrGKEouJp/MhzUwOtWVw0TBkFBZLScZrLlP8YmYziHYEVAdX04My5Eikuav9icxI+vMaDq9Pyj84s3P06ct3PTN5u4o2YdVS7Pa42VdYYLC+KD1P+xMCrPPIFQlTc1GzlHdi0vdq0H8+wjaYPMcy0DdN6y2nbSDMMl03fBrBTtHHKt6d5HQvxWpnFNqd7P2ZciLfAr3U22yzia52M0VUxzVwazYKJFAtJKfryaUB3Biplav+Wmf77hmv4SbUbVOv8ozRL+3fRKkveC1xjZs3Vbo+rfRPTf6W/njDNc7q5I+cWwKmCpSlrtHz6z82CoVRBPyLRa3teyz3Vbs9y4J+rOTj8F/SOZZI/M+yVmE+vutOrHCTxYMrVKh+xcrMg0COE8Hs9O/gsp19a6Eo8SJiDta9n3/7bwzsTbK2wXxDm7587pcqOyzsx59zyJAEHUHjPfvgCHlzNmmdyn6P2Szl6aQf3Cy4HusDTNzjnnKtLAoYshPcBH71gB2PVbtBy4tfV8yBhe2/npRmzD4Bt9/EJ55xzdUZIo1j4y+w4b/N0DHPnoy/zYIY27udLBN2AOFjt9jjnnHMLS0WJzyXHeasHV/PjAdY82U7CoRN8FoUPggbxeWnnnHP1IYC+Y5nw+xveynC1G7NceYB1Fp76VoZDgVtR+JjQGB5kOeecW96EdH9a1O/3XMNj1W7McuZrhxbAwQ+zoZCzW8zsV8ELQzvnnFuOJOBwSMJ/3Hg1X692a5Y7H8FaAF3X0Z8t6i1I3zGUVrs9zjnn3DwcM7PrPrKHO6vdkHrgI1gLaM8tPCWTtZvBnot5jiznnHPLgkBHQuB/9O4It5ovd1kQPoK1gDa9gR8p0dsx3Quk+EHqnHOutgnpOOKm3r5wuwdXC8dHsBZB3y5eRGI3S3YhZhn8fXbOOVdzJBODAT7QMxTeY2/mZLVbVE98BGsRbNjBN9Kg60EPAKHa7XHOOeemkWAkJPyF7Q/v9eBq4XmAtQgM1LuDbyQZ/SHoAeRBlnPOuZoh0BDiYyMj4f/t2clItRtUjzzAWiQGWr+HfzTC/5BpdynI8rlt55xz1SSkYQU+PnQivHP79ZyodoPqla8NWmT6Otl9P8/8pySjdwIbS8Wh/X13zjm31AQ6Kfib3Hh4R9d19Fe7QfXMR7AWmb2IYv+96act2J8IHSglcnPOOeeWkiSNS3w2FMNOD64WnwdYS+Cy2ygc7Us/bdj7EYfwqULnnHNLSmNm+kKxGP540+vZV+3WNAKfqlpCj3yc5qaU15uStwjrxt9/55xzi0xo1KR/TIP+aNO1PFjt9jQKH8FaQluvYpSUXVJ4H9Ihny50zjm3iAQaTeDzhaA/8eBqaXmAtcR6djAyPMqtlvAupCMeZDnnnFsEAo0R9MViGt6++Vruq3aDGo0HWFWw/XrGju4Nt6WytyP242uynHPOLRxJGpX4Pxb0ez5yVR2+BqiK7t5FrifJ/Eekd2K2Bf99OOecOztCGsb4u0DYufG17K12gxqVd+hVdvcucj3iFSTJe8w4VzFPlnPOOTdXUgyuPpYP4T3rdtBX7QY1Mu/Mq+yyHRR+3s/n0hCuB+1G8rI6zjnn5kgSGkF8wkJ4lwdX1ecjWDVCO0n2dfPCjNkHRXIR5sGvc865WRFoKMBtrSG8a/UOBqrdIOcjWDXDdhJ6+7gzlX4XC/d6gWjnnHOzIEkDCtyUPR7+xIOr2uEjWDVGO0n6e3h+MHuPyS7HfE2Wc865U9ERxAfSoXDjpjdzstqtcZM8wKpBAnv0Np7abHYL2GXCctVuk3POuVoiSQwk4h37CLsu20Gh2i1yU3mAVcP6b2drKrvNsF/ALFvt9jjnnKsJAh01s9/bcE36V+a5FGuSTz/VsA2v5ZEk1Wsx/lpotNrtcc45V10GAfQAaXj1hr3pJz24ql0+grUM9P8FXWmSvMWMazBbhf/enHOu0QgpBf2LEr2t9xq+U+0GudPzjnqZ2HMTLZkV7JDZWwzrxszw359zzjWCWFcQfSNNdb2XvlkevINeZvbdym9ZYjeAbSvdYei/Q+ecq18yaRi4o0nhzZ6GYfnIVLsBbm6uaOFn52zlAZldbFgXho9kOedcfRLoiBFubpJ2enC1vHjHvAxpJ8nBjTw7lb1b2BWGNeG/S+ecqyMKwF5CuHF4jL/cfj0nqt0iNzfeKS9j+z7KBRbs3WAvA2vFf5/OObfcCSkVesTQDd37+YztZLzajXJz5x3yMtd3M+vUnLwL+E3M2sGnDJ1zbpkSUtFM96Sp/rj3Wr7maRiWL++I68Bjt9CZy/EmKdlhsNbL6zjn3LIjpFEzfZ2ibtjweu7y4Gp58wCrTuzfRWswfiODvRXsInnmd+ecWx6kAByV+JtQDB/ceB0Pe3C1/HmAVUckbN9HeFYiexdmzwVrqXabnHPOnZJMSoPp0SB9qDjMJ7a+iePVbpRbGB5g1aH+29kalLzd4FUy2sH89+ycc7VFoIKkew29r/t1/B8ftaov3vHWqfvfS3vH6uTVgj8E68XrTjrnXK0Q6KQFPofCu7qv5b5qN8gtPA+w6thPd5Lv3MAvYvaHmD0bs1y12+Sccw1NBFBfxthl4+H2ruvor3aT3OLwAKvOCezg7Tw5VfIHGC8Ha692m5xzriFJRUz3I72P/fxDz05Gqt0kt3g8wGoQj3+Qnmw+uY6E1wJrwFM5OOfcEpFQAembielPN1zDnWa+3qreeYDVQB68maYVLZlfRXo32AWYr8tyzrnFp2HEJ7OFcINPCTYOL/bcQD74T6TPatYDW7bpLhnrgM2+Lss55xZNAO1G9o5kINy4/o0cq3aD3NLxEawGJLC+XWySJVeb8RqDbmEebDvn3MKQpFFDXyKjG7v38H3bSbHajXJLywOsBrbnJlqSVn7JsvY2ZJeBNeHHhHPOzZ8UMPUp6PZswq3rX8uBajfJVYd3po7DN9E73p68HfHqUsFo55xzc6bUTHdn0NvWXc23zQjVbpGrHg+wHBBHs6yNVySWvAO4CJ8ydM65WZIkjiM+kif8f+t20I9nZW94HmC5CdpJ0r+BC2XJ20j4d2Ad+DHinHOnJhVk+omlejfGP/fs8NxWLvLO0z3BnptoybTzWiP5XYmtmCX4seKccxMMgtAJg88lIbxz/Q4ernabXG3xTtOd0r6P8HRk7zfseYgcZoYfM865xiYkmenRYPqfIyN8cvv1jFW7Ua72eGfpTmvvh1iTySfXCa7GrBfPneaca1wBadgS+7qK6bu+/VX+9crPkFa7Ua42eYDlzkg7Sfav44okZ28S9hLMVuLHjnOucQhpHOO+ELg9TcPfbn6DJw11p+edpJu1h3fR0QK/iSXXA+dilsePIedc/ZJJqeCoxOek8KGN1/LDajfKLQ/eObo5O3Qb5xcseTvwMsQaX5vlnKszApA0CvqRFXXzsYP8/SU7Ga92w9zy4Z2im5e7d9K6sYdfS8m8EdPTDcvhx5NzbvkTQmbqN/F3QeED3TvYY57Xys2Rd4hu3nbuJPntXjbnlFxrcCWwEbNstdvlnHPzJKQhTN8qBv15muebW69itNqNcsuTB1jurOlmmvpbeLGw14G9wLAOQVLtdjnn3GwJjZv0sCX2l2Np+OSWHfRVu01uefMAyy2Ygx9nQ1pIXh3Q1Wa2DZ82dM7VNoEEHDfxhbQYbtn4Br5f7Ua5+uCdn1tQX99J9sIenh4seaPBL4GtwXNnOedqj0Bjku5PlHwgU0z/oes6hqrdKFc/PMByi+KxW+jMZPilxOy/gT0Pox3Mpw2dc9UmUFHiIcTfZQmf6urjEdtJqHbDXH3xAMstGoHt+SDd2TyvILH/AvY0sFb8uHPOLT0hpaB9mH2WNHzyWD8/8tQLbrF4R+cWncD23cb2LMl/SdErfX2Wc25pKSCOYvomQbuAb/fsYKTarXL1zTs4t2TuuIPM8wZ4mizzOwT9mmGrML/b0Dm3aAQqGHavSD/cHPj86h0MVLtRrjF4gOWW3P3vpX3lGp6L7L+b7Dkya8ePRefcQpIKGA+Z+Bhp+PsNa9hjV3phZrd0vFNzVbPvw2wix6+D/baZPRksix+Tzrn5E5LM6E/F5wnhEyfHuXf79YxVu2Gu8Xhn5qpKO0keW8PmpubkvynoN0jsPLAm/Nh0zs1eLMpsOizszmwIH0t9nZWrMu/EXM049EF6CvnkWkz/FWxjXJ9lfow6505FSAKGZPqmBb13LM/dXt7G1QLvvFxNuft15M65nM2pkt8SXIXY5PUNnXNPIAJoSKY7M6n+fHCcu867nkEvyuxqhQdYribdvYvc2iLn5bLJlRivTozN8jVazjmQ0ADS1y3otmzKtz0Du6tF3lm5mqadJPt6OM9IXmOmfw+2GSyPH7vONRgFxKChOzHtOrqPr3iSUFfLvJNyy8YjH2ZDcy55Y0C/ZVgPRqZ0CPtx7Fz9KU31ScCwpLuU6k97r+XrZj4N6Gqfd0xuWdFOkr61bEqaktcG8Z8xejwrvHN1RwhhGsTsu1ZI3zd6gO9v3emL193y4Z2SW5bueBWZZ7+YbdlM8mtB9kozXVKqc5jgx7Vzy5HiXyoksE/ia5aGT9kQd214K8PVbpxzc+UdkVv2Dn6cDcUCvy6zVxn2FBMdMl8Q79wyUU4OelJiD/BPRvj0hlXc65nX3XLmHZCrG3oVmb4X8xKS5NXA82VsMMj5Oi3nao4ATEoDDBr6Keh/Zwv8Tdd19Fe7cc4tBO90XN3RHWT6j3JByCRvMHgZ0Ot3HjpXM0pZ1xlA9gMs/eiJo3z5wt9nCM9h5eqIdziubt29i9zmLNsKIfkNZL9upgsFK8CSarfNuQYk0DiiD+ObInxqPMtdW6/ieLUb5txi8ADLNYT9uzhHGX45kb1S2CWIdWaWU/wM+OfAucUh4mjVEOhRk329kIZ/2HeSe5/zZk5Wu3HOLSbvWFxD2b+T1rCBZ2PJyzOJflFiC2blUS3/PDh39mSxQGBB6KAZ9yTSP6bj/N+e69jrpWxco/AOxTWs47fQOZbjFUXZr5vZ5cDaUk4tn0J0bj5K9QExHgL+qVgMf/uxA9y3cyeh2k1zbql5gOUa3v0fpb3d2K40eWki/TJmT0J0YJbBPyPOnZ4ImEaBvYg7EwtfMPh+VweHPc2Ca2TeeTjzfOWMAAAFiElEQVRXcseryLzopawfTXlWxpKXGjxXsAXRgpmv1XJukkAFxBEz/auCvpxk+ErhBA9v8rVVzgHeYTg3I91M06FmLhoXL0oS+2XgErB1QB482HINJ+atQkXBINKjmH3b0vAlxrmr+3oOVbuBztUa7yScO4M9N9GSW8FTQpK8SNjLQReaWFWaQnSuvsUpwBGJPoNvEMI/54zvrdtBX7Wb5lwt8wDLuVnSHWQOHaLF8lxQEM8DewlmlwGdXnDa1REhSTBkxsOm8FXga1nxb8fHOLr9esaq3UDnlgPvEJybB91Bpu8YnQmcWxTPtcSeZ2bPBNYCTaVpROeWCyGlwKASPQD6lsF3xsUPMx30b7rS11U5N1feCTi3AI7fQudg4Pxsnl8Ae76MJ0m23iCPeeZ4V5NUWlM1ZOhBZD8IFr7KOPf2ZOm3HRSq3UDnljMPsJxbYPt30WpiSzHhJVmzVwDbBF2GNQsSLz7tqiQmABWpmY4G0Q/2HSn8fSbHTzZcxWEzTwLq3ELxk7xzi0TC7ruBXFc3a8YD25ThBWaZX03QeQE6zddtuSWhVGLYoB+4M6PwxUKB+/LG/m98g5NXfsZzVTm3GPzk7twSuXsXuW3QOp5hU1rkEkuSZ2O8QGKLQbsnNnULQEjCGEEcxnSvpG8kRX6UzfDAUJ5jW65izMvVOLf4/GTuXJXcvYvceSltg/CUXD55Tgh6JmZPRXRh5P3ORDcLAgVgDDEo9KCC3WOE71mW76cnOLjxTYz61J9zS89P3s7VCL2KzEPPZ0VbG08PxeRliemyIDYZtt6MVomMZ5RvaAJhkEoUhI6asQ/sftLw5dEi39r6I/bbbb443bla4Cdq52qTaSeZw5toGRumI9PCFVLyUjMul1iP0QGWxz/DjSCABoHjkh5G9s9S+L8aYU+xk5Etv82Yj1A5V3v85OzcMvLIx2lmlA2tOXrTlEtF8pwk4RLBOqAdrAlh2MRn2z/jtU0TXwUyFYkL0o+baXcq+5eMwncwHk3H6e/9HY76+innlgc/+Tq3zD38HjpaO7hA2cz5krabsR10nmTdGK0GzYRSPq74ifdpxqVXGUhJqJgYoxKjGMeQHhH2EOIBs/CgCtzXc4h9tpNQ1VY75+bNT7LO1ak9N7GaZp6cyfFUSC5EOgfYaGbrg2gFcomRlchYnGOqPB/4uWHuVPGdYqIOiogCxhjSUYx9AdubgYex8NPiMP/20DEeedFOilVst3NuEfhJ1LkG8fWdZH9hNZl9CW1JExdDcqnBUyTbCFqN0SnRadAss4yJBEhK041+rpiqHEwFIEUSUMAYQBwnsSOk4XCQ/TxJwj1pgR8yxr6NKyjSR+ojU87VPz9pOtfYbP9OWpL1tFkTbYUiKxNYj9giknMtYQvSBrCVZrQL2oFWiWxiliBMhpXWfdVLSSDFEaj4R6ZgIo2jUAxhDIINQjhq2KNB4VGJ3YLHMzAQxhhqbWKws5Mhu9KTeDrXqDzAcs6dlu4gf3CAzpCyRjlWK7AmMTaFNOklYa1JnWasErRLNFnM4dU08b3RpEDOYgAWR8MUi2FbXLE9cR4yShNrk2emM52jNOW7aXfTmZAAszjERBxxEpACY8B46euYpPK/TybGMcmOYxwx0S/CXsGBYpFjwTjSlufIuqsZnM/76ZxrDB5gOecWxN27yPVAR3GMjkxCh3J0BOjIJawMosOgQ9BhSlaa0RLiGrCMpKzFtWBZQdZEloSMAjlLyBhkJLJAXmBmFIECoqgYKBUtrnUqYhQNihJFIDVZUUZRxniiMCQYEAwYDAQYSGAgMQbCOAO5wEA6ysD6tzLid+o555xzzjnnnHPOOeecc84555xzzjnnnHPOOeecc84555xzzjnnnHPOOefckvj/AZTB4D/316QKAAAAAElFTkSuQmCC", 0);
        startimage.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
        startimage.setImageAlpha(150);
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);

        this.mExpanded.setVisibility(View.GONE);
        this.mExpanded.setBackgroundColor(Color.parseColor("#E2131619"));
        this.mExpanded.setGravity(17);
        this.mExpanded.setOrientation(LinearLayout.VERTICAL);
        this.mExpanded.setPadding(0, 0, 0, 0);
        this.mExpanded.setLayoutParams(new LinearLayout.LayoutParams(500, -2));

        ScrollView scrollView = new ScrollView(getBaseContext());
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(300)));
        scrollView.setBackgroundColor(Color.parseColor("#E2131619"));

        this.view1.setLayoutParams(new LinearLayout.LayoutParams(-1, 5));
        this.view1.setBackgroundColor(Color.parseColor("#E2131619"));
        this.patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        this.patches.setOrientation(LinearLayout.VERTICAL);
        this.view2.setLayoutParams(new LinearLayout.LayoutParams(-1, 5));
        this.view2.setBackgroundColor(Color.parseColor("#E2131619"));
        this.view2.setPadding(0, 0, 0, 10);
        this.mButtonPanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));

        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams3.gravity = 17;
        
      //  mExpanded.setVisibility(View.VISIBLE);

        new LinearLayout.LayoutParams(-1, dp(25)).topMargin = dp(2);
        this.rootFrame.addView(this.mRootContainer);
        this.rootFrame.addView(this.mRootContaine);
        this.mRootContainer.addView(this.mCollapsed);
        this.mRootContaine.addView(this.mExpanded);
        this.mCollapsed.addView(this.startimage);
        this.mExpanded.addView(this.view1);
        this.mExpanded.addView(scrollView);
        scrollView.addView(this.patches);
        this.mExpanded.addView(this.view2);
        this.mExpanded.addView(relativeLayout);
        this.mFloatingView = this.rootFrame;
        if (Build.VERSION.SDK_INT >= 26) {
            this.params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            this.params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParams4 = this.params;
        layoutParams4.gravity = 51;
        layoutParams4.x = 0;
        layoutParams4.y = 100;
        this.mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        this.mWindowManager.addView(this.mFloatingView, this.params);
        RelativeLayout relativeLayout2 = this.mCollapsed;
        LinearLayout linearLayout = this.mExpanded;
        this.mFloatingView.setOnTouchListener(onTouchListener());
        initMenuButton(relativeLayout2, linearLayout);
    }
    

    void AddCheckBox(final String name,final int TZ) {
        CheckBox CheckBox = new CheckBox(this);
        CheckBox.setText(Html.fromHtml("<font face='roboto'>"+ name + "</font>"));
        CheckBox.setTextColor(Color.parseColor("#FFFFFF"));
        CheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
					if(TZ == 2001)
					{
						try{
							Runtime.getRuntime().exec("data/user/0/ /data/data/com.tencent.tmgp.pubgmhd/lib/libFal.so");
						//执行
                            }catch (IOException e) {}
							}
					if(TZ == 2002)
					{
						try{
							Runtime.getRuntime().exec("data/user/0/ /data/data/com.tencent.tmgp.pubgmhd/lib/libFal.so");
							//执行
						}catch (IOException e) {}
					}
					if(TZ == 2003)
					{
						try{
							Runtime.getRuntime().exec("data/user/0/ /data/data/com.tencent.tmgp.pubgmhd/lib/libFal.so");
							//执行
						}catch (IOException e) {}
					}
					
					if(TZ == 2005)
					{
						try{
							Runtime.getRuntime().exec("data/user/0/ /data/data/com.tencent.tmgp.pubgmhd/lib/libFal.so");
							//执行
						}catch (IOException e) {}
					}
						
					if(TZ == 2006)
					{
						try{
							Runtime.getRuntime().exec("data/user/0/ /data/data/com.tencent.tmgp.pubgmhd/lib/libFal.so");
							//执行
						}catch (IOException e) {}
					}
					if(TZ == 2007)
					{
						try{
							Runtime.getRuntime().exec("data/user/0/ /data/data/com.tencent.tmgp.pubgmhd/lib/libFal.so");
							//执行
						}catch (IOException e) {}
					}
					
					if(TZ == 2008)
					{
						try{
							Runtime.getRuntime().exec("data/user/0/ /data/data/com.tencent.tmgp.pubgmhd/lib/libFal.so");
							//执行
						}catch (IOException e) {}
					}
					if(TZ == 2009)
					{
						try{
							Runtime.getRuntime().exec("data/user/0/ /data/data/com.tencent.tmgp.pubgmhd/lib/libFal.so");
							//执行
						}catch (IOException e) {}
					}
					if(TZ == 2010)
					{
						try{
							Runtime.getRuntime().exec("data/user/0/ /data/data/com.tencent.tmgp.pubgmhd/lib/libFal.so");
							//执行
						}catch (IOException e) {}
					}
                }
            });
        this.patches.addView(CheckBox);
    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = FloatingModMenuService.this.mCollapsed;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        this.initialX = FloatingModMenuService.this.params.x;
                        this.initialY = FloatingModMenuService.this.params.y;
                        this.initialTouchX = motionEvent.getRawX();
                        this.initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - this.initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - this.initialTouchY);
                        if (rawX < 10 && rawY < 10 && FloatingModMenuService.this.isViewCollapsed()) {
                            this.collapsedView.setVisibility(View.GONE);
                            mExpanded.setVisibility(View.VISIBLE);
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        FloatingModMenuService.this.params.x = this.initialX + ((int) (motionEvent.getRawX() - this.initialTouchX));
                        FloatingModMenuService.this.params.y = this.initialY + ((int) (motionEvent.getRawY() - this.initialTouchY));

                        FloatingModMenuService.this.mWindowManager.updateViewLayout(FloatingModMenuService.this.mFloatingView, FloatingModMenuService.this.params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

    private void initMenuButton(final View view2, final View view3) {
       
    }

    

    boolean delayed;
 
    public boolean isViewCollapsed() {
        return this.mFloatingView == null || this.mCollapsed.getVisibility() == View.VISIBLE;
    }

    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }
 
    public void onDestroy() {
        super.onDestroy();
        View view = this.mFloatingView;
        if (view != null) {
            this.mWindowManager.removeView(view);
        }
    }

    private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    public void onTaskRemoved(Intent intent) {
        stopSelf();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        super.onTaskRemoved(intent);
    }


    public void Thread() {
        if (this.mFloatingView == null) {
            return;
        }
        if (isNotInGame()) {
            this.mFloatingView.setVisibility(View.INVISIBLE);
        } else {
            this.mFloatingView.setVisibility(View.VISIBLE);
        }
    }

    private interface InterfaceBtn {
        void OnWrite();
    }

    private interface InterfaceInt {
        void OnWrite(int i);
    }

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }

    int convertSizeToDp(float f) {
        return Math.round(TypedValue.applyDimension(1, f, getResources().getDisplayMetrics()));
    }
   

	



    
    
}


