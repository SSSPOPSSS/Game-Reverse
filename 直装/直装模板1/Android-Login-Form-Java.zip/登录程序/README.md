# Aviso - Warning!
Br: Eu estarei usando o meu idioma nativo para descrever esse projeto, então caso você não esteja entendendo nada que estou digitando, utilize o tradutor do seu navegador. Obrigado!<br></br>
En: I'll be using my native language to describe this project, so if you don't understand anything I'm typing, use your browser's translator.  Thank you!

Obrigado a todos pelo apoio!

Contatc Telegram @Hyupai

**Esse Server é apenas para utilizaçao dos meus outros projetos**

# Customização!

Sinta-se livre para mudar o Fundo, cores das letras e até mesmo remodelar o layout.
Se você nao sabe o mínimo de PHP e HTML isso pode ser dificil para você. Mas nao venha no meu privado chamando para te ajudar.
Pesquise no google.

# Server

Nessa versão eu adicionei algumas coisinhas:

- Proteção basica no painel;
- Layout mais moderno
- Nova tabela no banco de dados
- Pagina de consulta

Recomendo que você salve sua DB.php e simplesmente upe tudo de novo. Ou se você preferir simplesmente faça upload dos arquivos que você ainda nao tem.

Deixe-os espalhados dentro da public_html.

![](https://i.imgur.com/FrRDiZy.png)<br></br>

Quanto ao Banco de dados, simplesmente cole o codigo que eu deixei nesse repósitorio. Caso você ja tenha a tabela tokens, simplesmente cole o outro codigo no comando SQL

![](https://i.imgur.com/JZybRQL.png)<br></br>

Agora, basta adicionar um usuario em sua tabela usuarios clicando em `Insere`. 
**Lembre-se que a senha tem que ser adicionada em MD5.**

![](https://i.imgur.com/GSNcJSQ.png)<br></br>

# Testando

Feito isso agora é so você testar a proteção.<br></br>
![](https://i.imgur.com/GzSbwcn.gif)<br></br>

