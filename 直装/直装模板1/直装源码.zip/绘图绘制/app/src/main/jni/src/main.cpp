#include <pthread.h>
#include <jni.h>
#include <cstdio>
#include <cstdlib>
#include <fcntl.h>
#include <unistd.h>
#include <cmath>
#include <dirent.h>
#include <thread>
#include <sys/uio.h>
#include <sys/un.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <sys/socket.h>
#include <malloc.h>
#include <math.h>
#include <thread>
#include <iostream>
#include <sys/stat.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <iostream>
#include <locale>
#include <string>


extern "C" {
	JNIEXPORT jstring JNICALL
Java_SONGZI_NB_DrawService_ESP(JNIEnv *env,jobject activityObject,jfloat PMX,jfloat PMY) {
	FILE *fp;
	    char buff[65536];
	    fp = fopen("/sdcard/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Game.ini", "r");	// 读取文件
	    fgets(buff, sizeof(buff), fp);
		return env->NewStringUTF(buff);
		}
JNIEXPORT jstring JNICALL
Java_SONGZI_NB_StaticActivity_getDL(JNIEnv *env,jobject activityObject,jstring KM) {
	return KM;
}



JNIEXPORT jstring JNICALL
Java_SONGZI_NB_DrawService_PinenutNB(
        JNIEnv *env,
        jobject activityObject) {
		std::string BQ = "Vm10U1RXSnRNRE5XUnpsMlRrWldibFp0Y0Vaa1ZURnVVRlF3UFE9PQ==";
		return env->NewStringUTF(BQ.c_str());
}





















































































































































































































































































































}

