package SONGZI.NB;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Process;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import android.content.Context;
import android.widget.Toast;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import android.widget.Button;
import android.view.View;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import static android.graphics.Typeface.BOLD;
import android.os.IBinder;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.view.SurfaceHolder;
import java.io.File;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import static SONGZI.NB.StaticActivity.cacheDir;
import android.graphics.Canvas;
import android.annotation.SuppressLint;
import android.view.Display;
import android.graphics.Point;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TableRow;
import android.content.res.AssetManager;
import android.content.SharedPreferences;
import java.io.DataOutputStream;
import java.io.IOException;
import android.widget.EditText;

public class StaticActivity {

	static {
        System.loadLibrary("Pinenut");
    }
	
	public static native String getDL(String KM);
    public static String cacheDir;

    public static void Start(final Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            context.startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION",
                    Uri.parse("package:" + context.getPackageName())));
            Process.killProcess(Process.myPid());
        } else {
            context.startService(new Intent(context, FloatingModMenuService.class));
            context.startService(new Intent(context, DrawService.class));
        }

        cacheDir = context.getCacheDir().getPath() + "/";

    }
	
    static void Login(final Context context) {
		final LinearLayout linearLayout = new LinearLayout(context);
		linearLayout.setOrientation(1);
		linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
		linearLayout.setPadding(75, 75, 75, 75);
		final AlertDialog.Builder builder = new AlertDialog.Builder(context, 5);
		final EditText editText = new EditText(context);
		editText.setHint("请输入卡密");
		editText.setHintTextColor(0xff979797);
		final TextView textie = new TextView(context);
        textie.setTextColor(Color.BLACK);
        textie.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
		textie.setText("T2直装-V1.2");
		textie.setTextSize(20.0f);
		textie.setGravity(0);
		final TextView textVie = new TextView(context);
        textVie.setTextColor(Color.RED);
        textVie.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
		textVie.setTextSize(13.0f);
		editText.setTextColor(0xff0e47a1);
		editText.setSingleLine(true);
		Button Butt = new Button(context);
		Butt.setText("登录");
		Butt.setTextSize(13.0f);
		Butt.setTextColor(0xFFFFFFFF);
		Butt.setBackgroundColor(0xff0e47a1);
		Butt.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
		Butt.setOnClickListener(new View.OnClickListener() {
			@Override 
			public void onClick(View view) {
				String nn = editText.getText().toString();
				if(nn.equals(""))
				{
				Toast.makeText(context, "卡密不能为空!", Toast.LENGTH_LONG).show();
				}
				else
				{
				String KM = editText.getText().toString();
				String PD = getDL(KM);
				if(PD.equals("32"))
				{
				SONGZI(context);
				Toast.makeText(context, "" + getDL(KM), Toast.LENGTH_LONG).show();
				}
				else
				Toast.makeText(context, "" + getDL(KM), Toast.LENGTH_LONG).show();
				}
			}});
		linearLayout.addView(textie);
        linearLayout.addView(textVie);
		linearLayout.addView(editText);
		linearLayout.addView(Butt);
		builder.setCancelable(false);
		builder.setView(linearLayout);
		builder.show();
}



	static void SONGZI(Context context)
	 {
		 context.startService(new Intent(context, FloatingModMenuService.class));
		 context.startService(new Intent(context, DrawService.class));
	 }
}
