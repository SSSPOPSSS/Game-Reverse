package SONGZI.NB;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import static android.graphics.Typeface.BOLD;
import android.os.IBinder;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.view.SurfaceHolder;
import java.io.File;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import static SONGZI.NB.StaticActivity.cacheDir;
import android.graphics.Canvas;
import android.annotation.SuppressLint;
import android.view.Display;
import android.graphics.Point;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TableRow;
import android.content.res.AssetManager;
import android.content.SharedPreferences;
import java.io.DataOutputStream;
import java.io.IOException;
import android.widget.EditText;

public class FloatingModMenuService extends Service {

    public View mFloatingView;
    public TextView textView;
    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    public LinearLayout mExpanded;
    private RelativeLayout mRootContainer;
    private RelativeLayout mRootContaine;
    public WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    private LinearLayout patches;
    private FrameLayout rootFrame;
    private ImageView startimage;
    private LinearLayout view1;
    private LinearLayout view2;
    SharedPreferences configPrefs;
    
    private static boolean ks,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10,k11,k12,k13,k14,k15= false;

    public static int py1=100;//自瞄范围初始化
    public static int py=0;//自瞄范围初始化
    public static int pY=0;//偏框修复
    public static int X1 = 0;//左右偏移

    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }
    
    private void Game()
    {
		AddText("裸奔功能", 15, 1, "#000000");
		AddCheckBox("自瞄",9);
        AddCheckBox("无后",10);
		AddCheckBox("防抖",11);
		AddCheckBox("聚点",12);
		AddCheckBox("除草",13);
		AddCheckBox("范围",14);
		AddCheckBox("黑天",15);
		AddCheckBox("视角",16);
		AddCheckBox("瞬击",17);
		AddCheckBox("跳远",18);
    }
    
    @Override
    public void onCreate() {
        super.onCreate();
        initFloating();
		Game();
    }
    
 
public static void RunShell(String shell) {
        String s = shell;
        try {
            Runtime.getRuntime().exec(s, null, null);//执行
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    

    public String LJJQ()
    {
        String sb = "" + getFilesDir();
        String str = sb.substring(0, sb.indexOf("files"));
        return str + "cache/";
    }
   
    void ASeekbar(String seek) {
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(convertSizeToDp(15.0f), convertSizeToDp(5.0f), convertSizeToDp(15.0f), convertSizeToDp(5.0f));
        if(seek.equals("自瞄"))
        {
            final TextView textVe = new TextView(this);
            textVe.setTextColor(Color.parseColor("#000000"));
            textVe.setTypeface((Typeface) null, 1);
            textVe.setPadding(convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f));
            textVe.setTextSize(1, (float) 12);
            textVe.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
            seekBar.setProgress(50);
            textVe.setText("Fov: 100");
            seekBar.setProgress(0);
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        py = progress;
                        py1 = 100 + py * 4;  
                        textVe.setText("Fov: " + py1);
                    }
                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }
                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            });
            this.patches.addView(textVe);
         }
         
        if(seek.equals("偏框"))
        {
            final TextView textVie = new TextView(this);
            textVie.setTextColor(Color.parseColor("#000000"));
            textVie.setTypeface((Typeface) null, 1);
            textVie.setPadding(convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f));
            textVie.setTextSize(1, (float) 12);
            textVie.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
            seekBar.setProgress(50);
            textVie.setText("偏移: 0");
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        if(progress == 50) //当等于则为零
                        {
                            X1 = 0;
                            textVie.setText("偏移: " + X1);
                        }
                        if(progress < 50) //小于一半则为负数
                        {
                            X1 = -(50 - progress) * 10;
                            textVie.setText("偏移: " + X1);
                        }
                        if(progress > 50) //大于一半则为正数
                        {
                            X1 = (progress - 50) * 10;
                            textVie.setText("偏移: " + X1);
                        }
                    }
                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }
                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                    }
                });
            this.patches.addView(textVie);
        }
        
        if(seek.equals("右偏移"))
        {
            final TextView textVie = new TextView(this);
            textVie.setTextColor(Color.parseColor("#000000"));
            textVie.setTypeface((Typeface) null, 1);
            textVie.setPadding(convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f));
            textVie.setTextSize(1, (float) 12);
            textVie.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
            seekBar.setProgress(50);
            textVie.setText("偏移: 0");
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        if(progress == 50) //当等于则为零
                        {
                            X1 = 0;
                            textVie.setText("偏移: " + X1);
                        }
                        if(progress < 50) //小于一半则为负数
                        {
                            X1 = -(50 - progress);
                            textVie.setText("偏移: " + X1 * 10);
                        }
                        if(progress > 50) //大于一半则为正数
                        {
                            X1 = (progress - 50);
                            textVie.setText("偏移: " + X1 * 10);
                        }
                    }
                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }
                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                    }
                });
            this.patches.addView(textVie);
        }
        
        this.patches.addView(seekBar);
    }
    
    void AddSeekbar(String str, String str2, String str3) {
        String str4 = str2;
        String str5 = str3;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout.setOrientation(0);
        TextView textView = new TextView(this);
        textView.setText(str + ":");
        textView.setTextSize(1, 12.5f);
        textView.setPadding(convertSizeToDp(10.0f), convertSizeToDp(5.0f), convertSizeToDp(10.0f), convertSizeToDp(5.0f));
        textView.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        textView.setGravity(3);
        textView.setTextColor(Color.parseColor("#000000"));
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(convertSizeToDp(15.0f), convertSizeToDp(5.0f), convertSizeToDp(15.0f), convertSizeToDp(5.0f));
        TextView textView2 = new TextView(this);
        textView2.setText(str4 + str5);
        textView2.setGravity(5);
        textView2.setTextSize(1, 12.5f);
        textView2.setLayoutParams(new RelativeLayout.LayoutParams(-1, -2));
        textView2.setPadding(convertSizeToDp(15.0f), convertSizeToDp(5.0f), convertSizeToDp(15.0f), convertSizeToDp(5.0f));
        textView2.setTextColor(Color.parseColor("#000000"));
        SeekBar seekBar2 = seekBar;       
        linearLayout.addView(textView);
        linearLayout.addView(textView2);
        this.patches.addView(linearLayout);
        this.patches.addView(seekBar2);
    }
    
    void AddRadioButton(String[] strArr) {
        RadioGroup radioGroup = new RadioGroup(this);
        RadioButton[] radioButtonArr = new RadioButton[strArr.length];
        radioGroup.setOrientation(1);
    
        for (int i2 = 0; i2 < strArr.length; i2++) {
            radioButtonArr[i2] = new RadioButton(this);
            radioButtonArr[i2].setTextColor(Color.parseColor("#000000"));
            radioButtonArr[i2].setPadding(convertSizeToDp(0.0f), convertSizeToDp(5.0f), convertSizeToDp(10.0f), convertSizeToDp(5.0f));
            radioButtonArr[i2].setText(strArr[i2]);
            radioButtonArr[i2].setTextSize(1, 12.5f);
            radioButtonArr[i2].setId(i2);
            radioButtonArr[i2].setGravity(5);
            radioGroup.addView(radioButtonArr[i2]);
        }
        radioGroup.setLayoutParams(new RelativeLayout.LayoutParams(-1, -2));
        this.patches.addView(radioGroup);
    }
    
    
    void AddText(String str, int i, int i2, String str2) {
        TextView textVie = new TextView(this);
        textVie.setText(str);
        textVie.setTextColor(Color.parseColor(str2));
        textVie.setTypeface((Typeface) null, i2);
        textVie.setPadding(convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f));
        textVie.setTextSize(1, (float) i);
        textVie.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        this.patches.addView(textVie);
    }
    
    
    
    
    private void initFloating() {
        rootFrame = new FrameLayout(getBaseContext());
        mRootContainer = new RelativeLayout(getBaseContext()); 
        mRootContaine = new RelativeLayout(getBaseContext()); 
        mCollapsed = new RelativeLayout(getBaseContext()); 
        mExpanded = new LinearLayout(getBaseContext()); 
        view1 = new LinearLayout(getBaseContext());
        patches = new LinearLayout(getBaseContext());
        view2 = new LinearLayout(getBaseContext());
        mButtonPanel = new LinearLayout(getBaseContext()); 

        RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-2, -1));
        relativeLayout.setPadding(3, 0, 3, 3);
        relativeLayout.setVerticalGravity(16); 

        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 17;

        
        TextView textView = new TextView(getBaseContext());
        textView.setText("T2");
        textView.setTextColor(Color.parseColor("#000000"));
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setTextSize(20.0f);
        textView.setPadding(10, 10, 10, 5);
        textView.setLayoutParams(layoutParams2);
        textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mCollapsed.setVisibility(View.VISIBLE);
                    mExpanded.setVisibility(View.GONE);
                }
            });
      
        TextView textView2 = new TextView(getBaseContext());
        textView2.setText("v1.2");
        textView2.setTextColor(Color.parseColor("#000000"));
        textView2.setTypeface(Typeface.DEFAULT_BOLD);
        textView2.setTextSize(10.0f);
        textView2.setPadding(10, 5, 10, 10);
        

        this.mExpanded.addView(textView);
        this.mExpanded.addView(textView2);

        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mRootContaine.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
        startimage = new ImageView(getBaseContext());
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension = (int) TypedValue.applyDimension(1, 50, getResources().getDisplayMetrics());
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode = Base64.decode("/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAPAA8ADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9UKfRWXr2sWvh7SrrUrx/LtbaNppXwTtVQSTgcngHgVMpKKuxpNuyNGn15D/w1D4AH/MXP/gNN/8AEUv/AA1F4A/6Czf+A03/AMRXnf2lhP8An4vvPTWV456qjL7metU7NeRf8NQ+AP8AoLP/AOAs3/xFH/DUPw+/6Cz/APgNN/8AEUf2nhP+fi+8r+ycf/z5l9zPW6fXkP8Aw1B8P/8AoLt/4DTf/EUf8NQfD/8A6C7f+A03/wARU/2pg/8An4vvQf2Tj/8AnzL7met07NeSf8NPfD7/AKC7f+A03/xFN/4ag+H/AP0F2/8AAab/AOIo/tTB/wDPxfeg/snH/wDPiX3M9bzT68h/4ah+H3/QWb/wGm/+Ipf+GoPh9/0GD/4DTf8AxFH9qYP/AJ+L70H9k4//AJ8S+5nrVPryL/hqD4ff9Bdv/Aab/wCIo/4ah+H/AP0F2/8AAWb/AOIpf2ng/wDn4vvD+ycf/wA+Jfcz1qnYFeR/8NQ+AP8AoLt/4Czf/EUf8NQfD7/oMN/4Czf/ABFUszwn/PxfeH9k4/8A58S/8BZ67TK8k/4ag+H/AP0Fn/8AAWb/AOIpf+GoPh9/0GG/8BZv/iKP7Twn/PxfeH9k4/8A58S/8BZ67TM15L/w1B8Pv+gw3/gLN/8AEUf8NQfD7/oMN/4Czf8AxFH9p4T/AJ+L7w/snH/8+Jf+As9czTc15L/w1B8Pv+gw3/gLN/8AEUn/AA1B8P8A/oLv/wCAs3/xFH9p4T/n4vvD+ycf/wA+Jf8AgLPXqZXkv/DUPw+/6C7f+A03/wARS/8ADUPw/wD+gu3/AIDTf/EUv7Swn/PxfeH9k4//AJ8S+5nrNFeS/wDDT/w9/wCgw3/gNN/8RR/w0/8AD3/oMN/4DTf/ABFP+08J/wA/F94v7Kx3/PmX/gLPXaZmvJP+GoPh/wD9Bdv/AAFm/wDiKX/hqL4f/wDQXb/wGm/+Io/tPCf8/F94/wCycf8A8+Jf+As9czTa8l/4ai+H/wD0F2/8Bpv/AIij/hqL4f8A/QXb/wABZv8A4ij+08J/z8X3h/ZOP/58S+5nrtMryX/hqL4f/wDQXb/wFm/+IpP+Govh/wD9BaT/AMBZv/iKP7Twn/PxfeH9k4//AJ8S/wDAWeu5puK8l/4ai+H/AP0F2/8AAWb/AOIo/wCGofh//wBBd/8AwFm/+Io/tPCf8/F94f2Tj/8AnxL/AMBZ67TK8l/4ai8Af9Bd/wDwFm/+Io/4ah+H/wD0F3/8BZv/AIij+08J/wA/F94f2Tj/APnxL/wFnrtMzXkv/DUPw/8A+gu//gLN/wDEUf8ADUPw/wD+gu//AICzf/EUf2nhP+fi+8P7Jx//AD4l/wCAs9czTc15L/w1D8P/APoLv/4Czf8AxFH/AA1H8P8A/oLt/wCAs3/xFH9p4T/n4vvD+ycf/wA+Jf8AgLPXaZivJv8AhqL4f/8AQXf/AMBZv/iKT/hqH4ff9Bhv/AWb/wCIo/tLCf8APxfeH9k4/wD58S+5nrtMxXk3/DUfw+/6C7/+As3/AMRSf8NQ/D//AKC7/wDgLN/8RR/aeE/5+L7w/snH/wDPiX/gLPXaZXkv/DUXgD/oLv8A+As3/wARR/w1D8P/APoLv/4Czf8AxFH9p4T/AJ+L7w/snH/8+Jf+As9dpma8l/4ah+H/AP0F3/8AAWb/AOIo/wCGofh//wBBd/8AwFm/+Io/tPCf8/F94f2Tj/8AnxL/AMBZ65mm5ryX/hqH4f8A/QXf/wABZv8A4ij/AIah+H//AEFm/wDAWb/4ij+08J/z8X3h/ZOP/wCfEv8AwFnrmabmvJf+Go/h/wD9Bdv/AAFm/wDiKP8AhqP4f/8AQXb/AMBZv/iKP7Twn/PxfeH9k4//AJ8S+5nrtMryT/hqL4f/APQWk/8AAWb/AOIpf+Go/h//ANBZ/wDwFm/+Io/tPB/8/F94f2Tj/wDnxL/wFnrtFeRf8NRfD/8A6C7f+As3/wARR/w1F8P/APoLt/4Czf8AxFH9p4P/AJ+L7xf2Tj/+fEv/AAFnrVFeSf8ADUXw+/6Cz4/69Zv/AIivV4ZluI1deVbkV00cTRxH8KSZx18JXwtvbQcb91YnopB0pa6zmCiikPSgBvf0p9Y/iHxDY+F9Lm1HUZfJtIiN77C2MsFHABPUiuR/4Xz4N/6Cv/kvL/8AEVxVsbh6EuWpNJkOcY6NnouRSbq86/4Xx4O/6Cv/AJLzf/EUf8L48Hf9BX/yXm/+Irl/tbBf8/ET7an/ADHou8UbxXnX/C+PB3/QV/8AJeb/AOIpf+F8eDf+gr/5Lzf/ABFCzTBP/l6g9tT7no1Fec/8L48H/wDQVP8A4DTf/EUf8L48H/8AQVP/AIDTf/EUf2pgv+fqD2sO56NRXnX/AAvbwb/0FD/34m/+IpP+F8+Df+gqf/Aeb/4in/amD/5+oftYdz0TeKN4rzv/AIXz4N/6Ch/8B5v/AIij/hfPg3/oKH/wHm/+Ipf2pgv+fqF7an3PRN4o3ivO/wDhfPg3/oKH/wAB5v8A4ij/AIXz4N/6Ch/8B5v/AIij+1MF/wA/UHtqfc9E3ijeK87/AOF8+Df+gof/AAHm/wDiKP8AhfPg3/oKH/wHm/8AiKP7UwX/AD9Qe2p9z0TeKN4rzv8A4Xz4N/6Ch/8AAeb/AOIo/wCF8+Df+gof/Aeb/wCIo/tTBf8AP1B7an3PRN4o3ivO/wDhfPg3/oKH/wAB5v8A4ij/AIXz4N/6Ch/8B5v/AIij+1MF/wA/UHtqfc9E3ijeK87/AOF8+Df+gof/AAHm/wDiKP8AhfPg3/oKH/wHm/8AiKP7UwX/AD9Qe2p9z0TeKN4rzv8A4Xz4N/6Ch/8AAeb/AOIo/wCF8+Df+gof/Aeb/wCIo/tTBf8AP1B7an3PRN4o3ivO/wDhfPg3/oKH/wAB5v8A4ij/AIXz4N/6Ch/8B5v/AIij+1MF/wA/UHtqfc9E3ijeK87/AOF8+Df+gof/AAHm/wDiKP8AhfPg3/oKH/wHm/8AiKP7UwX/AD9Qe2p9z0TeKN4rzv8A4Xz4N/6Ch/8AAeb/AOIo/wCF8+Df+gof/Aeb/wCIo/tTBf8AP1B7an3PRN4o3ivO/wDhfPg3/oKH/wAB5v8A4ij/AIXz4N/6Ch/8B5v/AIij+1MF/wA/UHtqfc9E3ijeK87/AOF8+Df+gof/AAHm/wDiKP8AhfPg3/oKH/wHm/8AiKP7UwX/AD9Qe2p9z0aivOf+F8+Dv+gsf/Aab/4ij/hfPg7/AKCx/wDAab/4ij+1MF/z9Qe1h3PRqK85/wCF8eDf+gof/Aeb/wCIo/4Xx4N/6Ch/8B5v/iKf9qYP/n6h+1h3PRN4o3ivO/8AhfPg3/oKH/wHm/8AiKP+F8+Df+gof/Aeb/4il/amC/5+oXtqfc9E3ijeK87/AOF8+Df+gof/AAHm/wDiKP8AhfPg3/oKH/wHm/8AiKP7UwX/AD9Qe2p9z0TeKN4rzv8A4Xz4N/6Ch/8AAeb/AOIo/wCF8+Df+gof/Aeb/wCIo/tTBf8AP1B7an3PRN4o3ivO/wDhfPg3/oKH/wAB5v8A4ij/AIXz4N/6Ch/8B5v/AIij+1MF/wA/UHtqfc9E3ijeK87/AOF8+Df+gof/AAHm/wDiKP8AhfPg3/oKH/wHm/8AiKP7UwX/AD9Qe2p9z0TeKN4rzv8A4Xz4N/6Ch/8AAeb/AOIo/wCF8+Df+gof/Aeb/wCIo/tTBf8AP1B7an3PRN4o3ivO/wDhfPg3/oKH/wAB5v8A4ij/AIXz4N/6Ch/8B5v/AIij+1MF/wA/UHtqfc9Gorzn/hfPg3/oLH/wHm/+IpP+F8+Dv+gv/wCS83/xFH9qYL/n6g9rDuej0yvPP+F9eDv+gqf/AAHl/wDiKn0/4z+FdT1C2tLfUjLczuIo0FvKNxJwBkrgdepq45lhJtRjUTBVIPZnf0U1W3KDTq9JGoVxPxl/5Jd4oP8A1DZ//RbV21cT8Z/+SW+Kv+wbP/6LaubF/wACfodGG/jQ9Ufnqv3R+B79eKPxNH8C/QUV/PdRvnevU/rmjCPs46dEH4mkx7mlorPmZvyR7CY9zRj3NLRRzMOSPYTHuaMe5paKOZhyR7CY9zRtHvS0UczDkj2E2j3o2j3paKOZhyR7CbR70bR70tFHMw5I9hNo96No96WijmYckewm0e9G0e9LRRzMOSPYTaPejaPeloo5mHJHsJkeppcj+8aKKXMw5I9gyP7xoyP7xoop8z7hyR7Bkf3jRkf3jRRRzMOSPYMj+8aMj+8aKKOZhyR7Bkf3jRkf3jRRRzMOSPYMj+8aMj3ooo5mHIuwY9zRj3NFFHMx8q7B+Jo/E0Z9zRn3NHMw5V2DHuaNv1ooo5mHKuwbfrRt+tFFHMw5V2Ex7mjHuaXPuaM+5o5mHKuwmPc0Y9zS59zRn3NHMw5V2Ex7mjHuaXPuaM+5o5mHKuwmPc0Y9zS59zRn3NHMw5V2DHuaMe5ooo5mHIuwY9zRj3NFFHMw5F2E/E0fiaWkNHMw5F2FH3l5I5HTp+VfphowzpltwPuDpX5njh1+or9MNG/5Blt/uV+j8IPm9p8j8T8QElUo2Xf9C+OlLSDpS1+mH5EFIelLSHpQB538dRn4b6r/ANsf/RyV8q/L/d/lX1Z8df8Akmuq/wDbL/0dHXyl1Nfj3FjtjI69Dxsd8SF2/wCz/Kjb/s/yoJI70mT6mviOZ9zzbi7f9n+VG3/Z/lSZPqaMn1NHM+4rhgf3f5UYH93+VGT6mjJ9TSu+4XF2e38qNg/u/oKTJ9TRk+pqrvuFxdv+z/Kjb/s/ypMfT86MfT86d33C4u3/AGf5Ubf9n+VJj6fnRj6fnRd9wuLt/wBn+VG3/Z/lSY+n50Y+n50XfcLjto/un9KNo/un9KbRU8z7hcXb/s/yo2/7P8qSii77hcXb/s/yo2/7P8qSii77hcXb/s/yo2/7P8qSii77hcXb/s/yo2/7P8qSii77hcXb/s/yo2/7P8qSii77hcXb/s/yo2/7P8qSii77hcXb/s/yo2/7P8qSii77hcXb/s/yo2/7P8qSii77hcXb/s/yo2/7P8qSii77hcXb/s/yo2/7P8qSii77hcXb/s/yo2/7P8qSii77hcXb/s/yo2/7P8qSii77hcXb/s/yo2/7P8qSii77hcXb/s/yo2/7P8qSii77hcXb/s/yo2/7P8qSii77hcXb/s/yo2/7P8qSii77hcXb/s/yo2/7P8qSii77hcOPQfpRx6D9KKKLvuFxRtz0/UVseCfk8Z6E3/T/AAD85FrGrZ8F/wDI5aB/1/2//o1a78DJ/Waav1RrSd5o+0Yv9WPpUh6VHH9ypD0r+hafwo+mjsh1cT8Zv+SWeKv+wbP/AOizXZ1xnxm/5JZ4p/7B0/8A6LNc+Kd6EvQ6cN/Hh6r8z89R9wfQUg6Up+5+Aor+e6nxSP68ofwoeiCiiisUbhRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiik9gCiiimugCj/WL/ALwr9L9H/wCQZb/7lfmh/wAtE/3hX6X6P/yDLf8A3K/SuEN6vyPxLxC/i0fn+hfHSlpB0pa/Sz8hCkPSlpD0oA88+O3/ACTbVf8Aeh/9HR18p19W/HX/AJJrqv8A2y/9HR18pV+OcWf75H0PEx/xoD1ooPWivhzzQooooAKKKKACiiigAooooAKKKKACiiigBMUYpaKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKQ9KAG1t+CP+Rz0L/sIW/8A6MWsg/cNbHgj/kdNC/7CFv8A+jFr0MCr4qHqjWj/ABEfaMP3F+lSHvUcP3F+lSHvX9EQ+FH08dkKPu1xXxm/5JZ4q/7Bs/8A6LNdnXGfGX/klfir/sGz/wDos1y4r+BL0OnDfx4eq/M/PX/AUnrS/wCApPWv58q/FI/r2h/Ch6IWiiisVsbBRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooopoBf+Wif7wr9L9H/5Blv/ALlfmh/y0T/eFfpfo/8AyDLf/cr9I4P/AOXvyPxLxC/i0fn+hfHSlpB0pa/TD8hCkPSlpD0oA88+O3/JNtV/3of/AEdHXymegr6t+Ov/ACTXVf8Atl/6Ojr5S7Cvxziv/fI+h4uO+NBRRRXw55gUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUCCtzwT/yOeh/9hC3/APRi1h1s+B/+Rz0L/sIW/wD6MWvRwH+9Q9UdFP44n2jD9xfpUh71HD9xfpUh71/Q1P4UfSx2FPSuK+Mv/JK/FX/YNn/9FmuzrjPjN/ySzxV/2DZ//RbVzYn+BP0OnDfx4eq/M/PX/AUnrS/4Ck9a/nyr8Uj+vaH8KHohaKKKxWxsFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiimtgF/wCWif7wr9L9H/5Blv8A7lfmh/y0T/eFfpfo/wDyDLf/AHK/SeD/APl78j8S8Qv4tH5/oXx0paQdKWv0s/IQpD0paQ9KAPPPjt/yTbVf96H/ANHR18p19W/HX/kmuq/9sv8A0dHXylX47xX/AL5H0PFx3xoKKKK+GPMCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigQVu+Cf8Akc9D/wCwhb/+jFrCrZ8D/wDI56F/2ELf/wBGLXo4D/eoeqOin8cT7Rh+4v0qQ96jh+4v0qQ96/oan8KPpo7Dq4n4zf8AJLPFX/YNn/8ARbV2dcZ8Zf8Aklnin/sG3H/os1zYn+BP0OnDfx4eq/M/PX/AUnrS/wCApPWv58q/FI/ryh/Ch6IWiiisVsbBRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAoooprYBf+Wif7wr9L9H/AOQZb/7lfmh/y0T/AHhX6X6P/wAgy3/3K/SeD/8Al78j8S8Qv4tH5/oXx0paQdKWv0s/IQpD0paQ9KAPPPjt/wAk21X/AHof/R0dfKdfVvx1/wCSa6r/ANsv/R0dfKVfjvFf++R9Dxcd8aCiiivhjzAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooEFbvgn/kc9D/7CFv/AOjFrCrZ8D/8jnoX/YQt/wD0YtejgP8AeoeqOin8cT7Rh+4v0qQ96jh+4v0qQ96/oan8KPpo7Dq4j4y/8ks8V/8AYNuP/RZrtB1rjPjL/wAkr8Vf9g2f/wBANc+J/gT9Dow38aHqvzPz1X7v4Ck9aX/AUnrX891fikf17Q/hQ9ELRRRWK2NgooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUU1sAv/LRP94V+l+j/APIMt/8Acr80P+Wif7wr9L9H/wCQZb/7lfpPB/8Ay9+R+JeIX8Wj8/0L46UtIOlLX6WfkIUh6UtIelAHnnx2/wCSbar/AL0P/o6OvlOvq346/wDJNdV/7Zf+jo6+Uq/HeK/98j6Hi4740FFFFfDHmBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQIK3fBP/I56H/2ELf8A9GLWFWz4H/5HPQv+whb/APoxa9HAf71D1R0U/jifaMP3F+lSHvUcP3F+lSHvX9DU/hR9NHYdXE/GX/klfir/ALBs/wD6Aa7Mda4z4y/8ks8Vf9g24/8ARZrmxX8CfodOG/jw9V+Z+ev+ApPWl/wFJ61/PlX4pH9eUP4UPRC0UUVitjYKKKKYBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFNbAL/AMtE/wB4V+l+j/8AIMt/9yvzQ/5aJ/vCv0v0f/kGW/8AuV+k8H/8vfkfiXiF/Fo/P9C+OlLSDpS1+ln5CFIelLSHpQB558dv+Sbar/vQ/wDo6OvlOvq346/8k11X/tl/6Ojr5Sr8d4r/AN8j6Hi4740FFFFfDHmBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQIK3fBP8AyOeh/wDYQt//AEYtYVbPgf8A5HPQv+whb/8Aoxa9HAf71D1R0U/jifaMP3F+lSHvUcP3F+lSHvX9DU/hR9NHYdXE/GX/AJJZ4q/7Btx/6LNdnXGfGX/klnir/sG3H/os1z4r+BP0OnDfx4eq/M/PX/AUnrS/4Ck9a/nur8Uj+vKH8KHohaKKKxWxsFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiimtgF/5aJ/vCv0v0f/kGW/8AuV+aH/LRP94V+l+j/wDIMt/9yv0ng/8A5e/I/EvEL+LR+f6F8dKWkHSlr9LPyEKQ9KWkPSgDzz47f8k21X/eh/8AR0dfKdfVvx1/5Jrqv/bL/wBHR18pV+O8V/75H0PFx3xoKKKK+GPMCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigQVu+Cf+Rz0P/sIW/wD6MWsKtnwP/wAjnoX/AGELf/0YtejgP96h6o6KfxxPtGH7i/SpD3qOH7i/SpD3r+hqfwo+mjsOrifjL/ySzxV/2Dbj/wBFmuzrjPjL/wAks8Vf9g24/wDRZrmxX8CfodOG/jw9V+Z+ev8AgKT1pf8AAUnrX8+Vfikf15Q/hQ9ELRRRWK2NgooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUU1sAv/LRP94V+l+j/wDIMt/9yvzQ/wCWif7wr9L9H/5Blv8A7lfpPB//AC9+R+JeIX8Wj8/0L46UtIOlLX6WfkIUh6UtIelAHnnx2/5Jtqv+9D/6Ojr5Tr6t+Ov/ACTXVf8Atl/6Ojr5Sr8d4r/3yPoeLjvjQUUUV8MeYFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAgrd8E/8jnof/YQt/8A0YtYVbPgf/kc9C/7CFv/AOjFr0cB/vUPVHRT+OJ9ow/cX6VIe9Rw/cX6VIe9f0NT+FH00dhT0rivjL/ySzxV/wBg24/9FmuzrjPjL/ySzxV/2Dbj/wBFmufFfwJ+h04b+PD1X5n56/4Ck9aX/AUnrX891fikf15Q/hQ9ELRRRWK2NgooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUU1sAv8Ay0T/AHhX6X6P/wAgy3/3K/ND/lon+8K/S/R/+QZb/wC5X6Twf/y9+R+JeIX8Wj8/0L46UtIOlLX6WfkIUh6UtIelAHnnx2/5Jtqv+9D/AOjo6+U6+rfjr/yTXVf+2X/o6OvlKvx3iv8A3yPoeLjvjQUUUV8MeYFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAgrd8E/wDI56H/ANhC3/8ARi1hVs+B/wDkc9C/7CFv/wCjFr0cB/vUPVHRT+OJ9ow/cX6VIe9Rw/cX6VIe9f0NT+FH00dh1cV8ZP8Aklnir/sGz/8Aos12VcZ8Zf8Aklnir/sG3H/os1z4r+BL0OjDfx4eq/M/PX/AUnrS/wCApPWv57q/FI/r2h/Ch6IWiiisVsbBRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAoooprYBf+Wif7wr9L9H/AOQZb/7lfmh/y0T/AHhX6X6P/wAgy3/3K/SeD/8Al78j8S8Qv4tH5/oXx0paQdKWv0s/IQpD0paQ9KAPPPjt/wAk21X/AHof/R0dfKdfVvx1/wCSa6r/ANsv/R0dfKVfjvFf++R9Dxcd8aCiiivhjzAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooEFbvgn/kc9D/7CFv/AOjFrCrZ8D/8jnoX/YQt/wD0YtejgP8AeoeqOin8cT7Rh+4v0qQ96jh+4v0qQ96/oan8KPpo7Dq4n4zf8kr8V/8AYNuP/QDXZjrXGfGb/klnir/sGz/+izXPiv4EvQ6MN/Gh6r8z89V+7+ApPWl/wFJ61/PdX4pH9e0P4UPRC0UUVitjYKKKKYBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFNbAL/y0T/eFfpfo/wDyDLf/AHK/ND/lon+8K/S/R/8AkGW/+5X6Twf/AMvfkfiXiF/Fo/P9C+OlLSDpS1+ln5CFIelLSHpQB558dv8Akm2q/wC9D/6Ojr5Tr6t+Ov8AyTXVf+2X/o6OvlKvx3iv/fI+h4uO+NBRRRXwx5gUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUCCt3wT/yOeh/9hC3/APRi1hVs+B/+Rz0L/sIW/wD6MWvRwH+9Q9UdFP44n2jD9xfpUh71HD9xfpUh71/Q1P4UfTR2HVxPxm/5JZ4q/wCwbP8A+izXZ1xvxk/5JZ4q/wCwbcf+izXPiv4EvQ6MP/Gh6r8z89P8BSetL/gKT1r+e6vxSP69ofwoeiFooorFbGwUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKa2AX/AJaJ/vCv0v0f/kGW/wDuV+aH/LRP94V+l+j/APIMt/8Acr9J4P8A+XvyPxLxC/i0fn+hfHSlpB0pa/Sz8hCkPSlpD0oA88+O3/JNtV/3of8A0dHXynX1b8df+Sa6r/2y/wDR0dfKVfjvFf8AvkfQ8XHfGgooor4Y8wKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKBBW74J/wCRz0P/ALCFv/6MWsKtnwP/AMjnoX/YQt//AEYtejgP96h6o6KfxxPtGH7i/SpD3qOH7i/SpD3r+hqfwo+mjsOrifjN/wAks8Vf9g2f/wBFmuzrjPjN/wAkr8Vf9g24/wDRZrnxX8CXodGG/jQ9V+Z+eq/d/wCAij1oX7v/AAEUetfz3V+KR/XtD+FD0QUUUVitjYKKKKYBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFNbAL/y0T/eFfpfo/8AyDLf/cr80P8Alon+8K/S/R/+QZb/AO5X6Twf/wAvfkfiXiF/Fo/P9C+OlLSDpS1+ln5CFIelLSHpQB558dv+Sbar/vQ/+jo6+U6+rfjr/wAk11X/ALZf+jo6+Uq/HeK/98j6Hi4740FFFFfDHmBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQIK3fBP/I56H/2ELf/ANGLWFWz4H/5HPQv+whb/wDoxa9HAf71D1R0U/jifaMP3F+lSHvUcP3F+lSHvX9DU/hR9NHYdXE/Gb/klfir/sG3H/os12dcZ8Zf+SWeKv8AsGz/APos1z4r+BL0OjDfxoeq/M/PVfu/8BFFC/d/4CKK/nur8Uj+vaH8KHogooorFbGwUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKa2AX/lon+8K/S/R/+QZb/wC5X5of8tE/3hX6X6P/AMgy3/3K/SeD/wDl78j8S8Qv4tH5/oXx0paQdKWv0s/IQpD0paQ9KAPPPjt/yTbVf96H/wBHR18p19W/HX/kmuq/9sv/AEdHXylX47xX/vkfQ8XHfGgooor4Y8wKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKBBW74J/5HPQ/+whb/APoxawq2fA//ACOehf8AYQt//Ri16OA/3qHqjop/HE+0YfuL9KkPeo4fuL9KkPev6Gp/Cj6aOw6uJ+Mv/JLPFX/YNn/9FmuzrjPjL/ySzxV/2DZ//RZrnxX8CXodGG/jw9V+Z+eq/d/4CKKF+7/wEUV/PdX4pH9e0P4UPRBRRRWK2NgooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUU1sAv/AC0T/eFfpfo//IMt/wDcr80P+Wif7wr9L9H/AOQZb/7lfpPB/wDy9+R+JeIX8Wj8/wBC+OlLSDpS1+ln5CFIelLSHpQB558dv+Sbar/vQ/8Ao6OvlOvq346/8k11X/tl/wCjo6+Uq/HeK/8AfI+h4uO+NBRRRXwx5gUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUCCt3wT/wAjnof/AGELf/0YtYVbPgf/AJHPQv8AsIW//oxa9HAf71D1R0U/jifaMP3F+lSHvUcP3F+lSHvX9DU/hR9NHYU9K4r4y/8AJLPFX/YNn/8ARZrs64z4y/8AJK/FX/YNn/8ARZrnxX8CXodGG/jw9V+Z+eq/d/4CKKF+7/wEUV/PdX4pH9e0P4UPRBRRRWK2NgooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUU1sAv8Ay0T/AHhX6X6P/wAgy3/3K/ND/lon+8K/S/R/+QZb/wC5X6Twf/y9+R+JeIX8Wj8/0L46UtIOlLX6WfkIUh6UtIelAHnnx2/5Jtqv+9D/AOjo6+U6+rfjr/yTXVf+2X/o6OvlKvx3iv8A3yPoeLjvjQUUUV8MeYFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAgrd8E/wDI56H/ANhC3/8ARi1hVs+B/wDkc9C/7CFv/wCjFr0cB/vUPVHRT+OJ9ow/cX6VIe9Rw/cX6VIe9f0NT+FH00dh1cT8Zf8Aklfir/sGz/8Aos12dcZ8Zf8Aklfir/sGz/8Aos1z4r+BL0OjDfx4eq/M/PVfu/8AARRQv3f+Aiiv57q/FI/r2h/Ch6IKKKKxWxsFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiimtgF/5aJ/vCv0v0f/AJBlv/uV+aH/AC0T/eFfpfo//IMt/wDcr9J4P/5e/I/EvEL+LR+f6F8dKWkHSlr9LPyEKQ9KWkPSgDzz47f8k21X/eh/9HR18p19W/HX/kmuq/8AbL/0dHXylX47xX/vkfQ8XHfGgooor4Y8wKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKBBW74J/5HPQ/wDsIW//AKMWsKtnwP8A8jnoX/YQt/8A0YtejgP96h6o6KfxxPtGH7i/SpD3qOH7i/SpD3r+hqfwo+mjsOrifjL/AMkr8Vf9g2f/ANFmuzrjPjL/AMkr8Vf9g2f/ANFmufFfwJeh0Yb+PD1X5n56r93/AICKKF+7/wABFFfz3V+KR/XtD+FD0QUUUVitjYKKKKYBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFNbAL/y0T/eFfpfo/8AyDLf/cr80P8Alon+8K/S/R/+QZb/AO5X6Twf/wAvfkfiXiF/Fo/P9C+OlLSDpS1+ln5CFIelLSHpQB558dv+Sbar/vQ/+jo6+U6+rfjr/wAk11X/ALZf+jo6+Uq/HeK/98j6Hi4740FFFFfDHmBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQIK3fBP/I56H/2ELf/ANGLWFWz4H/5HPQv+whb/wDoxa9HAf71D1R0U/jifaMP3F+lSHvUcP3F+lSHvX9DU/hR9NHYdXE/GX/klfir/sGz/wDos12dcZ8Zf+SV+Kv+wbP/AOizXPiv4EvQ6MN/Hh6r8z89V+7/AMBFFC/d/wCAiiv57q/FI/r2h/Ch6IKKKKxWxsFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiimtgF/5aJ/vCv0v0f8A5Blv/uV+aH/LRP8AeFfpfo//ACDLf/cr9J4P/wCXvyPxLxC/i0fn+hfHSlpB0pa/Sz8hCkPSlpD0oA88+O3/ACTbVf8Aeh/9HR18p19W/HX/AJJrqv8A2y/9HR18pV+O8V/75H0PFx3xoKKKK+GPMCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigQVu+Cf+Rz0P/sIW/8A6MWsKtnwP/yOehf9hC3/APRi16OA/wB6h6o6KfxxPtGH7i/SpD3qOH7i/SpD3r+hqfwo+mjsOrifjL/ySvxV/wBg2f8A9FmuzrjPjL/ySvxV/wBg2f8A9FmufFfwJeh0Yb+PD1X5n56r93/gIooX7v8AwEUV/PdX4pH9e0P4UPRBRRRWK2NgooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUU1sAv/LRP94V+l+j/APIMt/8Acr80P+Wif7wr9L9H/wCQZb/7lfpPB/8Ay9+R+JeIX8Wj8/0L46UtIOlLX6WfkIUh6UtIelAHnnx2/wCSbar/AL0P/o6OvlOvq346/wDJNdV/7Zf+jo6+Uq/HeK/98j6Hi4740FFFFfDHmBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQIK3fBP/I56H/2ELf8A9GLWFWz4H/5HPQv+whb/APoxa9HAf71D1R0U/jifaMP3F+lSHvUcP3F+lSHvX9DU/hR9NHYdXE/GX/klfir/ALBs/wD6LNdnXGfGX/klfir/ALBs/wD6LNc+K/gS9Dow38eHqvzPz1X7v/ARRQv3f+Aiiv57q/FI/r2h/Ch6IKKKKxWxsFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiimtgF/5aJ/vCv0v0f/kGW/8AuV+aH/LRP94V+l+j/wDIMt/9yv0ng/8A5e/I/EvEL+LR+f6F8dKWkHSlr9LPyEKQ9KWkPSgDzz47f8k21X/eh/8AR0dfKdfVvx1/5Jrqv/bL/wBHR18pV+O8V/75H0PFx3xoKKKK+GPMCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigQVu+Cf+Rz0P/sIW/wD6MWsKtnwP/wAjnoX/AGELf/0YtejgP96h6o6KfxxPtGH7i/SpD3qOH7i/SpD3r+hqfwo+mjsOrifjL/ySvxV/2DZ//RZrs64z4y/8kr8Vf9g2f/0Wa58V/Al6HRhv48PVfmfnqv3f+Aiihfu/8BFFfz3V+KR/XtD+FD0QUUUVitjYKKKKYBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFNbAL/wAtE/3hX6X6P/yDLf8A3K/ND/lon+8K/S/R/wDkGW/+5X6Twf8A8vfkfiXiF/Fo/P8AQvjpS0g6UtfpZ+QhSHpS0h6UAeefHb/km2q/70P/AKOjr5Tr6t+Ov/JNdV/7Zf8Ao6OvlKvx3iv/AHyPoeLjvjQUUUV8MeYFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAgrd8E/8AI56H/wBhC3/9GLWFWz4H/wCRz0L/ALCFv/6MWvRwH+9Q9UdFP44n2jD9xfpUh71HD9xfpUh71/Q1P4UfTR2HVxPxl/5JX4q/7Bs//os12dcZ8Zf+SV+Kv+wbP/6LNc+K/gS9Dow38eHqvzPz1X7v/ARRQv3f+Aiiv57q/FI/r2h/Ch6IKKKKxWxsFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiimtgF/wCWif7wr9L9H/5Blv8A7lfmh/y0T/eFfpfo/wDyDLf/AHK/SeD/APl78j8S8Qv4tH5/oXx0paQdKWv0s/IQpD0paQ9KAPPPjt/yTbVf96H/ANHR18p19W/HX/kmuq/9sv8A0dHXylX47xX/AL5H0PFx3xoKKKK+GPMCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigQVu+Cf8Akc9D/wCwhb/+jFrCrZ8D/wDI56F/2ELf/wBGLXo4D/eoeqOin8cT7Rh+4v0qQ96jh+4v0qQ96/oan8KPpo7Dq4n4y/8AJK/FX/YNn/8ARZrs64z4y/8AJK/FX/YNn/8ARZrnxX8CXodGG/jw9V+Z+eq/d/4CKKF+7/wEUV/PdX4pH9e0P4UPRBRRRWK2NgooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUU1sAv8Ay0T/AHhX6X6P/wAgy3/3K/ND/lon+8K/S/R/+QZb/wC5X6Twf/y9+R+JeIX8Wj8/0L46UtIOlLX6WfkIUh6UtIelAHnnx2/5Jtqv+9D/AOjo6+U6+rfjr/yTXVf+2X/o6OvlKvx3iv8A3yPoeLjvjQUUUV8MeYFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAgrd8E/wDI56H/ANhC3/8ARi1hVs+B/wDkc9C/7CFv/wCjFr0cB/vUPVHRT+OJ9ow/cX6VIe9Rw/cX6VIe9f0NT+FH00dh1cT8Zf8Aklfir/sGz/8Aos121cT8Zf8Aklfir/sGz/8Aos1z4r+BL0OjDfx4eq/M/PVfu/8AARRQv3f+Aiiv57q/FI/r2h/Ch6IKKKKxWxsFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiimtgF/5aJ/vCv0v0f/AJBlv/uV+aH/AC0T/eFfpfo//IMt/wDcr9J4P/5e/I/EvEL+LR+f6F8dKWkHSlr9LPyEKQ9KWkPSgDzz47f8k21X/eh/9HR18p19W/HX/kmuq/8AbL/0dHXylX47xX/vkfQ8XHfGgooor4c8wKKKKACiiikAUUUUAFFFFMAooooAKKKKQBRRRQAUUUUwCiiigAooopAFFFFABRRRTAKKKKACiiigAooooAKKKKQBRRRTAKKKKACiiigAooopAFFFFABRRRTAKKKKACiiigAooopCCt3wT/yOeh/9hC3/APRi1hVs+B/+Rz0L/sIW/wD6MWvRwH+9Q9Ub0/jifaMP3F+lSHvUcP3F+lSHvX9DU/hR9PHYdXEfGf8A5JV4q/7Bs/8A6LNdvXEfGf8A5JV4q/7Bs/8A6Aa58V/An6HRhv48PVfmfnv6fQUlL6fQUlfz3V+KR/XtD+FD0QUUUVitjYKKKKYBRRRQAUUUUAFFFJmgBaKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAoHWiimAq/eX/AHhX6X6P/wAg22/3B/IV+aI++v8AvCv0v0c/8S22/wBwV+kcH6e1+R+J+IX8Wh8/0Lw6UtIOlLX6YfkAUh6UtIelAHnvx2/5Jvqv/bL/ANHR18pV9V/Hb/km2rf9sv8A0alfKgr8d4s/3yPoeLjvjQUUzNGa+GueYPopmaM0XAfRRRQIKKKKBhRTcmjJouwHUU3JoyaLsB1FFFABRRRQAUUzNGaLgPopmaM0XAfRTMmlDUAOooooAKKbk0ZNFwHUU3JoyaLgOopuTRk0XAdRTcmjJouA6iiigAoppNGTRcB1FNyaMmi4DqKbk0ZNFwHUUUUAFFFFABRTefejn3ouA6im8+9HPvRcB1FNyaATRcB1IelLRQAv8P41s+B/+Ry0L/sIW/8A6MWsWtrwX/yOeh/9hC3/APRi16WA/wB5p+qNaX8RH2hD91ak7tUcH3V+lSd2r+hafwo+njsJXL/EvR7rxB4F1zTbNDLdXdlNBEmQAXZCF5OAOcda6um/nRUgqkHB9TSEnCSmt0fBh/Zy+Iox/wAU4eBj/j7g7f8AA6b/AMM5fET/AKF1/wDwLg/+Lr712ijaK+Rlwxg5O7ufdR40zSCsuX7v+CfBX/DOfxE/6Fx//AuD/wCLo/4Zy+In/Qtv/wCBkH/xdfeu0UbRS/1XwfmV/rtmn937v+CfBX/DOXxE/wChbf8A8DIP/i6P+GcfiL/0Lb/+BkH/AMXX3rtFG0Uf6r4PzD/XbNP7v3f8E+Cv+GcfiL/0Lb/+BkH/AMXR/wAM4/EX/oW3/wDAyD/4uvvXaKNop/6r4LzD/XbNP7v3f8E+Cv8AhnH4i/8AQtv/AOBkH/xdH/DOPxF/6Ft//AyD/wCLr712ijaKP9V8F5h/rtmn937v+CfBX/DOXxE/6Ft//AyD/wCLo/4Zx+In/QuN/wCBcH/xdfeu0UbRS/1XwfmH+u2af3fu/wCCfBX/AAzn8RP+hbf/AMC4P/i6P+Gc/iJ/0Lb/APgXB/8AF1967RRtFH+q+D8w/wBds0/u/d/wT4K/4Zz+In/Qtv8A+BcH/wAXR/wzl8Rf+hbf/wAC4P8A4uvvXaKNoo/1XwfmH+u2af3fu/4J8Ff8M5fEX/oW3/8AAuD/AOLo/wCGcviL/wBC2/8A4Fwf/F1967RRtFP/AFXwXmH+u2af3fu/4J8Ff8M5fEX/AKFt/wDwLg/+Lo/4Zy+Iv/Qtv/4Fwf8Axdfeu0UbRR/qvgvMP9ds0/u/d/wT4K/4Zy+Iv/Qtv/4Fwf8AxdH/AAzl8Rf+hbf/AMC4P/i6+9doo2ij/VfBeYf67Zp/d+7/AIJ8Ff8ADOXxF/6Ft/8AwLg/+Lo/4Zy+Iv8A0Lb/APgXB/8AF1967RRtFH+q+C8w/wBds0/u/d/wT4K/4Zy+Iv8A0Lb/APgXB/8AF0f8M5fEX/oW3/8AAuD/AOLr712ijaKP9V8F5h/rtmn937v+CfBX/DOXxF/6Ft//AALg/wDi6P8AhnL4i/8AQtv/AOBcH/xdfeu0UbRR/qvgvMP9ds0/u/d/wT4K/wCGcviL/wBC2/8A4Fwf/F0f8M5fEX/oW3/8C4P/AIuvvXaKNoo/1XwXmH+u2af3fu/4J8Ff8M5fEX/oW3/8C4P/AIuj/hnL4i/9C2//AIFwf/F1967RRtFH+q+C8w/12zT+793/AAT4K/4Zy+Iv/Qtv/wCBcH/xdH/DOXxF/wChbf8A8C4P/i6+9doo2ij/AFXwXmH+u2af3fu/4J8Ff8M5fEX/AKFt/wDwLg/+Lo/4Zy+Iv/Qtv/4Fwf8Axdfeu0UbRR/qvgvMP9ds0/u/d/wT4K/4Zy+Iv/Qtv/4Fwf8AxdH/AAzl8Rf+hbf/AMC4P/i6+9doo2ij/VfBeYf67Zp/d+7/AIJ8Ff8ADOXxF/6Ft/8AwLg/+Lo/4Zy+Iv8A0Lb/APgXB/8AF1967RRtFH+q+C8w/wBds0/u/d/wT4K/4Zy+Iv8A0Lb/APgXB/8AF0f8M5fEX/oW3/8AAuD/AOLr712ijaKP9V8F5h/rtmn937v+CfBX/DOXxF/6Ft//AALg/wDi6P8AhnL4i/8AQtv/AOBcH/xdfeu0UbRR/qvgvMP9ds0/u/d/wT4K/wCGcviL/wBC2/8A4Fwf/F0f8M5fEX/oW3/8C4P/AIuvvXaKNoo/1XwXmH+u2af3fu/4J8Ff8M5fEX/oW3/8C4P/AIuj/hnL4i/9C2//AIFwf/F1967RRtFH+q+C8w/12zT+793/AAT4K/4Zy+Iv/Qtv/wCBcH/xdH/DOXxF/wChbf8A8C4P/i6+9doo2ij/AFXwXmH+u2af3fu/4J8Ff8M5fEX/AKFt/wDwLg/+Lo/4Zy+Iv/Qtv/4Fwf8Axdfeu0UbRR/qvgvMP9ds0/u/d/wT4K/4Zy+Iv/Qtv/4Fwf8AxdH/AAzl8Rf+hbf/AMC4P/i6+9doo2ij/VfB+Yf67Zp/d+7/AIJ8E/8ADOvxF3rjw27cg7Rd24P5mTFfdWmxeVZQo33lUA1c2gU1RgV7GX5XRy6/sup87muc4nOHF4m3u9h46UtJS17R4QUhpaKAOJ+LOgX3iPwPqNjp0BubuXy9kYZVziRWPLEDoD1NfPn/AApXxn/0BD/4FQ//ABdfW39KXHsa+dx+S4fMKiqVb3OepRhUd5HySPgr40/6Ah/8C4f/AIuj/hSnjT/oCH/wLh/+Lr612+1Ls+v515v+q+D8zP6pT7HyT/wpTxp/0BD/AOBcP/xdH/ClfGn/AEBD/wCBcP8A8XX1ts+v50bPr+dL/VbB+YfVKfY+Sf8AhSXjP/oCn/wLh/8Ai6P+FJeM/wDoDH/wKh/+Lr622+wo2+wpf6rYPuyfqdLsfJP/AApLxp/0BT/4FQ//ABdH/CkvGn/QFP8A4FQ//F19bbaNtP8A1Vwfdj+qUux8kf8AClPGn/QFP/gTD/8AF0f8KS8Z/wDQEP8A4FQ//F19b7fpRt+lP/VbB92H1Ol2Pkj/AIUl4z/6Ah/8Cof/AIuj/hSXjP8A6Ah/8Cof/i6+t9v0o2/Sj/VbB92H1Ol2Pkn/AIUn4z/6Ap/8C4f/AIuj/hSfjP8A6Ap/8C4f/i6+tdg/uijYP7opf6q4Puw+p0ux8lf8KT8Z/wDQFP8A4Fw//F0f8KT8Z/8AQFP/AIFw/wDxdfWuwf3RRsH90Uf6q4Puw+p0ux8lf8KU8af9AT/yah/+Lo/4Un41/wCgJ/5NQ/8AxdfW+0Ubaa4WwS7h9Tpdj5H/AOFJ+Nf+gJ/5NQ//ABdL/wAKU8a/9ARv/AuH/wCLr6320baf+q2C8w+p0ux8j/8ACk/Gv/QE/wDJqH/4uj/hSfjX/oCf+TUP/wAXX1vtFG0Uf6r4LzD6nS7HyR/wpTxr/wBAVv8AwKh/+Lo/4Ul41/6An/k1D/8AF19b7F/uijH+zU/6q4LzD6nS7HyV/wAKT8a/9AY/+BUP/wAXSf8ACkvGn/QFP/gVD/8AF19bY/2aMf7NH+quC8w+p0ux8k/8KU8af9AQ/wDgTD/8XS/8KU8Z/wDQEP8A4FQ//F19a7KNnvT/ANVsF5h9Tpdj5K/4Up4z/wCgIf8AwKh/+Lo/4Up4z/6Ah/8AAqH/AOLr612e9Gz3p/6rYLzD6nS7HyV/wpTxr/0BT/4Fw/8AxdH/AApTxr/0BT/4Fw//ABdfWuz3o2e9T/qrgvMPqdLsfI//AApPxr/0BD/4FQ//ABdP/wCFKeNf+gKf/AuH/wCLr612+1G32o/1VwXmH1Ol2Pkn/hSfjT/oCH/wKh/+Lo/4Un40/wCgIf8AwKh/+Lr63xSbfaj/AFVwXmH1Ol2Pkn/hSfjT/oCH/wACof8A4ul/4Un4z/6AZ/8AAuH/AOLr612+1G32prhbBLuH1Ol2Pkr/AIUn4z/6AZ/8C4f/AIuj/hSfjP8A6AZ/8C4f/i6+tdvtRt9qf+q2C8w+p0ux8k/8KT8af9AQ/wDgVD/8XR/wpPxp/wBAQ/8AgVD/APF19bbfajb7VP8AqrgvMPqdLsfJP/Ck/Gn/AEBD/wCBUP8A8XR/wpPxp/0BD/4FQ/8AxdfW232o2+1H+quC8w+p0ux8kf8ACkfGn/QEP/gVD/8AF0f8KR8af9AQ/wDgVD/8XX1xik2+1H+quC8w+p0ux8kf8KR8af8AQEP/AIFQ/wDxdL/wpLxp/wBAQ/8AgVD/APF19bbfajb7U1wtgl3D6nS7HyR/wpHxp/0BD/4FQ/8AxdH/AApHxp/0BD/4FQ//ABdfXGKTb7Uv9VcF5h9Tpdj5I/4Ul41/6Ap/8Cof/i6P+FJeNP8AoCn/AMCof/i6+t9vtRt9qP8AVXBeYfU6XY+SP+FJeNP+gKf/AAKh/wDi61PCnwh8W2HifSbq50rybe3u4ppJDcRHCq4Y8Bieg7V9R7fak2+2K1p8NYSlNTje6HHC04u6GxD5RUtNCgU6vroqySOsKKKKoYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAmBRilooAKKKKACiiigAooooAKKKKACiiigAooooATFGKWigBMUYpaKAExRilooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAExRilooAKTFLRQAmKMUtFACYoxS0UAJijFLRQAmKMUtFABSYpaKAExRilooAKTFLRQAmKMUtFACYoxS0UAFFFFABRRSZxQAtFR5p240riuOopm73o3e9Fwuh9FM3e9G73ouF0Popm73o3e9Fwuh9FM3e9G73ouF0Popm73o3e9Fwuh9FM3e9G73ouF0Popm73o3e9Fwuh9FM3e9G73ouF0Popm73o3e9Fwuh9FM3e9G73ouF0Popm73o3e9Fwuh9FM3e9G73ouF0Popm73o3e9Fwuh9FM3e9G73ouF0Popm73o3e9Fwuh9FM3e9G73ouF0Popm73o3e9Fwuh9FM3e9G73ouF0Popm73o3e9Fwuh9FM3e9G73ouF0Popm73o3e9Fwuh9FM3e9G73ouF0Popm73o3e9Fwuh9FM3e9G73ouF0Popm73o3e9Fwuh9FNwaMGmFx1FMxilwaAuOooooGFFFFABSZpCdopPMHqKV0A+imbv8AaFG7/aFMB9FM3f7Qo3f7QoAfRTN3+0KN3+0KAH0Uzd/tCjd/tCgB9FM3f7Qo3f7QoAfRTN3+0KN3+0KAH0Uzd/tCjd/tCgB9FM3f7Qo3f7QoAfRTN3+0KN3+0KAH0Uzd/tCjd/tCgB9FM3f7Qo3f7QoAfRTN3+0KN3+0KAH0Uzd/tCjd/tCgB9FM3f7Qo3f7QoAfRTN3+0KN3+0KAH0Uzd/tCjd/tCgB9FM3f7Qo3f7QoAfRTN3+0KN3+0KAH0Uzd/tCjd/tCgB9FM3f7Qo3f7QoAfRTN3+0KN3+0KAH0Uzd/tCjd/tCgB9FM3f7Qo3f7QoAfRTN3+0KN3+0KAH0Uzd/tCjd/tCgB9FM3f7Qo3f7QoAfRTNw9aNxpXQD6KTrS0IArlvH+vT+F/Butatbqr3FlZzXEYlGVZkQsAenHHYiumriPjV/yS3xT/2C7n/0U1b0UpVIp9WcGOnKnhqk4uzSZ8s/8NgeOM5+yaN/4Dy//HaP+GwPHH/Pro3/AIDy/wDx2vD8miv3Knw7lzgm6evzP5SrcW5xGpJRrO1z3D/hr/xx/wA+ui/+A8v/AMdo/wCGvvHH/Prof/gPL/8AHK8PzR+Arb/VzLf+ff4sy/1uzj/n8z3D/hr/AMcf8+mi/wDgPL/8do/4a+8cf8+uh/8AgPL/APHK8PyaPwFH+rmW/wDPv8WH+t2cf8/me4f8Nf8Ajj/n00X/AMB5f/jtH/DX3jj/AJ9dD/8AAeX/AOOV4fk0fgKP9XMt/wCff4sP9bs4/wCfzPcP+Gv/ABx/z6aL/wCA8v8A8do/4a+8cf8AProf/gPL/wDHK8PyaPwFH+rmW/8APv8AFh/rdnH/AD+Z7h/w1/44/wCfTRf/AAHl/wDjtH/DX3jj/n10P/wHl/8AjleH5NH4Cj/VzLf+ff4sP9bs4/5/M9w/4a/8cf8APpov/gPL/wDHaP8Ahr7xx/z66H/4Dy//AByvD8mj8BR/q5lv/Pv8WH+t2cf8/me4f8Nf+OP+fTRf/AeX/wCO0f8ADX3jj/n10P8A8B5f/jleH5NH4Cj/AFcy3/n3+LD/AFuzj/n8z3D/AIa/8cf8+mi/+A8v/wAdo/4a+8cf8+uh/wDgPL/8crw/Jo/AUf6uZb/z7/Fh/rdnH/P5nuH/AA1/44/59NF/8B5f/jtH/DX3jj/n10P/AMB5f/jleH5NH4Cj/VzLf+ff4sP9bs4/5/M9w/4a/wDHH/Ppov8A4Dy//HaP+GvvHH/Prof/AIDy/wDxyvD8mj8BR/q5lv8Az7/Fh/rdnH/P5nuH/DX/AI4/59NF/wDAeX/47R/w1944/wCfXQ//AAHl/wDjleH5NH4Cj/VzLf8An3+LD/W7OP8An8z3D/hr/wAcf8+mi/8AgPL/APHaP+GvvHH/AD66H/4Dy/8AxyvD8mj8BR/q5lv/AD7/ABYf63Zx/wA/me4f8Nf+OP8An00X/wAB5f8A47R/w1944/59dD/8B5f/AI5Xh+TR+Ao/1cy3/n3+LD/W7OP+fzPcP+Gv/HH/AD6aL/4Dy/8Ax2j/AIa+8cf8+uh/+A8v/wAcrw/Jo/AUf6uZb/z7/Fh/rdnH/P5nuH/DX/jj/n00X/wHl/8AjtH/AA1944/59dD/APAeX/45Xh+TR+Ao/wBXMt/59/iw/wBbs4/5/M9w/wCGv/HH/Ppov/gPL/8AHaP+GvvHH/Prof8A4Dy//HK8PyaPwFH+rmW/8+/xYf63Zx/z+Z7h/wANf+OP+fTRf/AeX/47R/w1944/59dD/wDAeX/45Xh+TR+Ao/1cy3/n3+LD/W7OP+fzPcP+Gv8Axx/z6aL/AOA8v/x2j/hr7xx/z66H/wCA8v8A8crw/Jo/AUf6uZb/AM+/xYf63Zx/z+Z7h/w1/wCOP+fTRf8AwHl/+O0f8NfeOP8An10P/wAB5f8A45Xh+TR+Ao/1cy3/AJ9/iw/1uzj/AJ/M9w/4a/8AHH/Ppov/AIDy/wDx2j/hr7xx/wA+uh/+A8v/AMcrw/Jo/AUf6uZb/wA+/wAWH+t2cf8AP5nuH/DX/jj/AJ9NF/8AAeX/AOO0f8NfeOP+fXQ//AeX/wCOV4fk0fgKP9XMt/59/iw/1uzj/n8z3D/hr/xx/wA+mi/+A8v/AMdo/wCGvvHH/Prof/gPL/8AHK8PyaPwFH+rmW/8+/xYf63Zx/z+Z7h/w1/44/59NF/8B5f/AI7R/wANfeOP+fXQ/wDwHl/+OV4fk0fgKP8AVzLf+ff4sP8AW7OP+fzPcP8Ahr/xx/z6aL/4Dy//AB2j/hr7xx/z66H/AOA8v/xyvD8mj8BR/q5lv/Pv8WH+t2cf8/me4f8ADX/jj/n00X/wHl/+O0f8NfeOP+fXRP8AwHl/+OV4fk0Uf6uZb/z7/Fh/rdnH/P5nuH/DYHjj/n20b/wGl/8AjtL/AMNf+OP+fXRv/Aab/wCO14dQOtT/AKtZb/z7/EP9bs5/5/s9y/4bA8cfxWui8dvss3/x2vtDTblrq2jkbqRX5edjX6gaN/x4Rf7tfn3E+XYbL5U1h42vf9D9f4DzfGZp7V4qblaxoDpS0gpa+EP2IKKKKAOc8ca3N4e0Ce8t1RpkKhd/TlgP615j/wALc1z/AJ52v/ftv/iq7z4rf8ihc/7yf+hrXhg4r+dePeIMwyzMY0sLUcY2R9tkmAw+KoSnVjd3O5/4W7rn/PO0/wC+D/8AFUn/AAuDW/8Anlaf98H/ABriCaSvzVcY53/z/Z9J/Y2C/kO3/wCFwa1/zztP++D/AI0v/C39b/uWn/fB/wAa4bFGKP8AXHO/+f7D+xsF/Idz/wALe1v/AJ52n/fB/wAaP+Fwa3/zytP++D/jXD0Uf6453/z/AGH9jYL+Q7f/AIXBrX/PO0/74P8AjS/8Lf1v+5af98H/ABrhsUYo/wBcc7/5/sP7GwX8h3P/AAt7W/8Annaf98H/ABo/4XBrf/PK0/74P+NcPRR/rjnf/P8AYf2Ngv5Dt/8AhcGtf887T/vg/wCNL/wt/W/7lp/3wf8AGuGxRij/AFxzv/n+w/sbBfyHc/8AC3tb/wCedp/3wf8AGj/hcGt/88rT/vg/41w9FH+uOd/8/wBh/Y2C/kO3/wCFwa1/zztP++D/AI0v/C39b/uWn/fB/wAa4bFGKP8AXHO/+f7D+xsF/Idz/wALe1v/AJ52n/fB/wAaP+Fwa3/zytP++D/jXD0Uf6453/z/AGH9jYL+Q7f/AIXBrX/PO0/74P8AjS/8Lf1v+5af98H/ABrhsUYo/wBcc7/5/sP7GwX8h3P/AAt7W/8Annaf98H/ABo/4XBrf/PK0/74P+NcPRR/rjnf/P8AYf2Ngv5Dt/8AhcGtf887T/vg/wCNL/wt/W/7lp/3wf8AGuGxRij/AFxzv/n+w/sbBfyHc/8AC3tb/wCedp/3wf8AGj/hcGt/88rT/vg/41w9FH+uOd/8/wBh/Y2C/kO3/wCFwa1/zztP++D/AI0v/C39b/uWn/fB/wAa4bFGKP8AXHO/+f7D+xsF/Idz/wALe1v/AJ52n/fB/wAaP+Fwa3/zytP++D/jXD0Uf6453/z/AGH9jYL+Q7f/AIXBrX/PO0/74P8AjS/8Lf1v+5af98H/ABrhsUYo/wBcc7/5/sP7GwX8h3P/AAt7W/8Annaf98H/ABo/4XBrf/PK0/74P+NcPRR/rjnf/P8AYf2Ngv5Dt/8AhcGtf887T/vg/wCNL/wt/W/7lp/3wf8AGuGxRij/AFxzv/n+w/sbBfyHc/8AC3tb/wCedp/3wf8AGj/hcGt/88rT/vg/41w9FH+uOd/8/wBh/Y2C/kO3/wCFwa1/zztP++D/AI0v/C39b/uWn/fB/wAa4bFGKP8AXHO/+f7D+xsF/Idz/wALe1v/AJ52n/fB/wAaP+Fwa3/zytP++D/jXD0Uf6453/z/AGH9jYL+Q7f/AIXBrX/PO0/74P8AjS/8Lf1v+5af98H/ABrhsUYo/wBcc7/5/sP7GwX8h3P/AAt7W/8Annaf98H/ABo/4XBrf/PK0/74P+NcPRR/rjnf/P8AYf2Ngv5Dt/8AhcGtf887T/vg/wCNL/wt/W/7lp/3wf8AGuGxRij/AFxzv/n+w/sbBfyHc/8AC3tb/wCedp/3wf8AGj/hcGt/88rT/vg/41w9FH+uOd/8/wBh/Y2C/kO3/wCFwa1/zztP++D/AI0v/C3tb/uWn/fB/wAa4bFKQvpR/rjnf/P9h/Y2C/kO3Hxf1rPzJa4/65n/AOKqzo/xV1i+1S0t5Y7YRzTJG+1SDgsAcHd6e1efY/Wr3h4f8T/TP+vmL/0MV6WWcV5xWxtKnUrtptfmcmLynCQoznGFmkfS6NlKkqOP/V/hTx0r+vaesFc/MBo61xXxq/5JX4r/AOwXc/8Aopq7WuI+NP8AySvxV/2DLn/0U1dlD+LD1R52Y/7nV/wv8j86B0pR0NIOlKOhr+maX8OPofxJX/iS9RB0paQdKWtTEKKKKBBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFMA/hNfp/on/AB4Qf7tfmB/Ca/T/AET/AI8IP92vyfjX46Xz/Q/efDLav8jQHSlpB0pa/MT96CkPSlpD0oA474rf8ijdf70f/oa14R3r3f4rf8ijdf70f/oa14R3r+VPE3/kax/wo/RuHP8Ad5ev6C0UUV+Pn14UUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFX/Dv/If0z/r5i/9DWs89K0PD3/IwaZ/19Rf+hrXsZR/v9H/ABL8zhx3+7z9GfSsf+r/AAp46UyP/V/hTx0r+7qXwI/GBtcT8av+SVeKv+wXc/8Aotq7auI+NP8AySvxV/2DLn/0U1dmH/iw9UebmX+51f8ACz86B0pR0NIOlKOhr+maX8OPofxLX/iS9RB0paQdKWtTEKKKKBBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFACfwn61+oOjf8g+L6V+X38J+tfqDo3/ACD4vpX5Rxr8dL5/ofvPhltX+RfHSlpB0pa/MT96CkPSlpD0oA434qf8ijdfWP8A9GLXhVe6/FT/AJFG6+sf/oxa8Kr+U/E3/kax/wAK/U/RuHP92l6/oFFFFfkB9eFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABV/w7/wAh/TP+vmL/ANDWqFX/AA7/AMh/TP8Ar5i/9DWvYyf/AH+j/iX5nDjv93n6M+lY/wDV/hTx0pkf+r/CnjpX93UvgR+MDa4n41f8kq8Vf9gu5/8ARbV21cR8af8Aklfir/sGXP8A6KauzD/xYeqPNzL/AHOr/hZ+dHYUq9DSHtSr0Nf0zR/hw9D+Ja/8SXqFFFFamAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUDrRQOtACHoa/UHRv+PCL/AHa/L49DX6g6N/x4Rf7tflHGvxUvn+h+8+GW1f5GhRRRX5ifvQUh6UtIelAHG/FT/kUbr6x/+jFrwqvdfip/yKN19Y//AEYteFV/Kfib/wAjWP8AhX6n6Pw5/u0vX9Aooor8gPrgooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooopgFX/AA7/AMh/TP8Ar5i/9DWqFX/Dv/If0z/r5i/9DWvXyf8A3+j/AIl+Zw47/d5+jPpWL/Vj6U8dBTIv9WPpTx0Ff3dS+BH4wNrifjV/ySrxV/2C7n/0W1dtXEfGn/klfir/ALBlz/6KauzD/wAWHqjzcy/3Or/hZ+dJ6UD7poPf60D7pr+maP8ADh6H8S1/4kvUD1ooPWitTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKB1ooHWgBD0NfqDo3/AB4Rf7tfl8ehr9QdG/48Iv8Adr8o41+Kl8/0P3nwy2r/ACNCiiivzE/egpD0paQ9KAON+Kn/ACKN19Y//Ri14VXuvxU/5FG6+sf/AKMWvCq/lPxN/wCRrH/Cv1P0fhz/AHaXr+gUUUV+QH1wUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUwCr/AId/5D+mf9fMX/oa1Qq/4d/5D+mf9fMX/oa16+T/AO/0f8S/M4cd/u8/Rn0rF/qx9KeOgpkX+rH0p46Cv7upfAj8YG1xPxq/5JV4q/7Bdz/6Lau2riPjT/ySvxV/2DLn/wBFNXZh/wCLD1R5uZf7nV/ws/Ok9KB900UD7pr+maP8OHofxLX/AIkvUD1ooPWitTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKB1ooHWgBD0NfqDo3/HhF/u1+Xx6Gv1B0b/jwi/3a/KONfipfP9D958Mtq/yNCiiivzE/egpD0paQ9KAON+Kn/Io3X1j/APRi14VXuvxU/wCRRuvrH/6MWvCq/lPxN/5Gsf8ACv1P0fhz/dpev6BRRRX5AfXBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRTAKv+Hf8AkP6Z/wBfMX/oa1Qq/wCHf+Q/pn/XzF/6Gtevk/8Av9H/ABL8zhx3+7z9GfSsX+rH0p46CmRf6sfSnjoK/u6l8CPxgbXE/Gr/AJJV4q/7Bdz/AOi2rtq4j40/8kr8Vf8AYMuf/RTV2Yf+LD1R5uZf7nV/ws/OgdKUfdNIOlKPumv6Zo/w4eh/Etf+JL1A9aKD1orUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACgdaKB1oAQ9DX6g6N/x4Rf7tfl8ehr9QdG/48Iv92vyjjX4qXz/AEP3nwy2r/I0KKKK/MT96CkPSlpD0oA434qf8ijdfWP/ANGLXhVe6/FT/kUbr6x/+jFrwqv5T8Tf+RrH/Cv1P0fhz/dpev6BRRRX5AfXBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRTAKv+Hf+Q/pn/XzF/wChrVCr/h3/AJD+mf8AXzF/6Gtevk/+/wBH/EvzOHHf7vP0Z9Kxf6sfSnjoKZF/qx9KeOgr+7qXwI/GBtcT8av+SVeKv+wXc/8Aotq7auI+NP8AySvxV/2DLn/0U1dmH/iw9UebmX+51f8ACz86R0oHQ0dqB0Nf0zR/hw9D+Ja/8SXqFFFFamAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUDrRQOtACHoa/UHRv+PCL/dr8vj0NfqDo3/HhF/u1+Uca/FS+f6H7z4ZbV/kaFFFFfmJ+9BSHpS0h6UAcb8VP+RRuvrH/AOjFrwqvdfip/wAijdfWP/0YteFV/Kfib/yNY/4V+p+j8Of7tL1/QKKKK/ID64KKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKYBV/w7/wAh/TP+vmL/ANDWqFX/AA7/AMh/TP8Ar5i/9DWvXyf/AH+j/iX5nDjv93n6M+lYv9WPpTx0FMi/1Y+lPHQV/d1L4EfjA2uJ+NX/ACSrxV/2C7n/ANFtXbVxHxp/5JX4q/7Blz/6KauzD/xYeqPNzL/c6v8AhZ+dI6UDoaO1A6Gv6Zo/w4eh/Etf+JL1CiiitTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKB1ooHWgBD0NfqDo3/HhF/u1+Xx6Gv1B0b/jwi/3a/KONfipfP9D958Mtq/yNCiiivzE/egpD0paQ9KAON+Kn/Io3X1j/APRi14VXuvxU/wCRRuvrH/6MWvCq/lPxN/5Gsf8ACv1P0fhz/dpev6BRRRX5AfXBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRTAKv+Hf8AkP6Z/wBfMX/oa1Qq/wCHf+Q/pn/XzF/6Gtevk/8Av9H/ABL8zhx3+7z9GfSsX+rH0p46CmRf6sfSnjoK/u6l8CPxgbXE/Gr/AJJV4q/7Bdz/AOi2rtq4j40/8kr8Vf8AYMuf/RTV2Yf+LD1R5uZf7nV/ws/OkdKB0NHagdDX9M0f4cPQ/iWv/El6hRRRWpgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFA60UDrQAh6Gv1B0b/jwi/wB2vy+PQ1+oOjf8eEX+7X5Rxr8VL5/ofvPhltX+RoUUUV+Yn70FIelLSHpQBxvxU/5FG6+sf/oxa8Kr3X4qf8ijdfWP/wBGLXhVfyn4m/8AI1j/AIV+p+j8Of7tL1/QKKKK/ID64KKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKYBV/wAO/wDIf0z/AK+Yv/Q1qhV/w7/yH9M/6+Yv/Q1r18n/AN/o/wCJfmcOO/3efoz6Vi/1Y+lPHQUyL/Vj6U8dBX93UvgR+MDa4n41f8kq8Vf9gu5/9FtXbVxHxp/5JX4q/wCwZc/+imrsw/8AFh6o83Mv9zq/4WfnSOlA6GjtQOhr+maP8OHofxLX/iS9QooorUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACgdaKB1oAQ9DX6g6N/wAeEX+7X5fHoa/UHRv+PCL/AHa/KONfipfP9D958Mtq/wAjQooor8xP3oKQ9KWkPSgDjfip/wAijdfWP/0YteFV7r8VP+RRuvrH/wCjFrwqv5T8Tf8Akax/wr9T9H4c/wB2l6/oFFFFfkB9cFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFMAq/wCHf+Q/pn/XzF/6GtUKv+Hf+Q/pn/XzF/6Gtevk/wDv9H/EvzOHHf7vP0Z9Kxf6sfSnjoKZF/qx9KeOgr+7qXwI/GBtcT8av+SVeKv+wXc/+i2rtq4j40/8kr8Vf9gy5/8ARTV2Yf8Aiw9UebmX+51f8LPzpHSgdDR2oHQ1/TNH+HD0P4lr/wASXqFFFFamAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUDrRQOtACHoa/UHRv8Ajwi/3a/L49DX6g6N/wAeEX+7X5Rxr8VL5/ofvPhltX+RoUUUV+Yn70FIelLSHpQBxvxU/wCRRuvrH/6MWvCq91+Kn/Io3X1j/wDRi14VX8p+Jv8AyNY/4V+p+j8Of7tL1/QKKKK/ID64KKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKYBV/w7/yH9M/6+Yv/Q1qhV/w7/yH9M/6+Yv/AENa9fJ/9/o/4l+Zw47/AHefoz6Vi/1Y+lPHQUyL/Vj6U8dBX93UvgR+MDa4n41f8kq8Vf8AYLuf/RbV21cR8af+SV+Kv+wZc/8Aopq7MP8AxYeqPNzL/c6v+Fn50jpQOho7UDoa/pmj/Dh6H8S1/wCJL1CiiitTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKB1ooHWgBD0NfqDo3/HhF/u1+Xx6Gv1B0b/AI8Iv92vyjjX4qXz/Q/efDLav8jQooor8xP3oKQ9KWkPSgDjfip/yKN19Y//AEYteFV7r8VP+RRuvrH/AOjFrwqv5T8Tf+RrH/Cv1P0fhz/dpev6BRRRX5AfXBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRTAKv+Hf+Q/pn/XzF/6GtUKv+Hf+Q/pn/XzF/wChrXr5P/v9H/EvzOHHf7vP0Z9Kxf6sfSnjoKZF/qx9KeOgr+7qXwI/GBtcT8av+SVeKv8AsF3P/otq7auI+NP/ACSvxV/2DLn/ANFNXZh/4sPVHm5l/udX/Cz86R0oHQ0dqB0Nf0zR/hw9D+Ja/wDEl6hRRRWpgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFA60UDrQAh6Gv1B0b/jwi/3a/L49DX6g6N/x4Rf7tflHGvxUvn+h+8+GW1f5GhRRRX5ifvQUh6UtIelAHG/FT/kUbr6x/8Aoxa8Kr3X4qf8ijdfWP8A9GLXhVfyn4m/8jWP+Ffqfo/Dn+7S9f0CiiivyA+uCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiimAVf8O/8h/TP+vmL/wBDWqFX/Dv/ACH9M/6+Yv8A0Na9fJ/9/o/4l+Zw47/d5+jPpWL/AFY+lPHQUyL/AFY+lPHQV/d1L4EfjA2uJ+NX/JKvFX/YLuf/AEW1dtXEfGn/AJJX4q/7Blz/AOimrsw/8WHqjzcy/wBzq/4WfnSOlA6GjtQOhr+maP8ADh6H8S1/4kvUKKKK1MAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAoHWigdaAEPQ1+oOjf8eEX+7X5fHoa/UHRv+PCL/dr8o41+Kl8/wBD958Mtq/yNCiiivzE/egpD0paQ9KAON+Kn/Io3X1j/wDRi14VXuvxU/5FG6+sf/oxa8Kr+U/E3/kax/wr9T9H4c/3aXr+gUUUV+QH1wUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUwCr/h3/kP6Z/18xf8Aoa1Qq/4d/wCQ/pn/AF8xf+hrXr5P/v8AR/xL8zhx3+7z9GfSsX+rH0p46CmRf6sfSnjoK/u6l8CPxgbXE/Gr/klXir/sF3P/AKLau2riPjT/AMkr8Vf9gy5/9FNXZh/4sPVHm5l/udX/AAs/OkdKB0NHagdDX9M0f4cPQ/iWv/El6hRRRWpgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFA60UDrQAh6Gv1B0b/jwi/3a/L49DX6g6N/x4Rf7tflHGvxUvn+h+8+GW1f5GhRRRX5ifvQUh6UtIelAHG/FT/kUbr6x/wDoxa8Kr3X4qf8AIo3X1j/9GLXhVfyn4m/8jWP+Ffqfo/Dn+7S9f0CiiivyA+uCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiimAVf8O/8AIf0z/r5i/wDQ1qhV/wAO/wDIf0z/AK+Yv/Q1r18n/wB/o/4l+Zw47/d5+jPpWL/Vj6U8dBTIv9WPpTx0Ff3dS+BH4wNrifjV/wAkq8Vf9gu5/wDRbV21cR8af+SV+Kv+wZc/+imrsw/8WHqjzcy/3Or/AIWfnSOlA6GjtQOhr+maP8OHofxLX/iS9QooorUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACgdaKB1oAQ9DX6g6N/x4Rf7tfl8ehr9QdG/48Iv92vyjjX4qXz/Q/efDLav8jQooor8xP3oKQ9KWkPSgDjfip/yKN19Y/wD0YteFV7r8VP8AkUbr6x/+jFrwqv5T8Tf+RrH/AAr9T9H4c/3aXr+gUUUV+QH1wUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUwCr/h3/AJD+mf8AXzF/6GtUKv8Ah3/kP6Z/18xf+hrXr5P/AL/R/wAS/M4cd/u8/Rn0rF/qx9KeOgpkX+rH0p46Cv7upfAj8YG1xPxq/wCSVeKv+wXc/wDotq7auI+NP/JK/FX/AGDLn/0U1dmH/iw9UebmX+51f8LPzpHSgdDR2oHQ1/TNH+HD0P4lr/xJeoUUUVqYBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABQOtFA60AIehr9QdG/48Iv8Adr8vj0NfqDo3/HhF/u1+Uca/FS+f6H7z4ZbV/kaFFFFfmJ+9BSHpS0h6UAcb8VP+RRuvrH/6MWvCq91+Kn/Io3X1j/8ARi14VX8p+Jv/ACNY/wCFfqfo/Dn+7S9f0CiiivyA+uCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiimAVf8ADv8AyH9M/wCvmL/0NaoVf8O/8h/TP+vmL/0Na9fJ/wDf6P8AiX5nDjv93n6M+lYv9WPpTx0FMi/1Y+lPHQV/d1L4EfjA2uJ+NX/JKvFX/YLuf/RbV21cR8af+SV+Kv8AsGXP/opq7MP/ABYeqPNzL/c6v+Fn50jpQOho7UDoa/pmj/Dh6H8S1/4kvUKKKK1MAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAoHWigdaAEPQ1+oOjf8AHhF/u1+Xx6Gv1B0b/jwi/wB2vyjjX4qXz/Q/efDLav8AI0KKKK/MT96CkPSlpD0oA434qf8AIo3X1j/9GLXhVe6/FT/kUbr6x/8Aoxa8Kr+U/E3/AJGsf8K/U/R+HP8Adpev6BRRRX5AfXBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRTAKv8Ah3/kP6Z/18xf+hrVCr/h3/kP6Z/18xf+hrXr5P8A7/R/xL8zhx3+7z9GfSsX+rH0p46CmRf6sfSnjoK/u6l8CPxgbXE/Gr/klXir/sF3P/otq7auI+NP/JK/FX/YMuf/AEU1dmH/AIsPVHm5l/udX/Cz86R0oHQ0dqB0Nf0zR/hw9D+Ja/8AEl6hRRRWpgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFA60UDrQAh6Gv1B0b/AI8Iv92vy+PQ1+oOjf8AHhF/u1+Uca/FS+f6H7z4ZbV/kaFFFFfmJ+9BSHpS0h6UAcb8VP8AkUbr6x/+jFrwqvdfip/yKN19Y/8A0YteFV/Kfib/AMjWP+Ffqfo/Dn+7S9f0CiiivyA+uCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiimAVf8O/8h/TP+vmL/0NaoVf8O/8h/TP+vmL/wBDWvXyf/f6P+JfmcOO/wB3n6M+lYv9WPpTx0FMi/1Y+lPHQV/d1L4EfjA2uJ+NX/JKvFX/AGC7n/0W1dtXEfGn/klfir/sGXP/AKKauzD/AMWHqjzcy/3Or/hZ+dI6UDoaO1A6Gv6Zo/w4eh/Etf8AiS9QooorUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACgdaKB1oAQ9DX6g6N/x4Rf7tfl8ehr9QdG/wCPCL/dr8o41+Kl8/0P3nwy2r/I0KKKK/MT96CkPSlpD0oA434qf8ijdfWP/wBGLXhVe6/FT/kUbr6x/wDoxa8Kr+U/E3/kax/wr9T9H4c/3aXr+gUUUV+QH1wUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUwCr/h3/kP6Z/18xf+hrVCr/h3/kP6Z/18xf8Aoa16+T/7/R/xL8zhx3+7z9GfSsX+rH0p46CmRf6sfSnjoK/u6l8CPxgbXE/Gr/klXir/ALBdz/6Lau2riPjT/wAkr8Vf9gy5/wDRTV2Yf+LD1R5uZf7nV/ws/OkdKB0NHagdDX9M0f4cPQ/iWv8AxJeoUUUVqYBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABQOtFA60AIehr9QdG/48Iv92vy+PQ1+oOjf8eEX+7X5Rxr8VL5/ofvPhltX+RoUUUV+Yn70FIelLSHpQBxvxU/5FG6+sf/AKMWvCq91+Kn/Io3X1j/APRi14VX8p+Jv/I1j/hX6n6Pw5/u0vX9Aooor8gPrgooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooopgFX/Dv/If0z/r5i/8AQ1qhV/w7/wAh/TP+vmL/ANDWvXyf/f6P+JfmcOO/3efoz6Vi/wBWPpTx0FMi/wBWPpTx0Ff3dS+BH4wNrifjV/ySrxV/2C7n/wBFtXbVxHxp/wCSV+Kv+wZc/wDopq7MP/Fh6o83Mv8Ac6v+Fn50jpQOho7UDoa/pmj/AA4eh/Etf+JL1CiiitTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKB1ooHWgBD0NfqDo3/HhF/u1+Xx6Gv1B0b/jwi/3a/KONfipfP8AQ/efDLav8jQooor8xP3oKQ9KWkPSgDjfip/yKN19Y/8A0YteFV7r8VP+RRuvrH/6MWvCq/lPxN/5Gsf8K/U/R+HP92l6/oFFFFfkB9cFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFMAq/4d/5D+mf9fMX/AKGtUKv+Hf8AkP6Z/wBfMX/oa16+T/7/AEf8S/M4cd/u8/Rn0rF/qx9KeOgpkX+rH0p46Cv7upfAj8YG1xPxq/5JV4q/7Bdz/wCi2rtq4j40/wDJK/FX/YMuf/RTV2Yf+LD1R5uZf7nV/wALPzpHSgdDR2oHQ1/TNH+HD0P4lr/xJeoUUUVqYBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABQOtFA60AIehr9QdG/48Iv92vy+PQ1+oOjf8eEX+7X5Rxr8VL5/ofvPhltX+RoUUUV+Yn70FIelLSHpQBxvxU/5FG6+sf8A6MWvCq91+Kn/ACKN19Y//Ri14VX8p+Jv/I1j/hX6n6Pw5/u0vX9Aooor8gPrgooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooopgFX/Dv/ACH9M/6+Yv8A0NaoVf8ADv8AyH9M/wCvmL/0Na9fJ/8Af6P+JfmcOO/3efoz6Vi/1Y+lPHQUyL/Vj6U8dBX93UvgR+MDa4n41f8AJKvFX/YLuf8A0W1dtXEfGn/klfir/sGXP/opq7MP/Fh6o83Mv9zq/wCFn50jpQOho7UDoa/pmj/Dh6H8S1/4kvUKKKK1MAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAoHWigdaAEPQ1+oOjf8eEX+7X5fHoa/UHRv+PCL/dr8o41+Kl8/0P3nwy2r/I0KKKK/MT96CkPSlpD0oA434qf8ijdfWP8A9GLXhVe6/FT/AJFG6+sf/oxa8Kr+U/E3/kax/wAK/U/R+HP92l6/oFFFFfkB9cFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFMAq/4d/wCQ/pn/AF8xf+hrVCr/AId/5D+mf9fMX/oa16+T/wC/0f8AEvzOHHf7vP0Z9Kxf6sfSnjoKZF/qx9KeOgr+7qXwI/GBtcT8av8AklXir/sF3P8A6Lau2riPjT/ySvxV/wBgy5/9FNXZh/4sPVHm5l/udX/Cz86R0oHQ0dqB0Nf0zR/hw9D+Ja/8SXqFFFFamAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUDrRQOtACHoa/UHRv+PCL/AHa/L49DX6g6N/x4Rf7tflHGvxUvn+h+8+GW1f5GhRRRX5ifvQUh6UtIelAHG/FT/kUbr6x/+jFrwqvdfip/yKN19Y//AEYteFV/Kfib/wAjWP8AhX6n6Pw5/u0vX9Aooor8gPrgooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooopgFX/AA7/AMh/TP8Ar5i/9DWqFX/Dv/If0z/r5i/9DWvXyf8A3+j/AIl+Zw47/d5+jPpWL/Vj6U8dBTIv9WPpTx0Ff3dS+BH4wNrifjV/ySrxV/2C7n/0W1dtXEfGn/klfir/ALBlz/6Lauyh/Fh6o83Mv9zq/wCFn50jpQOho7UDoa/pij/Dh6H8S1/4kvUKKKK2MAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAoHWigdaAEPQ1+oOjf8eEX+7X5fHoa/UHRv+PCL/dr8o41+Kl8/0P3nwy2r/I0KKKK/MT96CkPSlpD0oA434qf8ijdfWP8A9GLXhVe6fFQ58I3X1j/9GLXhdfyn4m/8jWP+FH6Pw5/u0vX9Aooor8gPrgooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooopgFX/Dv/If0z/r5i/8AQ1qhV/w7/wAh/TP+vmL/ANDWvXyf/f6P+JfmcOO/3efoz6Vj/wBV+FOPQU2P/VfhTj0Ff3ZR+CPofjEhK4n41f8AJK/FX/YMuf8A0U1dtWP4p0GDxNoV9pN0XW3vYHt5GjIDBWXBxnvg+hrspSUakW9kceMpSrYepTju00fmVj9KOT2r7C/4Yu8LAgf2xrX/AH9h/wDjVL/wxd4WP/MY1n/v7D/8ar9gp8XYGEFFp6H82T4AzWc3LT7z48oxX2H/AMMWeF/+gxrX/f2H/wCN0f8ADFfhf/oMa1/39h/+NVp/rhgez+4z/wCIe5t5fefHmKMV9h/8MW+Fv+gxrf8A38h/+N0f8MW+Fv8AoMa3/wB/If8A43R/rhgf5X9wf8Q9zby+8+PMUYr7D/4Yt8Lf9BjW/wDv5D/8bo/4Yt8Lf9BjW/8Av5D/APG6P9cMD/K/uD/iHubeX3nx5ijFfYf/AAxb4W/6DGt/9/If/jdH/DFvhb/oMa3/AN/If/jdH+uGB/lf3B/xD3NvL7z48xRivsP/AIYt8Lf9BjW/+/kP/wAbo/4Yt8Lf9BjW/wDv5D/8bo/1wwP8r+4P+Ie5t5fefHmKMV9h/wDDFvhb/oMa3/38h/8AjdH/AAxb4W/6DGt/9/If/jdH+uGB/lf3B/xD3NvL7z48xRivsP8A4Yt8Lf8AQY1v/v5D/wDG6P8Ahi3wt/0GNb/7+Q//ABuj/XDA/wAr+4P+Ie5t5fefHmKMV9h/8MW+Fv8AoMa3/wB/If8A43R/wxb4W/6DGt/9/If/AI3R/rhgf5X9wf8AEPc28vvPjzFGK+w/+GLfC3/QY1v/AL+Q/wDxuj/hi3wt/wBBjW/+/kP/AMbo/wBcMD/K/uD/AIh7m3l958eYoxX2H/wxb4W/6DGt/wDfyH/43R/wxb4W/wCgxrf/AH8h/wDjdH+uGB/lf3B/xD3NvL7z48xRivsP/hi3wt/0GNb/AO/kP/xuj/hi3wt/0GNb/wC/kP8A8bo/1wwP8r+4P+Ie5t5fefHmKMV9h/8ADFvhb/oMa3/38h/+N0f8MW+Fv+gxrf8A38h/+N0f64YH+V/cH/EPc28vvPjzFGK+w/8Ahi3wt/0GNb/7+Q//ABuj/hi3wt/0GNb/AO/kP/xuj/XDA/yv7g/4h7m3l958eYoxX2H/AMMW+Fv+gxrf/fyH/wCN0f8ADFvhb/oMa3/38h/+N0f64YH+V/cH/EPc28vvPjzFGK+w/wDhi3wt/wBBjW/+/kP/AMbo/wCGLfC3/QY1v/v5D/8AG6P9cMD/ACv7g/4h7m3l958eYoxX2H/wxb4W/wCgxrf/AH8h/wDjdH/DFvhb/oMa3/38h/8AjdH+uGB/lf3B/wAQ9zby+8+PMUYr7D/4Yt8Lf9BjW/8Av5D/APG6P+GLfC3/AEGNb/7+Q/8Axuj/AFwwP8r+4P8AiHubeX3nx5ijFfYf/DFvhb/oMa3/AN/If/jdH/DFvhb/AKDGt/8AfyH/AON0f64YH+V/cH/EPc28vvPjzFGK+w/+GLfC3/QY1v8A7+Q//G6P+GLfC3/QY1v/AL+Q/wDxuj/XDA/yv7g/4h7m3l958eYoxX2H/wAMW+Fv+gxrf/fyH/43R/wxb4W/6DGt/wDfyH/43R/rhgf5X9wf8Q9zby+8+PMUYr7D/wCGLfC3/QY1v/v5D/8AG6P+GLfC3/QY1v8A7+Q//G6P9cMD/K/uD/iHubeX3nx5ijFfYf8Awxb4W/6DGt/9/If/AI3R/wAMW+Fv+gxrf/fyH/43R/rhgf5X9wf8Q9zby+8+PMUYr7D/AOGLfC3/AEGNb/7+Q/8Axuj/AIYt8Lf9BjW/+/kP/wAbo/1wwP8AK/uD/iHubeX3nx5ijFfYf/DFvhb/AKDGt/8AfyH/AON0f8MW+Fv+gxrf/fyH/wCN0f64YH+V/cH/ABD3NvL7z48xRivsP/hi3wt/0GNb/wC/kP8A8bo/4Yt8Lf8AQY1v/v5D/wDG6P8AXDA/yv7g/wCIe5t5fefHmKK+w/8Ahizwt/0Gdb/7+Q//ABql/wCGLfC3/QY1r/v5D/8AG6P9cMD/ACsP+Ie5t5fefHeDX6gaL/x4Q/7teBj9jDwsBt/tfWyD1/ew/wDxqvoK1txbwog5AGK+H4hzejmsoOinpfc/UeDeH8XkftFibe9bYtUUg6UtfHH6kFFFIelAHF/FP/kULv6x/wDoa14YOlfR/iPQYvEOmy2U7ukcmMlMZ4II6g9xXH/8KZ0zP/H3dfjt/wDia/C+NOEsfneOWIwtuWyWrPrMozSjgaUoVE9WeQUYr1//AIUzpv8Az9XX5r/8TR/wpjTv+fy6/Nf/AImvzz/iHGddo/ee++IcL2Z5BijFev8A/CmNO/5/Lr81/wDiaP8AhTGnf8/l1+a//E0v+Ib512j94f6w4XszyDFGK9f/AOFMad/z+XX5r/8AE0f8KY07/n8uvzX/AOJo/wCIb512j94f6w4XszyDFGK9f/4Uxp3/AD+XX5r/APE0f8KY07/n8uvzX/4mj/iG+ddo/eH+sOF7M8gxRivX/wDhTGnf8/l1+a//ABNH/CmNO/5/Lr81/wDiaP8AiG+ddo/eH+sOF7M8gxRivX/+FMad/wA/l1+a/wDxNH/CmNO/5/Lr81/+Jo/4hvnXaP3h/rDhezPIMUV6/wD8KY07/n8uvzX/AOJo/wCFMaZ/z+Xf5r/8TR/xDfOv7v3h/rDhezPIKK9f/wCFK6Z/z+Xf5r/8TR/wpfTv+fy7/Nf/AImq/wCIb512j94f6xYXszyCivX/APhS+nf8/l3+a/8AxNH/AApfTv8An8u/zX/4ml/xDfOu0fvD/WHC9meQUV6//wAKX07/AJ/Lv81/+Jo/4Uvp3/P5d/mv/wATS/4hvnXaP3h/rDhezPIKK9f/AOFL6d/z+Xf5r/8AE0f8KX07/n8u/wA1/wDiaP8AiG+ddo/eH+sOF7M8gor1/wD4Uvp3/P5d/mv/AMTR/wAKX07/AJ/Lv81/+Jqv+Ib512j94f6x4XszyCivYf8AhS+nf8/l1/47/wDE0f8ACl9O/wCfy6/8d/8AiaP+Ib51/d+8P9YcL2Z49RXsP/Cl9O/5/Lr/AMd/+Jo/4Uvp3/P5df8Ajv8A8TS/4htnX937xf6w4Xszx6ivYf8AhS+nf8/l1/47/wDE0f8ACl9O/wCfy6/8d/8Aiaf/ABDfOv7v3lf6xYXszx6ivYP+FL6d/wA/l3/47/8AE0f8KX07/n8u/wDx3/4ml/xDfOu0fvF/rDhezPH6K9g/4Uvp3/P5d/8Ajv8A8TR/wpfTv+fy7/8AHf8A4mn/AMQ3zrtH7w/1iwvZnj9Fewf8KX07/n8u/wDx3/4mj/hS+nf8/l3/AOO//E0v+Ib512j94f6w4Xszx+jFev8A/Cl9O/5/Lv8A8d/+Jo/4Uvpv/P5d/wDjv/xNP/iG+df3fvH/AKxYXszyDFFev/8ACmNN/wCfu8/8d/8AiaP+FMad/wA/d3/47/8AE0v+Ib512j94v9YcL2Z5BSZr2D/hTGnf8/d3/wCO/wDxNH/CmNN/5/Lv81/+Jpf8Q3zrtH7w/wBYcL2Z4/mjNewf8KY03/n8u/8Ax3/4mj/hTGm/8/l3/wCO/wDxNV/xDfOu0fvD/WLC9meQUV6//wAKY07/AJ+7v/x3/wCJo/4Uxp3/AD93f/jv/wATS/4hvnXaP3h/rDhezPIKK9f/AOFMad/z93f/AI7/APE0f8KY07/n7u//AB3/AOJpf8Q3zrtH7w/1hwvZnkFFev8A/CmNO/5+7v8A8d/+Jo/4Uxp3/P3d/wDjv/xNH/EN867R+8P9YcL2Z5BSZr2D/hTGnf8AP3d/+O//ABNH/CmNN/5/Lv8A8d/+Jo/4hvnXZfeL/WHC9meP5rQ0D/kP6X/18xf+hivUP+FMaZ/z+Xf5r/8AE1PY/CPTLC8hnW4uGeGRZV3FcEg5Gfl9q9PL/D/N8Pi6dWajaLT3OfE59hq1GVOKd2jvov8AVinjpTYhtTH4U+v6gpJxgkz8+YUmBS0VqITbSbBTqKVgG7R70bBTqKYDdgo2CnUUAN2CjYKdRQA3YKNgp1FADdgo2CnUUAN2CjYKdRQA3YKNgp1FADdgo2CnUUAN2CjYKdRQA3YKNgp1FADdgo2CnUUAN2CjYKdRQA3YKNgp1FADdgo2CnUUAN2CjYKdRQA3YKNgp1FADdgo2CnUUAN2CjYKdRQA3YKNgp1FADdgo2CnUUAN2CjYKdRQA3YKNgp1FADdgo2CnUUAN2CjYKdRQA3YKNgp1FACbaNopaKAE2gdqMUtFABRRRQAUUUUAFFFFABRRRQAUUUUAJto20tFACbaNtLRQAm2jbS0UAJto20tFACbaMClooATAowKWigBMCjApaKAEwKMClooATAowKWigBMCjApaKAEwKMClooATAowKWigBMCjFLRQAmKMUtFACYoxS0UAJijFLRQAmKMUtFACYowPQUtFACYHpRgUtFACYoxS0UAFFFFABRRRQAUUUUAFJilooATApNgp1FKwCAYpaKKLAf//Z", 0);
        startimage.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
        startimage.setImageAlpha(200);
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);

        this.mExpanded.setVisibility(View.GONE);
        this.mExpanded.setBackgroundColor(Color.parseColor("#FFFFFF"));
        this.mExpanded.setGravity(17);
        this.mExpanded.setOrientation(LinearLayout.VERTICAL);
        this.mExpanded.setPadding(0, 0, 0, 0);
        this.mExpanded.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));

        ScrollView scrollView = new ScrollView(getBaseContext());
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(200)));
        scrollView.setBackgroundColor(Color.parseColor("#FFFFFF"));

        this.view1.setLayoutParams(new LinearLayout.LayoutParams(-1, 5));
        this.view1.setBackgroundColor(Color.parseColor("#FFFFFF"));
        this.patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        this.patches.setOrientation(LinearLayout.VERTICAL);
        this.view2.setLayoutParams(new LinearLayout.LayoutParams(-1, 5));
        this.view2.setBackgroundColor(Color.parseColor("#FFFFFF"));
        this.view2.setPadding(0, 0, 0, 10);
        this.mButtonPanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));

        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams3.gravity = 17;
        
      //  mExpanded.setVisibility(View.VISIBLE);

        new LinearLayout.LayoutParams(-1, dp(25)).topMargin = dp(2);
        this.rootFrame.addView(this.mRootContainer);
        this.rootFrame.addView(this.mRootContaine);
        this.mRootContainer.addView(this.mCollapsed);
        this.mRootContaine.addView(this.mExpanded);
        this.mCollapsed.addView(this.startimage);
        this.mExpanded.addView(this.view1);
        this.mExpanded.addView(scrollView);
        scrollView.addView(this.patches);
        this.mExpanded.addView(this.view2);
        this.mExpanded.addView(relativeLayout);
        this.mFloatingView = this.rootFrame;
        if (Build.VERSION.SDK_INT >= 26) {
            this.params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            this.params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParams4 = this.params;
        layoutParams4.gravity = 51;
        layoutParams4.x = 0;
        layoutParams4.y = 100;
        this.mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        this.mWindowManager.addView(this.mFloatingView, this.params);
        RelativeLayout relativeLayout2 = this.mCollapsed;
        LinearLayout linearLayout = this.mExpanded;
        this.mFloatingView.setOnTouchListener(onTouchListener());
        initMenuButton(relativeLayout2, linearLayout);
    }
    

    void AddCheckBox(final String name,final int TZ) {
        CheckBox CheckBox = new CheckBox(this);
        CheckBox.setText(Html.fromHtml("<font face='roboto'>"+ name + "</font>"));
        CheckBox.setTextColor(Color.parseColor("#000000"));
        CheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
					


                }
            });
        this.patches.addView(CheckBox);
    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = FloatingModMenuService.this.mCollapsed;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        this.initialX = FloatingModMenuService.this.params.x;
                        this.initialY = FloatingModMenuService.this.params.y;
                        this.initialTouchX = motionEvent.getRawX();
                        this.initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - this.initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - this.initialTouchY);
                        if (rawX < 10 && rawY < 10 && FloatingModMenuService.this.isViewCollapsed()) {
                            this.collapsedView.setVisibility(View.GONE);
                            mExpanded.setVisibility(View.VISIBLE);
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        FloatingModMenuService.this.params.x = this.initialX + ((int) (motionEvent.getRawX() - this.initialTouchX));
                        FloatingModMenuService.this.params.y = this.initialY + ((int) (motionEvent.getRawY() - this.initialTouchY));

                        FloatingModMenuService.this.mWindowManager.updateViewLayout(FloatingModMenuService.this.mFloatingView, FloatingModMenuService.this.params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

    private void initMenuButton(final View view2, final View view3) {
       
    }

    

    boolean delayed;
 
    public boolean isViewCollapsed() {
        return this.mFloatingView == null || this.mCollapsed.getVisibility() == View.VISIBLE;
    }

    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }
 
    public void onDestroy() {
        super.onDestroy();
        View view = this.mFloatingView;
        if (view != null) {
            this.mWindowManager.removeView(view);
        }
    }

    private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    public void onTaskRemoved(Intent intent) {
        stopSelf();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        super.onTaskRemoved(intent);
    }


    public void Thread() {
        if (this.mFloatingView == null) {
            return;
        }
        if (isNotInGame()) {
            this.mFloatingView.setVisibility(View.INVISIBLE);
        } else {
            this.mFloatingView.setVisibility(View.VISIBLE);
        }
    }

    private interface InterfaceBtn {
        void OnWrite();
    }

    private interface InterfaceInt {
        void OnWrite(int i);
    }

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }

    int convertSizeToDp(float f) {
        return Math.round(TypedValue.applyDimension(1, f, getResources().getDisplayMetrics()));
    }
   

	



    
    
}


