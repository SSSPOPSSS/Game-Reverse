require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
import "AndLua"
import "wx"
import "gc"
import "android.net.Uri"
import "android.provider.Settings$Secure"
import "android.provider.Settings"
import "android.view.animation.AnimationSet"
import "android.view.animation.LayoutAnimationController"
import "android.view.animation.AlphaAnimation"
import "android.view.animation.TranslateAnimation"
import "android.content.Context"
import "java.io.File"
import "android.graphics.drawable.GradientDrawable"
import "android.graphics.Typeface"
local bf=File(activity.getLuaDir().."/res/zt.ttf");
local tf=Typeface.createFromFile(bf)

activity.setTheme(R.Theme_Blue)
activity.setTitle("仿写UI")
activity.setContentView(loadlayout(layout))

隐藏标题栏()
沉浸状态栏()

--by顾辰 QQ:1993134700
--仅供交流参考，请勿倒卖



窗口 = activity.getSystemService(Context.WINDOW_SERVICE)
窗口容器 = WindowManager.LayoutParams()
if Build.VERSION.SDK_INT >= 26 then
  窗口容器.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY--悬浮窗打开方式
 else
  窗口容器.type = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT--悬浮窗打开方式
end
窗口容器.flags = WindowManager.LayoutParams().FLAG_NOT_FOCUSABLE
窗口容器.gravity = Gravity.LEFT | Gravity.TOP
窗口容器.format = 1
窗口容器.width = WindowManager.LayoutParams.WRAP_CONTENT
窗口容器.height = WindowManager.LayoutParams.WRAP_CONTENT

悬浮窗=loadlayout(wx)
悬浮球=loadlayout(gc)

local 坐标={x=2,y=2}
local 动画对象 = AnimationSet(true)
local 动画容器 = LayoutAnimationController(动画对象,0.2)
local 渐变动画 = AlphaAnimation(0,1)
--local 滑入动画 = TranslateAnimation(-100,0,0,0)
local 下滑动画 = TranslateAnimation(0, 0, 55, 0)

动画容器.setOrder(LayoutAnimationController.ORDER_NORMAL)
渐变动画.setDuration(500)
--滑入动画.setDuration(500)
下滑动画.setDuration(600)

动画对象.addAnimation(渐变动画)
--动画对象.addAnimation(滑入动画)
动画对象.addAnimation(下滑动画)

function 载入悬浮球()
  if(Mp==false)then
    坐标.x = 0
    坐标.y = activity.getWidth()/100
    窗口容器.x = 坐标.x
    窗口容器.y = 坐标.y
    Lin_main.setLayoutAnimation(动画容器)
    窗口.addView(悬浮球,窗口容器)
    Mp = true
  end
end
function 关闭悬浮球()
  if(Mp==true)then
    窗口.removeView(悬浮球)
    Mp = false
  end
end

function 载入悬浮窗口()
  if(Ml==false)then
    坐标.x = activity.getHeight()/4
    坐标.y = activity.getWidth()/7
    窗口容器.x = 坐标.x
    窗口容器.y = 坐标.y
    Lin_Ybb.setLayoutAnimation(动画容器)
    窗口.addView(悬浮窗,窗口容器)
    关闭悬浮球()
    Ml = true
  end
end
function 关闭悬浮窗口()
  if(Ml==true)then
    窗口.removeView(悬浮窗)
    载入悬浮球()
    Ml = false
  end
end

Ml=false
function 移动键.onClick
  if(Ml==false)then
    载入悬浮窗口()
  end
end

Mp=false
function 开启.onClick()
  if (Mp==false) then
    载入悬浮球()
    开启.setText("关闭悬浮窗")
   else
    if(Mp==true)then
      窗口.removeView(悬浮球)
      Mp = false
      开启.setText("开启悬浮窗")
    end
    if(Ml==true)then
      窗口.removeView(悬浮窗)
      Ml = false
    end
  end
end

local firstX,firstY,wmX,wmY

移动键.OnTouchListener = function(v,event)
  if(Ml == false)then
    if(event.getAction() == MotionEvent.ACTION_DOWN)then
      firstX = event.getRawX()
      firstY = event.getRawY()
      wmX = 窗口容器.x
      wmY = 窗口容器.y
     elseif(event.getAction() == MotionEvent.ACTION_MOVE)then
      坐标.x = wmX + (event.getRawX() - firstX)
      坐标.y = wmY + (event.getRawY() - firstY)
      窗口容器.x = 坐标.x
      窗口容器.y = 坐标.y
      窗口.updateViewLayout(悬浮球,窗口容器)
     elseif(event.getAction() == MotionEvent.ACTION_UP)then
      if(event.getRawX() > getX() / 2 - 32)then
        坐标.x = 0
        坐标.y = wmY + (event.getRawY() - firstY)
       else
        坐标.x = 0
        坐标.y = wmY + (event.getRawY() - firstY)
      end
      窗口容器.x = 坐标.x
      窗口容器.y = 坐标.y
      窗口.updateViewLayout(悬浮球,窗口容器)
    end
  end
  return false
end

function getX()
  local mConfiguration = activity.getResources().getConfiguration();
  local ori = mConfiguration.orientation;
  if ori == mConfiguration.ORIENTATION_LANDSCAPE then
    return activity.getHeight()
   else
    return activity.getWidth()
  end
end
function 显示(id)
  id.setVisibility(View.VISIBLE)
end

function 隐藏(id)
  id.setVisibility(View.GONE)
end

隐藏(界面2)
隐藏(界面3)
绘制界面.setBackgroundColor(0xFF00AAFF)
function 绘制界面.onClick
  显示(界面1)
  隐藏(界面2)
  隐藏(界面3)
  绘制界面.setBackgroundColor(0xFF00AAFF)
  功能界面.setBackgroundColor(0x00000000)
  其他界面.setBackgroundColor(0x00000000)

end

function 功能界面.onClick
  显示(界面2)
  隐藏(界面1)
  隐藏(界面3)
  功能界面.setBackgroundColor(0xFF00AAFF)
  绘制界面.setBackgroundColor(0x00000000)
  其他界面.setBackgroundColor(0x00000000)
end

function 其他界面.onClick
  显示(界面3)
  隐藏(界面1)
  隐藏(界面2)
  其他界面.setBackgroundColor(0xFF00AAFF)
  绘制界面.setBackgroundColor(0x00000000)
  功能界面.setBackgroundColor(0x00000000)
end



function 获取悬浮窗权限()
  if Build.VERSION.SDK_INT >= Build.VERSION_CODES.M&&!Settings.canDrawOverlays(this) then
    -- print("没有权限，需要申请权限")
    intent=Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
    intent.setData(Uri.parse("package:" .. activity.getPackageName()))
    activity.startActivityForResult(intent, 100)
    --os.exit()
   else
    print("你已赋予悬浮窗权限了")
  end
end

urla="http://www.iyuji.cn/iyuji/s/bWJSSnBRUlhRRXB3YlJhMmpLZjA5UT09/1616579547661236"
Http.get(urla,nil,function(code,content)
  公告=content:match("【公告】(.-)【公告】")
  时间=content:match("【时间】(.-)【时间】")
  公告2=content:match("【公告2】(.-)【公告2】")
  时间2=content:match("【时间2】(.-)【时间2】")
  内容.Text=""..公告..""
  更新.Text=""..时间..""
  内容2.Text=""..公告2..""
  更新2.Text=""..时间2..""
  if s == "a" then
   else
  end
end)



标题.setTypeface(tf);
更新.setTypeface(tf);
标题二.setTypeface(tf);
内容.setTypeface(tf);
开启.setTypeface(tf);
内容2.setTypeface(tf);
更新2.setTypeface(tf);
权限.setTypeface(tf);
版权.setTypeface(tf);
版权1.setTypeface(tf);
加群.setTypeface(tf);
其他界面.setTypeface(tf);
功能界面.setTypeface(tf);
绘制界面.setTypeface(tf);



设置边框 = function(view, Thickness, FrameColor, InsideColor, radiu)
  import("android.graphics.drawable.GradientDrawable")
  drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setStroke(Thickness, FrameColor)
  drawable.setColor(InsideColor)
  drawable.setCornerRadii({
    radiu,
    radiu,
    radiu,
    radiu,
    radiu,
    radiu,
    radiu,
    radiu
  })
  view.setBackgroundDrawable(drawable)
end


--设置边框(id,边框粗细，边框颜色,内部背景,圆角)
设置边框(开启,3,0xFF5FACC4,0xFF84BDEA,50)
设置边框(权限,3,0xFF5FACC4,0xFF84BDEA,50)
设置边框(加群,3,0xFF5FACC4,0xFF84BDEA,50)
function 加群.onClick()
  跳转QQ群("1021414274")
end