package com.tencent.QQmusic;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.provider.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.widget.CompoundButton.*;
import com.alibaba.fastjson.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import okhttp3.*;
import com.tencent.QQmusic.Http;

import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;



public class MainActivity extends Activity implements OnClickListener {
	private TextView 登录;
	private ImageButton mbutton;
	private boolean 悬浮球 = false;
	private boolean 悬浮窗 = false;
	private int mTouchStartX, mTouchStartY;//手指按下时坐标
	private int 按下X, 按下Y;
    private boolean isMove = false;
	private boolean 移动=false;
	private WindowManager mwindow;
	private WindowManager.LayoutParams lparam;
	private WindowManager mwMenu;
	private WindowManager.LayoutParams mparam;
	private LayoutInflater inflater;
	private View dis;
	private View displayMenu;
	public static int 屏幕高,屏幕宽;
	private String 框架判断;
	//xfc
	private Switch 注入数据;
	private boolean 状态1;
	private Switch 人物方框,敌人射线,人物人数,人物编队,人物距离,人物名字,人物血量,k1,k2,k3,k4,k5,k6,k7,k8,k9;
	private static boolean zt1,zt2,zt3,zt4,zt5,zt6,zt7,zt8,zt9,zt10,zt11,zt12,zt13,zt14,zt15,zt16;
	private static SeekBar mSeekBar ;//拖动
	public static int py=0;//偏移左右
	private TextView 当前模式,虚拟机,ROOT,框架;
	private String 模式="ROOT";
	private TextView 网盘;
	private boolean 悬浮窗是否激活;
	private static TextView textView;//文本拖动显示

    public static void RunShell(String shell) {
        String s = shell;

        try {
            Runtime.getRuntime().exec(s, null, null);//执行
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


	public static boolean 写入文件(String path, String txt) {
        byte[] sourceByte = txt.getBytes();
        if (null != sourceByte) {
            try {
                File file = new File(path); 
                if (!file.exists()) {   
                    File dir = new File(file.getParent());
                    dir.mkdirs();
                    file.createNewFile();
                }
                FileOutputStream outStream = new FileOutputStream(file);
                outStream.write(sourceByte);
                outStream.close();  
                return true;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
        return true;
    }

	public static String 读取文件(String path) {
        String str = "";
        try {
            File urlFile = new File(path);
            InputStreamReader isr = new InputStreamReader(new FileInputStream(urlFile), "UTF-8");
            BufferedReader br = new BufferedReader(isr);

            String mimeTypeLine = null;
            while ((mimeTypeLine = br.readLine()) != null) {
                str = str + mimeTypeLine;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return str;
    }
    //用来访问讯飞语录来实现远程更新
    private void gx(final String url, final String bb) {
        ExecuteElf("mkdir /sdcard/gx");
        new Thread(new Runnable() {
                @Override
                public void run() {
                    Response res = Http.sendPost(url, "", "", "");
                    if (res != null) {
                        try {
                            final String data = res.body().string();
                            String msg = data.substring(data.indexOf("<p>") + 3, data.indexOf("</p>"));
                            //int appversion = MainActivity.this.getPackageManager().getPackageInfo(MainActivity.this.getPackageName(), 0).versionCode;
                            JSONObject jsonObject = JSON.parseObject(msg);
                            String _appversion = jsonObject.getString("appversion");
                            //String _versionname = jsonObject.getString("versionname");
                            final String message = jsonObject.getString("message");

                            final String apkUrl = jsonObject.getString("apkurl");
                            //Log.i("Mobai" , "1");
                            if (_appversion.equals(bb)) {
                                //Log.i("Mobai", "不更新");
                                return;
                            }
                            runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        //Log.i("Mobai", "更新");
                                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                        builder.setTitle("版本更新");
                                        builder.setMessage(message);
                                        builder.setCancelable(false);
                                        builder.setNegativeButton("更新", new DialogInterface.OnClickListener() {

                                                @Override
                                                public void onClick(DialogInterface p1, int p2) {
                                                    //Uri uri = Uri.parse("https://www.lanzoui.com/b00zowtbc");
                                                 //   Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                                  //  startActivity(intent);
                                                    System.exit(0);//打开网址后正常退出App
                                                }
                                            });
                                        builder.show();
                                    }
                                });
                        } catch (Exception e) {
                            //Log.i("Mobai", e.getMessage());
                        }
                    } else {
                        System.exit(0);//正常退出App
                    }
                }
            }).start();
    }




    public void 开关(final String url) {

        new Thread(new Runnable() {
                @Override
                public void run() {
                    Response res = Http.sendPost(url, "", "", "");
                    if (res != null) {
                        try {
                            final String data = res.body().string();
                            String msg = data.substring(data.indexOf("<p>") + 3, data.indexOf("</p>"));
                            JSONObject jsonObject = JSON.parseObject(msg);
                            String 开关 = jsonObject.getString("开关");//解析是否开启

                            if (开关.equals("关")) {
                                runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {

                                            Toast.makeText(MainActivity.this, "软件已关闭使用", Toast.LENGTH_LONG).show();
                                            System.exit(0);//正常退出App

                                        }
                                    });         

                            } else if (开关.equals("开")) {
                                runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(MainActivity.this, "欢迎使用", Toast.LENGTH_LONG).show();


                                        }
                                    });}
                        } catch (Exception e) {

                        }
                    }

                }
            }).start(); 
    }

	public static void 创建文件夹(String path) {
        //新建一个File，传入文件夹目录
        File file = new File(path);
        //判断文件夹是否存在，如果不存在就创建，否则不创建
        if (!file.exists()) {
            //通过file的mkdirs()方法创建目录中包含却不存在的文件夹
            file.mkdirs();
        }

    }

    public static void 写入(String 路径, String 内容) {
        try {
            FileWriter fw = new FileWriter(路径);
            fw.write(内容);
            fw.close();
        } catch (IOException e) {}
    }


    private void 写入手机高宽(Context context, String 宽路径, String 高路径) {
        WindowManager windowManager = (WindowManager) getSystemService(MainActivity.WINDOW_SERVICE);
        assert windowManager != null;
        Display display = windowManager.getDefaultDisplay();
        Point outPoint = new Point();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            display.getRealSize(outPoint);
        }
        int 实际高, 实际宽;
        实际宽 = outPoint.x;
        实际高 = outPoint.y;
        //获取屏幕高度宽度
        String 宽 = String.valueOf(实际宽);
        String 高 = String.valueOf(实际高);
        //写入文件
        写入文件(宽路径, 宽);
        写入文件(高路径, 高);
    }




	private ViewClickFun viewClickFun=new ViewClickFun();
	private static TextView sendButton=null;
	private static EditText signEdit=null;
	final Handler hander=new Handler(){
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
				case 0:
					sendButton.setText("登录");
					String content=(String)msg.obj;
					String con= BaseUtil.decode(content, "UTF-8");


					if (EggUtil.isJson(con)) {
						JSONObject jsonO=JSON.parseObject(con);
						String isOk=jsonO.getString("登录验证");
						if (isOk.equals("成功")) {
							String key=jsonO.getString("识别码");
							String keyId=jsonO.getString("卡密ID");
							String end=jsonO.getString("到期时间");
							String type=jsonO.getString("卡密类型");
							String value=jsonO.getString("卡密价值");
							int runNum=Integer.parseInt(keyId);
							SimpleDateFormat formatter= new SimpleDateFormat("yyyyMMddHHmm");
							Date date = new Date(System.currentTimeMillis());
							String t=formatter.format(date);
							String isKey=String.valueOf(runNum + EasyConfig.NUM) + EasyConfig.TOKEN + signEdit.getText().toString() + keyId + t;
							if (EggUtil.getMD5(isKey).equals(key)) {
								if (!jsonO.getString("绑定的设备码").equals(EggUtil.getImei(MainActivity.this))) {
									Toast.makeText(MainActivity.this, "请不要篡改设备码", Toast.LENGTH_SHORT).show();
									finish();
									return;
								}          
                                写入("/sdcard/Android/yyy", signEdit.getText().toString());
                                写入("/sdcard/Android/yyy1", EggUtil.getImei(MainActivity.this));


                                开启悬浮窗();
                                signEdit.setFocusable(false);//禁用编辑框
                                try {
                                    Runtime.getRuntime().exec("chmod -R 777 " + getFilesDir().toString());
                                } catch (IOException e) {}
                                WindowManager windowManager = (WindowManager) getApplication().getSystemService(MainActivity.WINDOW_SERVICE);
                                Display display = windowManager.getDefaultDisplay();
                                Point outPoint = new Point();
                                ExecuteElf("su");
								Toast.makeText(MainActivity.this, "登录成功\n到期时间:" + end + "\n卡密类型:" + type + "，时长:" + value, Toast.LENGTH_SHORT).show();
								if (悬浮窗是否激活) {
									Toast.makeText(MainActivity.this, "请勿重复登录", Toast.LENGTH_SHORT).show();
								}


								//登录成功

							} else {
								Toast.makeText(MainActivity.this, "登录失败，数据异常", Toast.LENGTH_SHORT).show();
							}
						} else {
							Toast.makeText(MainActivity.this, "验证失败", Toast.LENGTH_SHORT).show();
						}

					} else {
						Toast.makeText(MainActivity.this, con, Toast.LENGTH_SHORT).show();
					}

					break;
				default:
			}
		}
	};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS,
							 WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        setContentView(R.layout.main);
		检查悬浮窗权限();
		获取分辨率();

		inflater = inflater.from(this);
		登录 = (TextView)findViewById(R.id.登录);
		登录.setOnClickListener(this);
		虚拟机 = (TextView)findViewById(R.id.虚拟机);
		虚拟机.setOnClickListener(this);
		ROOT = (TextView)findViewById(R.id.ROOT);
		ROOT.setOnClickListener(this);
		框架 = (TextView)findViewById(R.id.框架);
		框架.setOnClickListener(this);
		当前模式 = (TextView)findViewById(R.id.运行模式);
		//网盘 = (TextView)findViewById(R.id.网盘);
		//网盘.setOnClickListener(this);
		signEdit = (EditText)findViewById(R.id.sign_edit);
		initClick();
        String 密码=读取("/sdcard/Android/yyy");

        gx("http://damahou.vip/ycgx.txt", "2.1.0");
        notice("http://damahou.vip/gg.txt");
        开关("http://damahou.vip/kg.txt");
        signEdit.setText(密码);
    }
    private void notice(final String url) {
        new Thread(new Runnable() {
                @Override
                public void run() {
                    Response res = Http.sendPost(url, "", "", "");
                    if (res != null) {
                        try {
                            final String data = res.body().string();
                            String msg = data.substring(data.indexOf("<p>") + 3, data.indexOf("</p>"));
                            //int appversion = MainActivity.this.getPackageManager().getPackageInfo(MainActivity.this.getPackageName(), 0).versionCode;
                            JSONObject jsonObject = JSON.parseObject(msg);
                            String 是否开启公告 = jsonObject.getString("是否开启公告");//解析是否开启公告
                            //String _versionname = jsonObject.getString("versionname");
                            final String message = jsonObject.getString("message");//解析公告内容
                            //final String apkUrl = jsonObject.getString("apkurl");
                            //Log.i("Mobai" , "1");
                            if (是否开启公告.equals("否")) {
                                //Log.i("Mobai", "不更新");
                                return;
                            }
                            runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        //Log.i("Mobai", "更新");
                                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                        builder.setTitle("通知");
                                        builder.setMessage(message);
                                        builder.setCancelable(false);
                                        builder.setNegativeButton("确定", new DialogInterface.OnClickListener() {

                                                @Override
                                                public void onClick(DialogInterface p1, int p2) {
                                                    return;
                                                }
                                            });
                                        builder.show();
                                    }
                                });
                        } catch (Exception e) {
                            //Log.i("Mobai", e.getMessage());
                        }
                    } else {
                        System.exit(0);//正常退出App
                    }
                }
            }).start();
    }


	public void 检查悬浮窗权限() {
		if (!Settings.canDrawOverlays(this)) {
			Toast.makeText(this, "请开启悬浮窗权限", Toast.LENGTH_LONG).show();
			startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())), 0);
		}
	}


    public static String 读取(String strFilePath) {
        String path = strFilePath;
        String content = ""; //文件内容字符串
        //打开文件
        File file = new File(path);
        //如果path是传递过来的参数，可以做一个非目录的判断
        if (file.isDirectory()) {
        } else {
            try {
                InputStream instream = new FileInputStream(file); 
                if (instream != null) {
                    InputStreamReader inputreader = new InputStreamReader(instream);
                    BufferedReader buffreader = new BufferedReader(inputreader);
                    String line;
                    //分行读取
                    while ((line = buffreader.readLine()) != null) {
                        content += line ;
                    }                
                    instream.close();
                }
            } catch (java.io.FileNotFoundException e) {
            } catch (IOException e) {
            }
        }
        return content;
    }


	public void 获取分辨率() {
		WindowManager windowManager = (WindowManager)this.getSystemService(WINDOW_SERVICE);
		Display display = windowManager.getDefaultDisplay();
		Point outPoint = new Point();
		mwindow = (WindowManager)getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
		lparam = new WindowManager.LayoutParams();
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            lparam.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            lparam.type = WindowManager.LayoutParams.TYPE_PHONE;
        }

		display.getRealSize(outPoint);
		屏幕宽 = outPoint.x;
		屏幕高 = outPoint.y;
		int 屏宽= getResources().getDisplayMetrics().widthPixels;
		int 屏高= getResources().getDisplayMetrics().heightPixels;
		
		写入("/sdcard/x",""+屏宽);
		写入("/sdcard/y",""+屏高);
		
		写入文件("/sdcard/b.log", "");
		写出资源文件(getFilesDir() + "/assets", "a");
		写出资源文件(getFilesDir() + "/assets", "a");
	}

	@Override
	public void onClick(View p1) {
		switch (p1.getId()) {
			case R.id.虚拟机:
				{
					模式 = "虚拟机";
					当前模式.setText("当前运行方式：虚拟机");
				}
				break;
			case R.id.ROOT:
				{
					模式 = "ROOT";
					当前模式.setText("当前运行方式：ROOT");
				}
				break;
			case R.id.框架:
				{
					模式 = "框架";
					当前模式.setText("当前运行方式：框架");
				}
				break;


		}
	}


	private void 开启悬浮窗() {
		mwindow = (WindowManager)getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
		lparam = new WindowManager.LayoutParams();
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            lparam.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            lparam.type = WindowManager.LayoutParams.TYPE_PHONE;
        }
		if (Settings.canDrawOverlays(this)) {
			mbutton = new ImageButton(getApplicationContext());
			mbutton.setBackgroundResource(R.drawable.ic_launcher);///悬浮球的图片
			mbutton.setOnTouchListener(new OnTouchListener() 
				{
					@Override
					public boolean onTouch(View v, MotionEvent event) {
						switch (event.getAction()) {
							case MotionEvent.ACTION_DOWN:
								isMove = false;
								mTouchStartX = (int) event.getRawX();
								mTouchStartY = (int) event.getRawY();
								break;
							case MotionEvent.ACTION_MOVE:
								int nowX = (int) event.getRawX();
								int nowY = (int) event.getRawY();
								int movedX = nowX - mTouchStartX;
								int movedY = nowY - mTouchStartY;
								if (movedX > 5 || movedY > 5) {
									isMove = true;
								}
								mTouchStartX = nowX;
								mTouchStartY = nowY;
								lparam.x += movedX;
								lparam.y += movedY;
								mwindow.updateViewLayout(mbutton, lparam);
								break;
							case MotionEvent.ACTION_UP:
								break;
							case MotionEvent.ACTION_CANCEL:
								break;
						}
					    return isMove;
					}
				});
			mbutton.setOnClickListener(new OnClickListener()//悬浮球的单击事件
				{
					@Override
					public void onClick(View v) {
						加载窗口();//加载悬浮窗
						悬浮窗 = true;
						mwindow.removeView(mbutton);//关闭悬浮球
						悬浮球 = false;
					}
				});
			lparam.format = PixelFormat.RGBA_8888;
			lparam.gravity = Gravity.LEFT;
			lparam.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
			lparam.width = 120;
			//宽度
			lparam.height = 120;
			//高度
			if (mparam == null) {
				lparam.x = 300;//悬浮球起始x
				lparam.y = 0;//悬浮球起始y
			} else {
				lparam.x = mparam.x;
				lparam.y = mparam.y;//y
			}
			mwindow.addView(mbutton, lparam);//加载悬浮球
			悬浮球 = true;
			悬浮窗是否激活 = true;
		} else {
			Toast.makeText(this, "开启失败", Toast.LENGTH_LONG).show();
			悬浮窗是否激活 = false;
		}
	}

	//只能写入字符串
	private void SaveText(String path, String txt) {
		try {
			FileOutputStream fos = new FileOutputStream(path);
			fos.write(txt.getBytes());
			fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	private void 加载窗口() {
		mwMenu = (WindowManager)getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
		mparam = new WindowManager.LayoutParams();
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mparam.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            mparam.type = WindowManager.LayoutParams.TYPE_PHONE;
        }
		displayMenu = inflater.inflate(R.layout.xfc, null);
		dis = displayMenu.findViewById(R.id.menu);
		mparam.format = PixelFormat.RGBA_8888;
		mparam.gravity = Gravity.LEFT;
		mparam.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
		mparam.width = WindowManager.LayoutParams.WRAP_CONTENT;
		//宽度
		mparam.height = WindowManager.LayoutParams.WRAP_CONTENT;
		//高度
		mparam.x = lparam.x;//x
		mparam.y = lparam.y;//y
		mwMenu.addView(dis, mparam);

		//悬浮窗长按监听
		RelativeLayout ll1=displayMenu.findViewById(R.id.menu);
		ll1.setOnTouchListener(new OnTouchListener() 
			{
			    @Override
				public boolean onTouch(View v, MotionEvent event) {
				    switch (event.getAction()) {
					    case MotionEvent.ACTION_DOWN://单击
						    移动 = false;
						    按下X = (int) event.getRawX();
						    按下Y = (int) event.getRawY();
						    break;
						case MotionEvent.ACTION_MOVE://拖动
						    int nowX = (int) event.getRawX();
							int nowY = (int) event.getRawY();
							int movedX = nowX - 按下X;
							int movedY = nowY - 按下Y;
							if (movedX > 5 || movedY > 5) {
							    移动 = true;
				            }
					        按下X = nowX;
					        按下Y = nowY;
					        lparam.x += movedX;
					        lparam.y += movedY;
					        mwindow.updateViewLayout(displayMenu, mparam);
					        break;
					    case MotionEvent.ACTION_UP://抬起
						    break;
						case MotionEvent.ACTION_CANCEL:
						    break;
					}
					return 移动;
				}
			});
		TextView Im1=displayMenu.findViewById(R.id.close);



		mSeekBar = displayMenu.findViewById(R.id.tdt);

		mSeekBar.setProgress(py);


//调整方框
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					Log.e("xyh", "onProgressChanged: " + progress + "");

					py = progress;//赋值给偏移
					Storagevariable.setF(py);

				}
				@Override
				public void onStartTrackingTouch(SeekBar seekBar) {
				}

				@Override
				public void onStopTrackingTouch(SeekBar seekBar) {

				}
			});


		//缩小悬浮窗
		Im1.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v) {
					开启悬浮窗();//显示主悬浮窗

					mwMenu.removeView(dis);//移除菜单
					悬浮窗 = false;//菜单状态
				}
			});
		///寻找布局里的控件
		注入数据 = (Switch)displayMenu.findViewById(R.id.注入数据);	
		人物血量 = (Switch)displayMenu.findViewById(R.id.人物血量);
		人物名字 = (Switch)displayMenu.findViewById(R.id.人物名字);
		人物编队 = (Switch)displayMenu.findViewById(R.id.人物编队);
		人物方框 = (Switch)displayMenu.findViewById(R.id.人物方框);
		人物距离 = (Switch)displayMenu.findViewById(R.id.人物距离);
		人物人数 = (Switch)displayMenu.findViewById(R.id.人物人数);
		敌人射线 = (Switch)displayMenu.findViewById(R.id.人物射线);


		k1 = (Switch)displayMenu.findViewById(R.id.k1);	
		k2 = (Switch)displayMenu.findViewById(R.id.k2);
		k3 = (Switch)displayMenu.findViewById(R.id.k3);
		k4 = (Switch)displayMenu.findViewById(R.id.k4);
		k5 = (Switch)displayMenu.findViewById(R.id.k5);
		k6 = (Switch)displayMenu.findViewById(R.id.k6);
		k7 = (Switch)displayMenu.findViewById(R.id.k7);
		k8 = (Switch)displayMenu.findViewById(R.id.k8);
		k9 = (Switch)displayMenu.findViewById(R.id.k9);


		刷新按钮状态();//调用设置按钮状态
		注入数据.setOnCheckedChangeListener(new jg());
		人物血量.setOnCheckedChangeListener(new jg());
		人物名字.setOnCheckedChangeListener(new jg());
		人物编队.setOnCheckedChangeListener(new jg());
	    人物方框.setOnCheckedChangeListener(new jg());
		人物距离.setOnCheckedChangeListener(new jg());
		人物人数.setOnCheckedChangeListener(new jg());
		敌人射线.setOnCheckedChangeListener(new jg());

		k1.setOnCheckedChangeListener(new jg());
		k2.setOnCheckedChangeListener(new jg());
		k3.setOnCheckedChangeListener(new jg());
		k4.setOnCheckedChangeListener(new jg());
	    k5.setOnCheckedChangeListener(new jg());
		k6.setOnCheckedChangeListener(new jg());
		k7.setOnCheckedChangeListener(new jg());
		k8.setOnCheckedChangeListener(new jg());
		k9.setOnCheckedChangeListener(new jg());

		mSeekBar = displayMenu.findViewById(R.id.tdt);

	}

	private void 刷新按钮状态() {
		注入数据.setChecked(状态1);
		人物血量.setChecked(zt1);
		人物名字.setChecked(zt2);
		人物编队.setChecked(zt3);
		人物方框.setChecked(zt4);
		人物距离.setChecked(zt5);
		人物人数.setChecked(zt6);
		敌人射线.setChecked(zt7);

		k1.setChecked(zt8);
		k2.setChecked(zt9);
		k3.setChecked(zt10);
		k4.setChecked(zt11);
		k5.setChecked(zt12);
		k6.setChecked(zt13);
		k7.setChecked(zt14);
		k8.setChecked(zt15);
		k9.setChecked(zt16);

	}






	class jg implements OnCheckedChangeListener {

		@Override
		public void onCheckedChanged(CompoundButton p1, boolean p2) {
			switch (p1.getId()) {
				case R.id.注入数据:
					{
						if (p2) {
							if (模式.equals("虚拟机")) {			 
								MainActivity.RunShell(("chmod 755 " + getFilesDir() + "/assets/a"));
								MainActivity.RunShell("su -c " + getFilesDir() + "/assets/a");
								Data.setA(1);
								FloatService.ShowFloat(MainActivity.this);
								Toast.makeText(MainActivity.this, "注入数据", Toast.LENGTH_LONG).show();
								状态1 = true;
							} else if (模式.equals("ROOT")) {
								MainActivity.RunShell(("chmod 777 " + getFilesDir() + "/assets/a"));
								MainActivity.RunShell("su -c " + getFilesDir() + "/assets/a");

								Data.setA(1);
								FloatService.ShowFloat(MainActivity.this);
								Toast.makeText(MainActivity.this, "注入数据", Toast.LENGTH_LONG).show();
								状态1 = true;
							} else if (模式.equals("框架")) {
								MainActivity.RunShell(("chmod 777 " + getFilesDir() + "/assets/a"));
								Data.setA(1);
								FloatService.ShowFloat(MainActivity.this);
								Toast.makeText(MainActivity.this, "注入数据", Toast.LENGTH_LONG).show();
								状态1 = true;
							}

						} else {
							FloatService.HideFloat();
							状态1 = false;
							Toast.makeText(MainActivity.this, "绘制关闭", Toast.LENGTH_LONG).show();
						}
					}
					break;

				case R.id.人物血量:
					{
						if (p2) {
                            	Toast.makeText(MainActivity.this, "开启显示血量", Toast.LENGTH_LONG).show();
							zt1 = true;
						} else {
                            	Toast.makeText(MainActivity.this, "关闭血量显示关", Toast.LENGTH_LONG).show();
							zt1 = false;
						}
					}
					break;
				case R.id.人物名字:
					{
						if (p2) {
                            	Toast.makeText(MainActivity.this, "开启名字显示", Toast.LENGTH_LONG).show();
							zt2 = true;
						} else {
                            	Toast.makeText(MainActivity.this, "关闭名字显示", Toast.LENGTH_LONG).show();
							zt2 = false;
						}

					}
					break;
				case R.id.人物编队:
					{
						if (p2) {
                            	Toast.makeText(MainActivity.this, "开启团队显示", Toast.LENGTH_LONG).show();
							zt3 = true;
						} else {
                            			Toast.makeText(MainActivity.this, "关闭团队显示", Toast.LENGTH_LONG).show();
							zt3 = false;
						}

					}
					break;

				case R.id.人物方框:
					{
						if (p2) {
                            Toast.makeText(MainActivity.this, "开启方框显示", Toast.LENGTH_LONG).show();
							zt4 = true;
						} else {
                            		Toast.makeText(MainActivity.this, "关闭方框显示", Toast.LENGTH_LONG).show();
							zt4 = false;
						}
					}
					break;
				case R.id.人物距离:
					{
						if (p2) {
                            	Toast.makeText(MainActivity.this, "开启距离显示", Toast.LENGTH_LONG).show();
							zt5 = true;
						} else {
                            		Toast.makeText(MainActivity.this, "关闭距离显示", Toast.LENGTH_LONG).show();
							zt5 = false;
						}

					}
					break;
				case R.id.人物人数:
					{
						if (p2) {
                            		Toast.makeText(MainActivity.this, "开启人数显示", Toast.LENGTH_LONG).show();
							zt6 = true;
						} else {
                            	Toast.makeText(MainActivity.this, "关闭人数显示", Toast.LENGTH_LONG).show();
							zt6 = false;
						}

					}
					break;
				case R.id.人物射线:
					{
						if (p2) {
                            	Toast.makeText(MainActivity.this, "开启射线显示", Toast.LENGTH_LONG).show();
							zt7 = true;
						} else {
                            Toast.makeText(MainActivity.this, "关闭射线显示", Toast.LENGTH_LONG).show();
							zt7 = false;
						}

					}
					break;
				case R.id.k1:
					{
						if (p2) {
							Toast.makeText(MainActivity.this, "开启车辆显示", Toast.LENGTH_LONG).show();
							zt8 = true;
						} else {
							Toast.makeText(MainActivity.this, "关闭车辆显示", Toast.LENGTH_LONG).show();
							zt8 = false;
						}
					}
					break;
				case R.id.k2:
					{
						if (p2) {
							Toast.makeText(MainActivity.this, "开启枪类显示", Toast.LENGTH_LONG).show();
							zt9 = true;
						} else {
							Toast.makeText(MainActivity.this, "关闭枪类显示", Toast.LENGTH_LONG).show();
							zt9 = false;
						}

					}
					break;
				case R.id.k3:
					{
						if (p2) {
                            Toast.makeText(MainActivity.this, "开启子弹显示", Toast.LENGTH_LONG).show();
							zt10 = true;
						} else {
							Toast.makeText(MainActivity.this, "关闭子弹显示", Toast.LENGTH_LONG).show();
							zt10 = false;
						}

					}
					break;

				case R.id.k4:
					{
						if (p2) {
                            Toast.makeText(MainActivity.this, "开启倍镜显示", Toast.LENGTH_LONG).show();
							zt11 = true;
						} else {
							Toast.makeText(MainActivity.this, "关闭倍镜显示", Toast.LENGTH_LONG).show();
							zt11 = false;
						}
					}
					break;
				case R.id.k5:
					{
						if (p2) {
                            Toast.makeText(MainActivity.this, "开启背包显示", Toast.LENGTH_LONG).show();
							zt12 = true;
						} else {
                            	Toast.makeText(MainActivity.this, "关闭背包显示", Toast.LENGTH_LONG).show();
							zt12 = false;
						}

					}
					break;
				case R.id.k6:
					{
						if (p2) {
							Toast.makeText(MainActivity.this, "开启空投显示", Toast.LENGTH_LONG).show();
							zt13 = true;
						} else {
                            	Toast.makeText(MainActivity.this, "关闭空投显示", Toast.LENGTH_LONG).show();
							zt13 = false;
						}

					}
					break;
				case R.id.k7:
					{
						if (p2) {
							Toast.makeText(MainActivity.this, "开启护甲显示", Toast.LENGTH_LONG).show();
							zt14 = true;
						} else {
                            	Toast.makeText(MainActivity.this, "关闭护甲显示", Toast.LENGTH_LONG).show();
							zt14 = false;
						}

					}
					break;

				case R.id.k8:
					{
						if (p2) {
							Toast.makeText(MainActivity.this, "开启背包显示", Toast.LENGTH_LONG).show();
							zt15 = true;
						} else {
                            	Toast.makeText(MainActivity.this, "关闭背包显示", Toast.LENGTH_LONG).show();
							zt15 = false;
						}

					}
					break;
				case R.id.k9:
					{
						if (p2) {
							Toast.makeText(MainActivity.this, "开启药品显示", Toast.LENGTH_LONG).show();
							zt16 = true;
						} else {
							Toast.makeText(MainActivity.this, "关闭药品显示", Toast.LENGTH_LONG).show();
							zt16 = false;
						}

					}
					break;
			}
		}
	}

	public static boolean 返回(int count) {
		switch (count) {
			case 1:
				return zt1;///方框1
			case 2:
				return zt2;//射线2
			case 3:
				return zt3;//敌人数据
			case 4:
				return zt4;///方框1
			case 5:
				return zt5;//射线2
			case 6:
				return zt6;//敌人数据
			case 7:
				return zt7;//敌人数据
			case 8:
				return zt8;//车辆
			case 9:
				return zt9;//枪类
			case 10:
				return zt10;//子弹
			case 11:
				return zt11;///倍镜
			case 12:
				return zt12;//背包
			case 13:
				return zt13;//空投
			case 14:
				return zt14;//护甲
			case 15:
				return zt15;//配件
			case 16:
				return zt16;//药品
			default:
			    return false;
		}
	}
	
	
	

	private void ExecuteElf(String shell) {
		String s=shell;

		try {
			Runtime.getRuntime().exec(s, null, null);//执行
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public static boolean 写出assets资源文件(Context context, String outPath, String fileName) {
        File file = new File(outPath);
        if (!file.exists()) {
            if (!file.mkdirs()) {
                Log.e("--Method--", "copyAssetsSingleFile: cannot create directory.");
                return false;
            }
        }
        try {
            InputStream inputStream = context.getAssets().open(fileName);
            File outFile = new File(file, fileName);
            FileOutputStream fileOutputStream = new FileOutputStream(outFile);
            // Transfer bytes from inputStream to fileOutputStream
            byte[] buffer = new byte[1024];
            int byteRead;
            while (-1 != (byteRead = inputStream.read(buffer))) {
                fileOutputStream.write(buffer, 0, byteRead);
            }
            inputStream.close();
            fileOutputStream.flush();
            fileOutputStream.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }




	private boolean 写出资源文件(String outPath, String fileName) {
		File file = new File(outPath);
		if (!file.exists()) {
			if (!file.mkdirs()) {
				Log.e("--Method--", "copyAssetsSingleFile: cannot create directory.");
				return false;
			}
		}
		try {
			InputStream inputStream = getAssets().open(fileName);
			File outFile = new File(file, fileName);
			FileOutputStream fileOutputStream = new FileOutputStream(outFile);
			// Transfer bytes from inputStream to fileOutputStream
			byte[] buffer = new byte[1024];
			int byteRead;
			while (-1 != (byteRead = inputStream.read(buffer))) {
				fileOutputStream.write(buffer, 0, byteRead);
			}
			inputStream.close();
			fileOutputStream.flush();
			fileOutputStream.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}


	private void initClick() {
		MainActivity.sendButton = findViewById(R.id.登录);//登录按钮
		MainActivity.sendButton.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1) {
					// TODO: Implement this method
					MainActivity.sendButton.setText("正在登录...");
					开启悬浮窗();
					viewClickFun.sendButtonClick();
				}

			});
	}

	private class ViewClickFun {
		public void sendButtonClick() {

			if (signEdit.getText().toString().equals("")) {

				Toast.makeText(MainActivity.this, "卡密不能为空", Toast.LENGTH_SHORT).show();
				sendButton.setText("登录");
				return;
			}
			String keySign=EggUtil.str2HexStr(BaseUtil.encode(signEdit.getText().toString(), "UTF-8"));
			String userImei=EggUtil.str2HexStr(BaseUtil.encode(EggUtil.getImei(MainActivity.this), "UTF-8"));
			String printType=EggUtil.str2HexStr(BaseUtil.encode("json", "UTF-8"));

			final String url=EasyConfig.HOST + "user/kmdenglu.php?appid=" + EasyConfig.APPID + "&km=" + keySign + "&imei=" + userImei + "&print=" + printType;
			// TODO: Implement this method
			Thread thread=new Thread(new Runnable(){		
					@Override
					public void run() {
						// TODO: Implement this method
						try {
							Message msg=new Message();
							OkHttpClient okHttp = new OkHttpClient.Builder()
								.connectTimeout(15L, TimeUnit.SECONDS)
								.readTimeout(15L, TimeUnit.SECONDS)
								.writeTimeout(15L, TimeUnit.SECONDS)
								.build();
							Request req=new Request.Builder()
								.url(url)
								.build();

							Response response=okHttp.newCall(req).execute();
							msg.what = 0;

							if (response.isSuccessful()) {
								msg.obj = response.body().string();

							} else {
								msg.obj = new String("网络错误");
							}

							hander.sendMessage(msg);

						} catch (MalformedURLException e) {
							e.printStackTrace();
						} catch (IOException e) { 	e.printStackTrace(); }
					}
				});
			thread.start();
		}
	}

}
