
package com.tencent.QQmusic;

import android.annotation.SuppressLint;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;

public class AnimationF
{
	View view;
	int[] ids;
	
	public AnimationF(View view, int[] R_ids)
	{
		this.view = view;
		ids = R_ids;
		
		initSetting(false);
	}
	
	public void initSetting(boolean on)
	{
		SettingAniOn = on;
		for (int i = 1; i < ids.length; i++)
			view.findViewById(ids[i]).setVisibility(on ? View.VISIBLE : View.INVISIBLE);
	}
	
	boolean SettingAniOn = true;
	

	public void Setting(View view)
	{
		settingAni(!SettingAniOn);
	}
	

	private void settingAni(boolean on)
	{
		SettingAniOn = on;
		final int ANITIME = 300;
	
		View setting = view.findViewById(ids[0]);
		rotateAni(setting, on, ANITIME);
		
		for (int i = 1; i < ids.length; i++)
		{
			View V = view.findViewById(ids[i]);
			transAni(V, i + 1, on, ANITIME);
		}
	}
	
	private void transAni(final View view, int id, final boolean on, final int ANITIME)
	{
		// final float Y = id * 40;
		final float X = id * 40;
		
		AnimationSet AniSet = new AnimationSet(true);
		
		// TranslateAnimation transAin = new TranslateAnimation(0, 0, on ? Y : 0, on ? 0 : Y);
		TranslateAnimation transAin = new TranslateAnimation(on ? -X : 0, on ? 0 : -X, 0, 0);
		transAin.setDuration(ANITIME);
		transAin.setAnimationListener(new AnimationListener()
		{
			@Override
			public void onAnimationStart(Animation arg0)
			{
				view.setClickable(false);
			}
			
			@Override
			public void onAnimationRepeat(Animation arg0)
			{}
			
			@Override
			public void onAnimationEnd(Animation arg0)
			{
				view.setClickable(true);
				view.setVisibility(on ? View.VISIBLE : View.INVISIBLE);
			}
		});
		
		AniSet.addAnimation(transAin);
		view.startAnimation(AniSet);
	}
	
	private void rotateAni(final View view, final boolean on, final int ANITIME)
	{
		AnimationSet AniSet = new AnimationSet(true);
		final float DEGREE = 180;
		
		RotateAnimation rotateAni = new RotateAnimation(0, on ? DEGREE : -DEGREE, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
		rotateAni.setDuration(ANITIME + 30);
		rotateAni.setAnimationListener(new AnimationListener()
		{
			@Override
			public void onAnimationStart(Animation arg0)
			{
				view.setClickable(false);
			}
			
			@Override
			public void onAnimationRepeat(Animation arg0)
			{}
			
			@SuppressLint("NewApi")
			@Override
			public void onAnimationEnd(Animation arg0)
			{
				view.setClickable(true);
				view.setRotation(on ? -DEGREE : 0);
			}
		});
		
		AniSet.addAnimation(rotateAni);
		view.startAnimation(AniSet);
	}
}
