package com.tencent.QQmusic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;

import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.os.Environment;


import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Properties;
import java.io.InputStream;
import java.io.InputStreamReader;
import android.widget.Toast;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import java.util.*;
import java.io.*;
import android.service.*;
import android.os.*;
import android.content.*;
import android.view.*;
import android.graphics.*;
import android.widget.AbsoluteLayout.*;
import android.provider.*;
import android.net.*;
import android.graphics.drawable.*;
import android.widget.CompoundButton.*;
import android.text.style.*;
//import com.aw.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import static android.graphics.Typeface.BOLD;

import com.tencent.QQmusic.MainActivity;
import android.icu.text.SimpleDateFormat;

public class mSurfaceView extends SurfaceView implements SurfaceHolder.Callback,Runnable {

    //用于标注线程是否继续
    private boolean Flag=true;
    //SurfaceHolder
    SurfaceHolder surfaceHolder;

    //定义画笔
	Paint paint = new Paint();
    Paint paint1 = new Paint();
    Paint paint2 = new Paint();
    Paint paint3 = new Paint();
    Paint paint4 = new Paint();
    Paint paint5 = new Paint();
    Paint paint6 = new Paint();
    Paint paint7 = new Paint();
    Paint paint8 = new Paint();
    Paint paint9 = new Paint();
    Paint paint10 = new Paint();
    Paint paint11 = new Paint();
    Paint paint12 = new Paint();
    Paint paint13 = new Paint();
    Paint paint14 = new Paint();
	Paint paint15 = new Paint();
	Paint paint16 = new Paint();
	Paint 距离字体 = new Paint();
	Paint 距离描边 = new Paint();
	Paint paintc = new Paint();
	



    Paint painttime = new Paint();
	Paint yellow_Stack = new Paint();
	Paint green_Stack = new Paint();
	Paint number = new Paint();
    Paint 人机方框 = new Paint();

    Paint paint21 = new Paint();

	
	Canvas canvas=null;
	float x=0;
	float y=0;
	float w=0;
	float h=0;
	float m=0;
	int wz ;
	
	int M ;
	float rs;
	float ai;
	float hp;
	int bh;
	float x1 = 0;//左右偏移
	String name="";
    float ggtzy = 0;
    float ggtgd = 0;
    float ggsbzy = 0;
    float ggsbsx = 0;
    float ggpgzy = 0;
    float ggpgsx = 0;
    float ggzjzy = 0;
    float ggzjsx = 0;
    float ggyjzy = 0;
    float ggyjsx = 0;
    float ggzszzy = 0;
    float ggzszsx = 0;
    float ggysjzy = 0;
    float ggysjsx = 0;
    float ggzswzy = 0;
    float ggzswsx = 0;
    float ggyswzy = 0;
    float ggyswsx = 0;
    float ggzdtzy = 0;
    float ggzdtsx = 0;
    float ggydtzy = 0;
    float ggydtsx = 0;
    float ggzxgzy = 0;
    float ggzxgsx = 0;
    float ggyxgzy = 0;
    float ggyxgsx = 0;
    float ggzjwzy = 0;
    float ggzjwsx = 0;
    float ggyjwzy = 0;
    float ggyjwsx = 0;

	
	


    public mSurfaceView(Context context, AttributeSet attrs) {
        super(context, attrs);

        surfaceHolder = getHolder();
        surfaceHolder.addCallback(this);
        this.setZOrderOnTop(true);
        surfaceHolder.setFormat(PixelFormat.TRANSLUCENT);
    }

	public static String ReadTxtFile(String p0) {
		// TODO: Implement this method
		return null;
	}


	public void toast(String s) {
		Toast.makeText(getContext(), s, Toast.LENGTH_LONG).show();
	}




	public static String getFileContent(File file) {
        String content = "";
        if (!file.isDirectory()) {
            try {
                InputStream instream = new FileInputStream(file);
                if (instream != null) {
                    InputStreamReader inputreader
						= new InputStreamReader(instream, "UTF-8");
                    BufferedReader buffreader = new BufferedReader(inputreader);
                    String line = "";
                    while ((line = buffreader.readLine()) != null) {
                        content += line;
                    }
                    instream.close();//关闭输入流
                }
            } catch (java.io.FileNotFoundException e) {
            } catch (IOException e) {
            }
        }
        return content;
    }

    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        //初始化画笔
        init();
        Flag = true;
        new Thread(this).start();
    }
    private void init() {

		//红点
        paint.setColor(Color.rgb(255, 0, 0));
        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeWidth(3.5f);
        //射线
        paint1.setColor(Color.rgb(255, 198, 0));
		paint1.setStyle(Paint.Style.FILL);
        paint1.setStrokeWidth(1.8f);
        //距离描边
        paint2.setColor(Color.rgb(0, 0, 0));
        paint2.setStrokeWidth(1);//描边大小
        paint2.setTextSize(20);//字体大小z
        paint2.setAlpha(1000);//透明性
        paint2.setStyle(Paint.Style.STROKE);//描边
        //距离
		距离字体.setColor(Color.rgb(255,255,255));
        距离字体.setTextSize(20);//字体大小

		距离描边.setColor(Color.rgb(0, 0, 0));
        距离描边.setStrokeWidth(10);//描边大小
        距离描边.setTextSize(20);//字体大小z
        距离描边.setAlpha(100);//透明性
        距离描边.setStyle(Paint.Style.STROKE);//描边
		//射线圆点
        paint4.setColor(Color.rgb(255, 255, 255));
        paint4.setStyle(Paint.Style.FILL);
        paint4.setTextSize(10);
        //血条边框
        paint5.setColor(Color.rgb(255, 255, 255));
        paint5.setStyle(Paint.Style.STROKE);  //边框
        paint5.setStrokeWidth(2f);
        //血条实心
        paint6.setColor(0xFFFFC935);
        paint6.setStyle(Paint.Style.FILL);
        paint6.setAlpha(100);
        //方框实心
        paint7.setColor(Color.rgb(255, 255, 255));
        paint7.setStyle(Paint.Style.FILL);
        paint7.setAlpha(10);
        //方框边框
        paint8.setColor(Color.rgb(248, 248, 255));
        paint8.setStyle(Paint.Style.STROKE);
        paint8.setStrokeWidth(2f);
        //运行时间
        painttime.setColor(Color.rgb(255, 198, 0));//字体颜色
        //Typeface font = Typeface.create(Typeface.SANS_SERIF, BOLD);//加载字体
        //painttime.setTypeface(font);//设置字体
        painttime.setStrokeWidth(7);
        painttime.setTextSize(20);//字体大0小
        //背敌距离
        paint9.setColor(Color.rgb(255, 255, 255));
        paint9.setStyle(Paint.Style.FILL);
        paint9.setTextSize(20);
        paint9.setAlpha(200);
        //背敌
        paint10.setColor(Color.rgb(255, 198, 0));
        paint10.setStyle(Paint.Style.FILL);
        paint10.setTextSize(15);
        paint10.setAlpha(90);
        //队编背景
        paint11.setColor(Color.rgb(0, 0, 0));
        paint11.setStyle(Paint.Style.FILL);
        paint11.setAlpha(160);
        //队编
        paint12.setColor(Color.rgb(248, 248, 255));//字体颜色
        Typeface font = Typeface.create(Typeface.SANS_SERIF, BOLD);//加载字体
        paint12.setTypeface(font);//设置字体
        paint12.setStrokeWidth(7);
        paint12.setTextSize(20);//字体大0小

        paint13.setColor(Color.rgb(112, 128, 144));
        paint13.setStyle(Paint.Style.FILL);
        paint13.setAlpha(160);

        paint14.setColor(Color.rgb(255,165,0));//字体颜色
        paint14.setStrokeWidth(20);
        paint14.setTextSize(20);//字体大0小
        //骨骼颜色
		paint15.setColor(Color.rgb(255, 255, 255));
        paint15.setStyle(Paint.Style.STROKE);
        paint15.setStrokeWidth(2.5f);

		yellow_Stack.setColor(0xFFFFC700);
		yellow_Stack.setStyle(Paint.Style.FILL);
		yellow_Stack.setAlpha(28);

		green_Stack.setColor(0xFF00FF00);
		green_Stack.setStyle(Paint.Style.FILL);
		green_Stack.setAlpha(28);

		number.setColor(0xC7000000);
		number.setTypeface(font);
		number.setTextSize(20);

        paint21.setColor(Color.rgb(184, 255, 195));
        //paint21.setColor(Color.parseColor("#fbd14b"));
        paint21.setStrokeWidth(2);//描边大小
        paint21.setTextSize(18);//字体大小z
        paint21.setAlpha(200);//透明性
        paint21.setStyle(Paint.Style.STROKE);//描边

        人机方框.setColor(Color.rgb(60, 179, 113));
        人机方框.setStyle(Paint.Style.STROKE);
        人机方框.setStrokeWidth(1.5f);

		//人机显示
		paint3.setColor(Color.rgb(255,255,255));//字体颜色
        paint3.setStrokeWidth(28);
        paint3.setTextSize(18);//字体大0小

		paint16.setColor(Color.rgb(255,0,0));//字体颜色
        paint16.setStrokeWidth(28);
        paint16.setTextSize(18);//字体大0小

		paintc.setAntiAlias(true);
		paintc.setColor(0xFFFFFFFF);
		paintc.setStyle(Paint.Style.STROKE);
		paintc.setStrokeWidth(12);
		
		
    }
    

	int 屏宽= getResources().getDisplayMetrics().widthPixels;
	int 屏高= getResources().getDisplayMetrics().heightPixels;
	
	
	public String 获取车辆(int id) {
		
			
		String name="";
			
		if (id == 70) {
			name = "摩托车";
		}
		if (id == 71) {
			name = "小绵羊";
		}
		if (id == 72) {
			name = "三轮摩托车";
		}
		if (id == 72) {
			name = "三轮摩托";
		}
		if (id == 74) {
			name = "跑车";
		}
		if (id == 75) {
			name = "小轿车";
		}
		if (id == 76) {
			name = "皮卡车";
		}
		if (id == 73) {
			name = "蹦蹦车";
			
		}
		if (id == 78) {
			name = "吉普";
		}
		
		
	return name;
	}
	
	
	

	public String 获取背包(int id) {
		String name="";
		if (id == 7) {
			name = "一级包";
		}
		if (id == 8) {
			name = "二级包";
		}
		if (id == 9) {
			name = "三级包";
		}
		return name;
	}



	public String 获取护甲(int id) {
		String name="";
		if (id == 12) {
			name = "一级甲";
		}
		if (id == 2) {
			name = "一级头";
		}
		if (id == 3) {
			name = "二级甲";
		}
		if (id == 4) {
			name = "二级头";
		}
		if (id == 5) {
			name = "三级头";
		}
		if (id == 6) {
			name = "三级甲";
		}
		return name;
	}
	public String 获取空投(int id) {
		String name="";
		if (id == 10) {
			name = "空投箱";
		}
		if (id == 11) {
			name = "盒子";
		}
		return name;
	}

	public String 获取药品(int id) {
		String name="";
		if (id == 21) {
			name = "止痛药";
		}
		if (id == 22) {
			name = "肾上腺素";
		}
		if (id == 23) {
			name = "饮料";
		}
		if (id == 24) {
			name = "急救包";
		}
		
		if (id == 25) {
			name = "医疗箱";
		}
		return name;
	}

	public String 获取武器(int id) {
		String name="";
		if (id == 31) {
			name = "M416";
		}
		if (id == 32) {
			name = "M16A4";
		}
		if (id == 33) {
			name = "SCAR";
		}
		if (id == 34) {
			name = "QBZ";
		}
		if (id == 35) {
			name = "M762";
		}
		if (id == 36) {
			name = "MK47";
		}
		if (id == 37) {
			name = "Groza";
		}
		if (id == 511) {
			name = "AWM";
		}
		if (id == 39) {
			name = "Kar98k";
		}
		if (id == 40) {
			name = "M24";
		}
		if (id == 41) {
			name = "Mini14";
		}
		if (id == 42) {
			name = "SKS";
		}
		if (id == 43) {
			name = "QBU";
		}
		return name;
	}


	public String 获取子弹(int id) {
		String name="";
		if (id == 41) {
			name = "5.56";
		}
		if (id == 47) {
			name = "7.62";
		}

		return name;
	}

	public String 获取倍镜(int id) {
		String name="";
		if (id == 54) {
			name = "4倍镜";
		}
		if (id == 55) {
			name = "6倍镜";
		}
		if (id == 56) {
			name = "8倍镜";
		}
		return name;
	}


	public String 获取配件(int id) {
		String name="";
		if (id == 48) {
			name = "步枪快速扩容";
		}
		if (id == 49) {
			name = "步枪扩容";
		}
		if (id == 50) {
			name = "狙击快速扩容";
		}
		if (id == 51) {
			name = "狙击扩容";
		}
		if (id == 52) {
			name = "步枪消音";
		}
		if (id == 53) {
			name = "狙击消音";
		}
		return name;
	}


    @Override
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        Flag = false;
    }


    int offset;
    int Height=MainActivity.屏幕高,Width=MainActivity.屏幕宽;

	private void pubg() {

		
		File file = new File("/sdcard/b.log");
		if (file == null)
			return;
        //循环打印运行时间
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss");
        Date date = new Date(System.currentTimeMillis());
        canvas.drawText(String.valueOf(simpleDateFormat.format(date)), (MainActivity.屏幕宽 / 2 / 2 + 500), 40, painttime);//运行时间

        canvas.drawText("", (MainActivity.屏幕宽 / 2 / 2 ), 40, painttime);

		String fileContent = getFileContent(file);
		if (fileContent != null) {
		    String[] concent = fileContent.split(";");
		    for (int i = 0; i < concent.length; i++) {
				x1 = Storagevariable.getF() ;//获取左右偏移  		
				String[] zb = concent[i].split(",");
				try {
                    x = Float.parseFloat(zb[0]);//x
                    y = Float.parseFloat(zb[1]);//y
                    h = Float.parseFloat(zb[2]);//高
                    hp = Float.parseFloat(zb[3]);//血量
                    M = Integer.parseInt(zb[4]);//距离
                    ai = Float.parseFloat(zb[5]);//人机
                    rs = Integer.parseInt(zb[6]);
                    bh = Integer.parseInt(zb[7]);//队编
                    name = (zb[8]);//名字 
                    ggtzy = Float.parseFloat(zb[9]);//骨骼头左右
                    ggtgd = Float.parseFloat(zb[10]);//骨骼头高度 
                    ggsbzy = Float.parseFloat(zb[11]);//骨骼胸部左右
                    ggsbsx = Float.parseFloat(zb[12]);//骨骼胸部上下
                    ggpgzy = Float.parseFloat(zb[13]);//骨骼盆骨左右
                    ggpgsx = Float.parseFloat(zb[14]);//骨骼盆骨上下
                    ggzjzy = Float.parseFloat(zb[15]);//骨骼左肩左右
                    ggzjsx = Float.parseFloat(zb[16]);//骨骼左肩上下
                    ggyjzy = Float.parseFloat(zb[17]);//骨骼右肩左右
                    ggyjsx = Float.parseFloat(zb[18]);//骨骼右肩上下
                    ggzszzy = Float.parseFloat(zb[19]);//骨骼左手肘左右
                    ggzszsx = Float.parseFloat(zb[20]);//骨骼左手肘上下
                    ggysjzy = Float.parseFloat(zb[21]);//骨骼右手肘左右
                    ggysjsx = Float.parseFloat(zb[22]);//骨骼右手肘上下
                    ggzswzy = Float.parseFloat(zb[23]);//骨骼左手腕左右
                    ggzswsx = Float.parseFloat(zb[24]);//骨骼左手腕上下
                    ggyswzy = Float.parseFloat(zb[25]);//骨骼右手腕左右
                    ggyswsx = Float.parseFloat(zb[26]);//骨骼右手腕上下
                    ggzdtzy = Float.parseFloat(zb[27]);//骨骼左大腿左右
                    ggzdtsx = Float.parseFloat(zb[28]);//骨骼左大腿上下
                    ggydtzy = Float.parseFloat(zb[29]);//骨骼右大腿左右
                    ggydtsx = Float.parseFloat(zb[30]);//骨骼右大腿上下
                    ggzxgzy = Float.parseFloat(zb[31]);//骨骼左膝盖左右
                    ggzxgsx = Float.parseFloat(zb[32]);//骨骼左膝盖上下
                    ggyxgzy = Float.parseFloat(zb[33]);//骨骼右膝盖左右
                    ggyxgsx = Float.parseFloat(zb[34]);//骨骼右膝盖上下
                    ggzjwzy = Float.parseFloat(zb[35]);//骨骼左脚腕左右
                    ggzjwsx = Float.parseFloat(zb[36]);//骨骼左脚腕上下
                    ggyjwzy = Float.parseFloat(zb[37]);//骨骼右脚腕左右
                    ggyjwsx = Float.parseFloat(zb[38]);//骨骼右脚腕上下
                    w = h / 2;
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				int DW = (int) bh;
                if (MainActivity.返回(3)) {



//背敌预警
					if (M > 0 && hp > 0) {
						if (x < 0) {
							if (y <= 0) {
								canvas.drawCircle(0, 0, 80, paint10);
							} else if (y > Width) {
								canvas.drawCircle(0, Width, 80, paint10);
							} else {
								canvas.drawCircle(0, y, 80, paint10);
								canvas.drawText((int)M + "m", 0, y, paint9);
							}
						}

						if (x > Height) {
							if (y <= 0) {
								canvas.drawCircle(Height  - 80, 0, 80, paint10);
							} else if (y > Width) {
								canvas.drawCircle(Height  - 80, Width, 80, paint10);
							} else {
								canvas.drawCircle(Height  - 80, y, 80, paint10);
								canvas.drawText((int)M + "m", Height + 0 - 115, y, paint9);
							}
						}
					}
				}
                if (m < 800 && m >= 0  && hp > 0 && hp < 122 && x >= 0 && 0 <= h) {

					if (MainActivity.返回(1)) {
                        //血条
                        canvas.drawRect(ggtzy - 100 + x1, ggtgd - 45, ggtzy - 100 + x1 + ((((ggtzy + 100 + x1) - (ggtzy - 100 + x1)) / 100) * hp), ggtgd - 20, paint6);
						canvas.drawRect(ggtzy - 100 + x1, ggtgd - 45, ggtzy + 100 + x1, ggtgd - 20, paint5);
						
                        if (m < 200) {
                            if (ai != 0) {
                                canvas.drawText(name+ " "+DW+"号", ggtzy - 50 + x1, ggtgd - 24, paint16);

							}else{
								canvas.drawText("人机" +" "+ DW+"号", ggtzy - 50 + x1, ggtgd - 24, paint3);//canvas.drawText("人机", ggtzy +20 + x1 - 40, ggtgd - 49, paint14);//距离文本 
							}
							//距离
							canvas.drawText(M + "M", ggtzy - 35 + x1, ggyjwsx + 35, 距离字体);
							canvas.drawText(M + "M", ggtzy - 35 + x1, ggyjwsx + 35, 距离描边);//距离
						}
						
                            //距离
                            


					}


					if (MainActivity.返回(2)) {
                         //canvas.drawText(name + "", x - 80 + x1, y - w - 32, paintc);		
					}


					//方框
					if (MainActivity.返回(4)) {
						if (m < 180)
                            canvas.drawRect(ggpgzy - h / 4 + x1, ggtgd - 16, ggpgzy + h / 4 + x1, ggzjwsx + 12, paint8);
						

					}

					if (MainActivity.返回(5)) {
                        if (M < 400 && M > 1 && m > 0 && hp > 0 && x>0 && y>0 && h>0)
                           canvas.drawLine(ggtzy + x1, ggtgd, ggsbzy + x1, ggsbsx, paint15);
							canvas.drawLine(ggsbzy + x1, ggsbsx, ggpgzy + x1, ggpgsx, paint15);
							canvas.drawLine(ggsbzy + x1, ggsbsx, ggzjzy + x1, ggzjsx, paint15);
							canvas.drawLine(ggzjzy + x1, ggzjsx, ggzszzy + x1, ggzszsx, paint15);
							canvas.drawLine(ggzszzy + x1, ggzszsx, ggzswzy + x1, ggzswsx, paint15);
							canvas.drawLine(ggsbzy + x1, ggsbsx, ggyjzy + x1, ggyjsx, paint15);
							canvas.drawLine(ggyjzy + x1, ggyjsx, ggysjzy + x1, ggysjsx, paint15);
							canvas.drawLine(ggysjzy + x1, ggysjsx, ggyswzy + x1, ggyswsx, paint15);
							canvas.drawLine(ggpgzy + x1, ggpgsx, ggzdtzy + x1, ggzdtsx, paint15);
							canvas.drawLine(ggzdtzy + x1, ggzdtsx, ggzxgzy + x1, ggzxgsx, paint15);
							canvas.drawLine(ggzxgzy + x1, ggzxgsx, ggzjwzy + x1, ggzjwsx, paint15);
							canvas.drawLine(ggpgzy + x1, ggpgsx, ggydtzy + x1, ggydtsx, paint15);
							canvas.drawLine(ggydtzy + x1, ggydtsx, ggyxgzy + x1, ggyxgsx, paint15);
							canvas.drawLine(ggyxgzy + x1, ggyxgsx, ggyjwzy + x1, ggyjwsx, paint15);
						}}

					//射线
					if (MainActivity.返回(7)) {

                        canvas.drawLine(屏宽 / 2, 95, ggtzy + x1, ggtgd - 45, paint1);
						

					}
				}
                
                
                 if (w > 0 && h > 0)
                 {		
                 if (MainActivity.返回(8) && wz < 99 && wz > 70)
                 {
                 canvas.drawText(获取车辆(wz) + "(" + (int)M + "M)", x - 30 + x1, y , 距离字体);							
                 }
                 if (MainActivity.返回(9) && wz < 43 && wz > 31)
                 {
                 canvas.drawText(获取武器(wz) , x - 30 , y , 距离字体);					
                 }
                 if (MainActivity.返回(10) && wz < 47 && wz > 46)
                 {
					 canvas.drawText(获取子弹(wz) , x - 30 , y , 距离字体);					
                 }
                 if (MainActivity.返回(11) && wz < 3 && wz > 1)
                 {
					 canvas.drawText(获取背包(wz) , x - 30 , y , 距离字体);					
                 }
                 if (MainActivity.返回(12) && wz < 11 && wz > 10)
                 {
					 canvas.drawText(获取空投(wz) , x - 30 , y , 距离字体);					
                 }
                 if (MainActivity.返回(13) && wz < 4 && wz > 9)
                 {
					 canvas.drawText(获取护甲(wz) , x - 30 , y , 距离字体);					
                 }
                 if (MainActivity.返回(14) && wz < 53 && wz > 48)
                 {
					 canvas.drawText(获取配件(wz) , x - 30 , y , 距离字体);					
                 }
                 if (MainActivity.返回(15) && wz < 25 && wz > 21)
                 {
					 canvas.drawText(获取药品(wz) , x - 30 , y , 距离字体);					
                 }		

                 }	

			}		
			
			rs=rs+1;
		
		
			
			
			if (MainActivity.返回(6)) {

				if (rs > 0)
					{
						int cih=80;
					for (int i = 0; i <= 14; i++)
				{
					cih = cih - 3;
					canvas.drawRect(屏宽 / 2 - cih, 70, 屏宽 / 2 + cih, 97, yellow_Stack);
				}
				if (rs >= 10)
			{
			canvas.drawText(rs + "", 屏宽 / 2 - 15, 93, number);
		}
		else
	{
	canvas.drawText(rs + "", 屏宽 / 2 - 7, 93, number);
	}
	}
		else
			{
				int cih=80;
				for (int i = 0; i <= 14; i++)
			{
				cih = cih - 3;
			canvas.drawRect(屏宽 / 2 - cih, 70, 屏宽 / 2 + cih, 97, green_Stack);
			}
				canvas.drawText("安全", 屏宽 / 2 - 23, 93, number);
			}
		}
	

	
}
		

	@Override
	public void run() {        
        while (Flag) {
            try {
                canvas = surfaceHolder.lockCanvas();
                canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
            } catch (Exception e) {
                break;
            }
			if (Data.getA() == 1) {
				pubg();
			}
			surfaceHolder.unlockCanvasAndPost(canvas);
		}
    }
}
	
	

