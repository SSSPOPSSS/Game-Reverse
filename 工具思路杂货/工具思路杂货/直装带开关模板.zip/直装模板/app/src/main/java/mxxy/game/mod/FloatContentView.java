package mxxy.game.mod;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import mxxy.game.mod.Miscellaneous;
import java.io.IOException;

   
   
   
   
   
   
public class FloatContentView extends PopupWindow {

    private Context mContext;
	
	private boolean view;

    public FloatContentView(Context context) {
        super(context);
        this.mContext = context;
        initView();
    }

    private void initView() {

        LinearLayout main = new LinearLayout(mContext);
		LinearLayout.LayoutParams mainParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
		main.setLayoutParams(mainParams);

		GradientDrawable mainBackground = new GradientDrawable();
        mainBackground.setColor(0x3E30CBDE);
		mainBackground.setCornerRadius(30);
        mainBackground.setStroke(5, 0xFF007FFF);
		//设置背景
		main.setBackgroundDrawable(mainBackground);

		LinearLayout mainLayout = new LinearLayout(mContext);
		LinearLayout.LayoutParams mainLayoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
		mainLayout.setLayoutParams(mainLayoutParams);
		mainLayout.setOrientation(LinearLayout.VERTICAL);
		//设置图片背景
		//mainLayout.setBackgroundDrawable(drawable);
		main.addView(mainLayout);

		LinearLayout titleLayout = new LinearLayout(mContext);
		LinearLayout.LayoutParams titleLayoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
		titleLayout.setLayoutParams(titleLayoutParams);
		titleLayout.setGravity(Gravity.CENTER);
		titleLayout.setPadding(20, 20, 20, 20);
		mainLayout.addView(titleLayout);

		TextView title = new TextView(mContext);
		LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
		title.setLayoutParams(titleParams);
		title.setText("直装名");
		title.setTextSize(15);
        title.setTextColor(0xB9076F7E);
		title.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
		titleLayout.addView(title);

		ScrollView scroll = new ScrollView(mContext);
		ScrollView.LayoutParams scrollParams = new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT);
        scrollParams.bottomMargin = 10;
		scroll.setLayoutParams(scrollParams);
		mainLayout.addView(scroll);

		LinearLayout layout = new LinearLayout(mContext);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
		layout.setLayoutParams(layoutParams);
		layout.setOrientation(LinearLayout.VERTICAL);
		layout.setPadding(5, 5, 5, 5);
		scroll.addView(layout);

		GradientDrawable ButtonBackground = new GradientDrawable();
        ButtonBackground.setColor(0xFF4D4DFF);
		ButtonBackground.setCornerRadius(10);
        ButtonBackground.setStroke(5, 0xFF007FFF);

		LinearLayout layout1 = new LinearLayout(mContext);
		LinearLayout.LayoutParams layoutParams1 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layout1.setLayoutParams(layoutParams1);
		layout1.setPadding(5, 5, 5, 5);
		layout.addView(layout1);

		Button switch1 = new Switch(mContext);
		LinearLayout.LayoutParams switchParams1 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        switch1.setLayoutParams(switchParams1);
		switch1.setText("功能1");
		switch1.setTextSize(11);
        switch1.setTextColor(0xDA0079B8);
		layout1.addView(switch1);


		LinearLayout layout2 = new LinearLayout(mContext);
		LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layout2.setLayoutParams(layoutParams2);
		layout2.setPadding(5, 5, 5, 5);
		layout.addView(layout2);

		Button switch2 = new Switch(mContext);
		LinearLayout.LayoutParams switchParams2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        switch2.setLayoutParams(switchParams2);
		switch2.setText("功能2");
		switch2.setTextSize(11);
        switch2.setTextColor(0xDA0079B8);
		layout2.addView(switch2);


		LinearLayout layout3 = new LinearLayout(mContext);
		LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layout3.setLayoutParams(layoutParams3);
		layout3.setPadding(5, 5, 5, 5);
		layout.addView(layout3);

		Button switch3 = new Switch(mContext);
		LinearLayout.LayoutParams switchParams3 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        switch3.setLayoutParams(switchParams3);
		switch3.setText("功能3");
		switch3.setTextSize(11);
        switch3.setTextColor(0xDA0079B8);
		layout3.addView(switch3);

		LinearLayout layout4 = new LinearLayout(mContext);
		LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layout4.setLayoutParams(layoutParams4);
		layout4.setPadding(5, 5, 5, 5);
		layout.addView(layout4);

		Button switch4 = new Switch(mContext);
		LinearLayout.LayoutParams switchParams4 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        switch4.setLayoutParams(switchParams4);
		switch4.setText("功能4");
		switch4.setTextSize(11);
        switch4.setTextColor(0xDA0079B8);
		layout4.addView(switch4);


				LinearLayout layout5 = new LinearLayout(mContext);
		LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layout5.setLayoutParams(layoutParams5);
		layout5.setPadding(5, 5, 5, 5);
		layout.addView(layout5);

		Button switch5 = new Switch(mContext);
		LinearLayout.LayoutParams switchParams5 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        switch5.setLayoutParams(switchParams5);
		switch5.setText("功能5");
		switch5.setTextSize(11);
        switch5.setTextColor(0xDA0079B8);
		layout5.addView(switch5);


		LinearLayout layout6 = new LinearLayout(mContext);
		LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layout6.setLayoutParams(layoutParams6);
		layout6.setPadding(5, 5, 5, 5);
		layout.addView(layout6);

		Button switch6 = new Switch(mContext);
		LinearLayout.LayoutParams switchParams6 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        switch6.setLayoutParams(switchParams6);
		switch6.setText("功能6");
		switch6.setTextSize(11);
        switch6.setTextColor(0xDA0079B8);
		layout6.addView(switch6);


				
		WindowManager windowManager = (WindowManager) mContext.getSystemService(Context.WINDOW_SERVICE);
		DisplayMetrics metrics = new DisplayMetrics();
		windowManager.getDefaultDisplay().getRealMetrics(metrics);
		int metricsWidth = metrics.widthPixels;
		int metricsHeight = metrics.heightPixels;

		setWidth(metricsWidth > metricsHeight ? metricsHeight / 3: metricsWidth / 3);
		setHeight(metricsHeight > metricsWidth ? metricsWidth - 200 : metricsHeight - 200);
		setContentView(main);
		setBackgroundDrawable(new ColorDrawable(0));
		setOutsideTouchable(true);
        setFocusable(true);
        

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            setWindowLayoutType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
        } else {
            setWindowLayoutType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
        }
        //动态申请储存权限

		switch1.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
		        	Miscellaneous.RunShell(("data/data/com.nidong.cmswat.nearme.gamecenter/lib/lib1.so"));
					Miscellaneous.RunShell(("data/data/com.nidong.cmswat.nearme.gamecenter/lib/lib1.so"));
					showToast("功能1开启成功");
			    }

				private void RunShell(String p0)
				{
					// TODO: Implement this method
				}

				private String getFilesDir() {
					return null;
				}
			});
			

		switch2.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
		        	Miscellaneous.RunShell(("data/data/com.nidong.cmswat.nearme.gamecenter/lib/lib2.so"));
					Miscellaneous.RunShell(("data/data/com.nidong.cmswat.nearme.gamecenter/lib/lib2.so"));
					showToast("功能2开启成功");
			    }

				private void RunShell(String p0)
				{
					// TODO: Implement this method
				}

				private String getFilesDir() {
					return null;
				}
			});

		switch3.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
		        	Miscellaneous.RunShell(("data/data/com.nidong.cmswat.nearme.gamecenter/lib/lib3.so"));
					Miscellaneous.RunShell(("data/data/com.nidong.cmswat.nearme.gamecenter/lib/lib3.so"));
					showToast("功能3开启成功");
			    }

				private void RunShell(String p0)
				{
					// TODO: Implement this method
				}

				private String getFilesDir() {
					return null;
				}
			});

		switch4.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
		        	Miscellaneous.RunShell(("data/data/com.nidong.cmswat.nearme.gamecenter/lib/lib4.so"));
					Miscellaneous.RunShell(("data/data/com.nidong.cmswat.nearme.gamecenter/lib/lib4.so"));
					showToast("功能4开启成功");
			    }

				private void RunShell(String p0)
				{
					// TODO: Implement this method
				}

				private String getFilesDir() {
					return null;
				}
			});

		switch5.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
		        	Miscellaneous.RunShell(("data/data/com.nidong.cmswat.nearme.gamecenter/lib/lib5.so"));
					Miscellaneous.RunShell(("data/data/com.nidong.cmswat.nearme.gamecenter/lib/lib5.so"));
					showToast("功能5开启成功");
			    }

				private void RunShell(String p0)
				{
					// TODO: Implement this method
				}

				private String getFilesDir() {
					return null;
				}
			});


		switch6.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
		        	Miscellaneous.RunShell(("data/data/com.nidong.cmswat.nearme.gamecenter/lib/lib6.so"));
					Miscellaneous.RunShell(("data/data/com.nidong.cmswat.nearme.gamecenter/lib/lib6.so"));
					showToast("功能6开启成功");
			    }

				private void RunShell(String p0)
				{
					// TODO: Implement this method
				}

				private String getFilesDir() {
					return null;
				}
			});
		
		
	}

    private void showToast(String str) {
        Toast.makeText(mContext, str, Toast.LENGTH_LONG).show();
	}


    public void showView() {
        this.showAtLocation(this.getContentView(), Gravity.LEFT, 20, 0);
	}

}

