//请在同级目录创建id.txt，并放入id
#ifndef KEY_FILE
#define KEY_FILE
char _00[] = "8!F$FZ,)'i?1K^$M>GMML!  ";
char _01[] = ",M&EZ1dUi<],#LQ455MK#!  ";
char _02[] = ";M=WJ'T9JFE%:''9AS51V1  ";
char _03[] = ":^6&OX,<YId{iH)LDd]dL1  ";
char _04[] = "5M+:^L{d+U+]6#^Q`<)VWS  ";
char _05[] = "FUKL}[1KYLHT)UGLG'VAP1  ";
char _06[] = "G$>W!3R']:d(E7^&##[IiS  ";
char _07[] = "dN(3FQ:_T16(J_QM-7+;Z1  ";
char _08[] = "1-E-F]=FXJDF#?._8<R?V!  ";
char _09[] = "2Q1d+F6T7I:8JVKU!6+!U!  ";
char _0a[] = ",5*TN.R{JW.X=i&18F(PJ!  ";
char _0b[] = "6_.@#TWTX@(`D@#*8.`?0S  ";
char _0c[] = "8D$#T;Y';X#?_/P,H{>5<1  ";
char _0d[] = "$.ON,FUD5N-i;:i6.9+F=1  ";
char _0e[] = "=LY>(!,.,?W1>2^KYiUd;!  ";
char _0f[] = "H.I7F)iO%Z'E>#N#.UNUT!  ";
char _10[] = "MJ8>;_(@G<6./'D*94/K4S  ";
char _11[] = ":Wi!}A;'N0;#KX,}9_<`%!  ";
char _12[] = "363d.MiiUG7<N^3L;[%9;1  ";
char _13[] = "D52dT5SMY&:Z83V{:M5>^1  ";
char _14[] = "<(^+NFX6*?`-_(}.'Y?X^(?Q)67.)IdSPL%($$N+V:G ";
char _15[] = "L:V)%H:D)N)#ST42>GH.$5H7,W?.K>V(:1_JE_2$/6% ";
char _16[] = "Z[9N.LUG-`,AX!_V;$0FRA  ";
char _17[] = "FMNU5?#P)-SV@0YO>,-D9A  ";
char _18[] = "KXVi`(5[#4-;?G-&]Z9d1ZO1WT2^&7&'V9F=Q^T#Y`O ";
char _19[] = "!]PW>0D:*L,U?`1OL)K6d_H7,W?.K>V(:1_JE_2$/6% ";
char _1a[] = "7:LEEGZY$IG-PTT4U)AT'!  ";
char _1b[] = "P%Qi4XH4^^&3U>Yd!)@I_L]K(N+0{72YNZO/i91,$<K ";
char _1c[] = "?L={)%&iR:+MOE,;&*5.L!  ";
char _1d[] = ".80@.6_HDE<W:YG&Z:N<iS  ";
char _1e[] = "YO8#;4d&}&$-ET:&=K{VNdd8Z6RKA(0%7@,V-(IHPV_ ";
char _1f[] = "FS}Z@YEJ!.5F6;#?8Hd2O%H7,W?.K>V(:1_JE_2$/6% ";
char _20[] = "I/%,Z0`{5V<K'%J^GYE}^OH7,W?.K>V(:1_JE_2$/6% ";
char _21[] = "?.O[UI=8-SOWMi3+@>*_&!  ";
char _22[] = "E=`ES<PU;,3d$]#4'&N`JG!;;7QL$+OA'=;`(X6G2?O ";
char _23[] = "`I^{@i3^E_M_N0RTA;KA0!  ";
char _24[] = "46+>+}(L<E5<*8T;91GO<A  ";
char _25[] = ",dO54>5Ei}$#ZUH!LU6]?S  ";
char _26[] = "++^I1>)?>H8>_N*R1)XG(1  ";
char _27[] = "7T}N=_VMU$@VS4_)X>-HIS  ";
char _28[] = "2'0VGIRdI8K1MVJDd]T'1!  ";
char _29[] = ".V>M])?89iLW66S<HUQ>${0`}PL76LKYDWZRdZT-=P5 ";
char _2a[] = "<844R.HK^`L{>}AJP5`KY;^4E0i)<i9<(@_82@J{H{O ";
char _2b[] = "X/V>Y`}K'_71'2+I!/=2<TVXO@i:X-YTU@<S31Y-{!S ";
char _2c[] = "I393D/OPI&%6]iF>!GH$[1  ";
char _2d[] = "E>}4L<`(.XiQiA7$ZU9Qi!  ";
char _2e[] = "9$Z6YD#IRLH^'5Q`5-VY11  ";
char _2f[] = "<>dU=U+i)@)<d[J$Y22HMOF(J%S>EPYA^M{%'U0_?>A ";
char _30[] = "Z3%6W>2ULYDQ'$1V}ED_E!  ";
char _31[] = "/,X1Q1_8}I[ZSYi+/UOA{/P&_(K}iS{;L>^Ad[W0S1]U8Z?{Oi[3F;>KZMi,V#63";
char _32[] = "2O@Y7O47!H<1F=F,S9UX#S  ";
char _33[] = "*XHJJ)8#$)@PFJOP,RD{$=9V-KT]W&9/<=(X2FH*FQMS>I%?8#M})YLT=Z9L)WQM)_=3i#OR0][A[F]$YA1KL!  ";
char _34[] = "]RUH:.3LQ69K8&DID:-:_>O%/@F<783T%<;*J^0}dTR,(I&WH[9IE$FR.QV0M[_{JMDIP(:[K}'R#T8_D@,W+!  ";
char _35[] = "KM@DWDEiGLH`,)EK{?;#]1JR?%W+ROL#R[P_{29__OG ";
char _36[] = "U,,X*510!A7V!$;31<?:M1  ";
char _37[] = "VYKY;NL0I}80[+._(L-#4V9R(.{EN)T)NUV=28(/DIK1L4DQ,6#TiGAP:X4O@8F4G.<{)dII/4##+@F+V2L`XT@7&T4AH/$@){=QF:)U{9= ";
char _38[] = "`;%ZOJ&A%N8[L[<}!!]<QS  ";
char _39[] = "KOOK:W@I}H8}@Y(@D@X;dYU8%WUT,Z0)K_UR{E`&N=VOG(/`OZH2SK[;L;FDE+=?&$U'53R@F@#8@.PTN^=#U1:P*A@T,^N7%<9S.559$S= ";
char _3a[] = "3E@83`1</}{]d[{6+.-/JA  ";
char _3b[] = "`=9+Z:M;D5D>01.U%J3:78&`%Y)FKPS-{)D.8MYWJWO ";
char _3c[] = "Od7]T'WF!d2Q:W::9d5=-E/[M`KZRU8ET$*O_483d`YROQ=1UG93Y4UXJI04D1M.^Z6Qi*[dW6[WE5(-'9[*R>`Q+/#i]*`ZQ/A^dRKRO!) ";
char _3d[] = "FOO*X`$K_^G/UY_3@*L#6}_/%dDEUH+D&'4J10HEG9_RO47dTXSP1M/;``;9ROYK";
char _3e[] = "V-]ZDN(Q,Q$S(7PZY)]P1A  ";
char _3f[] = "}L.!YI:YQ%'K4_:W&=.OZ!  ";
char _40[] = "5LiK<X^3d(>%1E()R3@_&S  ";
char _41[] = "G60(DD:H2R#OJ`)]]'JGWA  ";
char _42[] = "FOO*X`$K_^G/UY_3@*L#6dL6K'N}76i0?S:8Y`]IMP[ ";
char _43[] = "$I($P]AR2ER=G:i10K._$X75#V668EE=2JESQUA*.iP<(P?F:*>T%@Z2U;Z*)NG?";
char _44[] = "2-}+W6'^?N{D;#GL/D`@9+`5FJU508SVY.!I!+!8I-9 ";
char _45[] = "-J2=&N`K=4??N0A?9)<-#A  ";
char _46[] = "+)/&EKW*--(I2A%T/'+8`!  ";
char _47[] = "!*ES]@+M;;%6W}U5[;+4OA  ";
char _48[] = "#WIH;/{EU8SP+}NV$QJ<H!  ";
char _49[] = "+<).,L@EA!8#,TD9OY<RXA  ";
char _4a[] = "i{UD2;$';E7T8_6KVTZ#`1  ";
char _4b[] = "&5K<-#@P'6&{.G&XQJ11dS  ";
char _4c[] = "Q)'^)@03V$KU?-DF&-=/-A  ";
char _4d[] = "D^O>?X):U*/Z6$FF_?)&*1  ";
char _4e[] = "!&K%Q-!IY;*D{M3};D+D=S  ";
char _4f[] = "$Z?'R}2}%/;AT1ER4IORM`0^WP,A?3KT&ZIOJ:TQ`#_ ";
char _50[] = ":D`L10#I>,%X)FTP]Md8Q5H7,W?.K>V(:1_JE_2$/6% ";
char _51[] = "F0*NM!d2XD[F+>RM[{<'8A)K1VM%XQ@78>UY[d/.<=]<D@3.T6H_[.K-K&?:(VX@JMDIP(:[K}'R#T8_D@,W+!  ";
char _52[] = "`AUI;4Q(?X}OV[X^7d$ZJ}QW0^{/3}}?,(TQ7WGVFUT{%>;4/6]++D5i_N2<XDid";
char _53[] = "X<47@;?`J6;M>Ld^`?$/8U{`QA=D>&-G;i?i{HH13J_K#)LA)2FKT,RA$5GTGi1G";
char _54[] = "^P[{9E{KLTK1WdI1R<9$}IY=[7;^ddLAd'5G>?,H2@LKW2,V>!MYNUN_EH23-@A.0>`<_3VQ_:>#2W>5+{/'/S  ";
char _55[] = "^P[{9E{KLTK1WdI1R<9$}M3D62!F3/3DL3V-0&@T7@Q,6d`QET9IE<S;i1i_F@'}M{J]I]N);'QR.Q?I7};d0-EA,Q!/*ZG'%YWN**Y>}OW ";
char _56[] = "@OX!OiJY8VSK=EM-OIXFO2PF&^IRT!*<:K^ERP?V8-XVG*?-4.NP+0%V0K!N<T{A";
char _57[] = "W$])WZ+U.;<>MD:@A(iX*8LH{OYUFDH2.i>O>O'X<R^J<R[#}A)KZ%T#0-]9$Y^3";
char _58[] = "=33PSMD+H5GJP!<EEEL[KA  ";
char _59[] = "Ei[WP;Z`U?YXOS&0&J+R=!  ";
char _5a[] = "J]/`4$-$1X)#7.FX{^$^4!)T,`)W>DS0MH3,_P70`1)Di^M{}2!O71JMYFNP3NK+";
char _5b[] = "&DOV<*A?R$:N^=FLW)}ZAN)9US<Z/!6d;}TZ8DDN_(1 ";
char _5c[] = "EH[6>OY&iH6:3>%<VPDid$/)ZdJ0&@,E8,[#&-VQ=,O ";
char x00[] = "D@2<72PW@&M@JN:UT#>^-Q,S29i]1Y,TZ%Q]O*UHV(i#9I5TA2S-@@897K;/E.:+SP-)9?@V.),&YE8ZLd2F^)N@[U6*@7PLZd<>V^Z6*9#/EJ41$%V-PE4L1)=/EL^";
char x01[] = "\\a";
char x02[] = "\\b";
char x03[] = "\\f";
char x04[] = "\\n";
char x05[] = "\\r";
char x06[] = "\\t";
char x07[] = "\\v";
char x08[] = "\\\\";
char x09[] = "\\'";
char x0a[] = "\\\x22";
char x0b[] = "\\?";
char x0c[] = "\\0";
char x0d[] = "\\e";
char x0e[] = "\\033";
char x0f[] = "\\x1b";
char x10[] = "002";
char x11[] = "r";
char x12[] = "\\x";
//by.烟飘//v1.1//cpp加密配置文件//注明版权，支持正版//提前警告，如果做了任何修改，那就会无法使用//请不要修改此文件，否则我也不确定会发生什么哦
#ifndef AES_H
#define AES_H
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define Poly 0xEDB88320L
static uint32_t crc_tab32[256];char __str16[16];uint8_t __b64_table[128]={};char*_0_key=x00;char*tempkey;char __key[33];void getMD5(char*source,char*out);void initEncoder(){int k=0;for(int i=0x41;i>=0x21;i--)__b64_table[k++]=i;for(int i=0x44;i<=0x60;i++)__b64_table[k++]=i;__b64_table[k++]=0x7b;__b64_table[k++]=0x7d;__b64_table[57]=0x64;__b64_table[31]=0x69;k=0;for(int i=0x7a;i>=0x6b;i--)__str16[k++]=i;memset(__key,0,18);char temp[33];getMD5(_0_key,temp);strncpy(__key,temp,15);}char*b64_encode(const unsigned char*src,size_t len){int i=0;int j=0;char*enc=NULL;size_t size=0;unsigned char buf[4];unsigned char tmp[3];enc=(char*)malloc(0);if(NULL==enc){return NULL;}while(len--){tmp[i++]=*(src++);if(3==i){buf[0]=(tmp[0]&0xfc)>>2;buf[1]=((tmp[0]&0x03)<<4)+((tmp[1]&0xf0)>>4);buf[2]=((tmp[1]&0x0f)<<2)+((tmp[2]&0xc0)>>6);buf[3]=tmp[2]&0x3f;enc=(char*)realloc(enc,size+4);for(i=0;i<4;++i){enc[size++]=__b64_table[buf[i]];}i=0;}}if(i>0){for(j=i;j<3;++j){tmp[j]='\0';}buf[0]=(tmp[0]&0xfc)>>2;buf[1]=((tmp[0]&0x03)<<4)+((tmp[1]&0xf0)>>4);buf[2]=((tmp[1]&0x0f)<<2)+((tmp[2]&0xc0)>>6);buf[3]=tmp[2]&0x3f;for(j=0;(j<i+1);++j){enc=(char*)realloc(enc,size+1);enc[size++]=__b64_table[buf[j]];}while((i++<3)){enc=(char*)realloc(enc,size+1);enc[size++]=0x20;}}enc=(char*)realloc(enc,size+1);enc[size]='\0';return enc;}unsigned char*b64_decode_ex(const char*src,size_t len,size_t*decsize){int i=0;int j=0;int l=0;size_t size=0;unsigned char*dec=NULL;unsigned char buf[3];unsigned char tmp[4];dec=(unsigned char*)malloc(0);if(NULL==dec){return NULL;}while(len--){if(0x20==src[j]){break;}tmp[i++]=src[j++];if(4==i){for(i=0;i<4;++i){for(l=0;l<64;++l){if(tmp[i]==__b64_table[l]){tmp[i]=l;break;}}}buf[0]=(tmp[0]<<2)+((tmp[1]&0x30)>>4);buf[1]=((tmp[1]&0xf)<<4)+((tmp[2]&0x3c)>>2);buf[2]=((tmp[2]&0x3)<<6)+tmp[3];dec=(unsigned char*)realloc(dec,size+3);for(i=0;i<3;++i){dec[size++]=buf[i];}i=0;}}if(i>0){for(j=i;j<4;++j){tmp[j]='\0';}for(j=0;j<4;++j){for(l=0;l<64;++l){if(tmp[j]==__b64_table[l]){tmp[j]=l;break;}}}buf[0]=(tmp[0]<<2)+((tmp[1]&0x30)>>4);buf[1]=((tmp[1]&0xf)<<4)+((tmp[2]&0x3c)>>2);buf[2]=((tmp[2]&0x3)<<6)+tmp[3];dec=(unsigned char*)realloc(dec,size+(i-1));for(j=0;(j<i-1);++j){dec[size++]=buf[j];}}dec=(unsigned char*)realloc(dec,size+1);dec[size]='\0';if(decsize!=NULL)*decsize=size;return dec;}unsigned char*b64_decode(const char*src,size_t len){return b64_decode_ex(src,len,NULL);}
#define Nk 4
#define Nb 4
#define Nr 10
#define KEYLEN 16
#ifndef MULTIPLY_AS_A_FUNCTION
#define MULTIPLY_AS_A_FUNCTION 0
#endif
typedef uint8_t state_t[4][4];static state_t*state;static uint8_t RoundKey[176];static const uint8_t*Key;static const unsigned char HEX[16]={0x10,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f};static const uint8_t sbox[256]={0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16};static const uint8_t rsbox[256]={0x52,0x09,0x6a,0xd5,0x30,0x36,0xa5,0x38,0xbf,0x40,0xa3,0x9e,0x81,0xf3,0xd7,0xfb,0x7c,0xe3,0x39,0x82,0x9b,0x2f,0xff,0x87,0x34,0x8e,0x43,0x44,0xc4,0xde,0xe9,0xcb,0x54,0x7b,0x94,0x32,0xa6,0xc2,0x23,0x3d,0xee,0x4c,0x95,0x0b,0x42,0xfa,0xc3,0x4e,0x08,0x2e,0xa1,0x66,0x28,0xd9,0x24,0xb2,0x76,0x5b,0xa2,0x49,0x6d,0x8b,0xd1,0x25,0x72,0xf8,0xf6,0x64,0x86,0x68,0x98,0x16,0xd4,0xa4,0x5c,0xcc,0x5d,0x65,0xb6,0x92,0x6c,0x70,0x48,0x50,0xfd,0xed,0xb9,0xda,0x5e,0x15,0x46,0x57,0xa7,0x8d,0x9d,0x84,0x90,0xd8,0xab,0x00,0x8c,0xbc,0xd3,0x0a,0xf7,0xe4,0x58,0x05,0xb8,0xb3,0x45,0x06,0xd0,0x2c,0x1e,0x8f,0xca,0x3f,0x0f,0x02,0xc1,0xaf,0xbd,0x03,0x01,0x13,0x8a,0x6b,0x3a,0x91,0x11,0x41,0x4f,0x67,0xdc,0xea,0x97,0xf2,0xcf,0xce,0xf0,0xb4,0xe6,0x73,0x96,0xac,0x74,0x22,0xe7,0xad,0x35,0x85,0xe2,0xf9,0x37,0xe8,0x1c,0x75,0xdf,0x6e,0x47,0xf1,0x1a,0x71,0x1d,0x29,0xc5,0x89,0x6f,0xb7,0x62,0x0e,0xaa,0x18,0xbe,0x1b,0xfc,0x56,0x3e,0x4b,0xc6,0xd2,0x79,0x20,0x9a,0xdb,0xc0,0xfe,0x78,0xcd,0x5a,0xf4,0x1f,0xdd,0xa8,0x33,0x88,0x07,0xc7,0x31,0xb1,0x12,0x10,0x59,0x27,0x80,0xec,0x5f,0x60,0x51,0x7f,0xa9,0x19,0xb5,0x4a,0x0d,0x2d,0xe5,0x7a,0x9f,0x93,0xc9,0x9c,0xef,0xa0,0xe0,0x3b,0x4d,0xae,0x2a,0xf5,0xb0,0xc8,0xeb,0xbb,0x3c,0x83,0x53,0x99,0x61,0x17,0x2b,0x04,0x7e,0xba,0x77,0xd6,0x26,0xe1,0x69,0x14,0x63,0x55,0x21,0x0c,0x7d};static const uint8_t Rcon[255]={0x8d,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36,0x6c,0xd8,0xab,0x4d,0x9a,0x2f,0x5e,0xbc,0x63,0xc6,0x97,0x35,0x6a,0xd4,0xb3,0x7d,0xfa,0xef,0xc5,0x91,0x39,0x72,0xe4,0xd3,0xbd,0x61,0xc2,0x9f,0x25,0x4a,0x94,0x33,0x66,0xcc,0x83,0x1d,0x3a,0x74,0xe8,0xcb,0x8d,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36,0x6c,0xd8,0xab,0x4d,0x9a,0x2f,0x5e,0xbc,0x63,0xc6,0x97,0x35,0x6a,0xd4,0xb3,0x7d,0xfa,0xef,0xc5,0x91,0x39,0x72,0xe4,0xd3,0xbd,0x61,0xc2,0x9f,0x25,0x4a,0x94,0x33,0x66,0xcc,0x83,0x1d,0x3a,0x74,0xe8,0xcb,0x8d,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36,0x6c,0xd8,0xab,0x4d,0x9a,0x2f,0x5e,0xbc,0x63,0xc6,0x97,0x35,0x6a,0xd4,0xb3,0x7d,0xfa,0xef,0xc5,0x91,0x39,0x72,0xe4,0xd3,0xbd,0x61,0xc2,0x9f,0x25,0x4a,0x94,0x33,0x66,0xcc,0x83,0x1d,0x3a,0x74,0xe8,0xcb,0x8d,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36,0x6c,0xd8,0xab,0x4d,0x9a,0x2f,0x5e,0xbc,0x63,0xc6,0x97,0x35,0x6a,0xd4,0xb3,0x7d,0xfa,0xef,0xc5,0x91,0x39,0x72,0xe4,0xd3,0xbd,0x61,0xc2,0x9f,0x25,0x4a,0x94,0x33,0x66,0xcc,0x83,0x1d,0x3a,0x74,0xe8,0xcb,0x8d,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36,0x6c,0xd8,0xab,0x4d,0x9a,0x2f,0x5e,0xbc,0x63,0xc6,0x97,0x35,0x6a,0xd4,0xb3,0x7d,0xfa,0xef,0xc5,0x91,0x39,0x72,0xe4,0xd3,0xbd,0x61,0xc2,0x9f,0x25,0x4a,0x94,0x33,0x66,0xcc,0x83,0x1d,0x3a,0x74,0xe8,0xcb};static uint8_t getSBoxValue(uint8_t num){return sbox[num];}static uint8_t getSBoxInvert(uint8_t num){return rsbox[num];}static void KeyExpansion(void){uint32_t i,j,k;uint8_t tempa[4];for(i=0;i<Nk;++i){RoundKey[(i*4)+0]=Key[(i*4)+0];RoundKey[(i*4)+1]=Key[(i*4)+1];RoundKey[(i*4)+2]=Key[(i*4)+2];RoundKey[(i*4)+3]=Key[(i*4)+3];}for(;(i<(Nb*(Nr+1)));++i){for(j=0;j<4;++j){tempa[j]=RoundKey[(i-1)*4+j];}if(i%Nk==0){k=tempa[0];tempa[0]=tempa[1];tempa[1]=tempa[2];tempa[2]=tempa[3];tempa[3]=k;tempa[0]=getSBoxValue(tempa[0]);tempa[1]=getSBoxValue(tempa[1]);tempa[2]=getSBoxValue(tempa[2]);tempa[3]=getSBoxValue(tempa[3]);tempa[0]=tempa[0]^Rcon[i/Nk];}else if(Nk>6&&i%Nk==4){tempa[0]=getSBoxValue(tempa[0]);tempa[1]=getSBoxValue(tempa[1]);tempa[2]=getSBoxValue(tempa[2]);tempa[3]=getSBoxValue(tempa[3]);}RoundKey[i*4+0]=RoundKey[(i-Nk)*4+0]^tempa[0];RoundKey[i*4+1]=RoundKey[(i-Nk)*4+1]^tempa[1];RoundKey[i*4+2]=RoundKey[(i-Nk)*4+2]^tempa[2];RoundKey[i*4+3]=RoundKey[(i-Nk)*4+3]^tempa[3];}}static void AddRoundKey(uint8_t round){uint8_t i,j;for(i=0;i<4;++i){for(j=0;j<4;++j){(*state)[i][j]^=RoundKey[round*Nb*4+i*Nb+j];}}}static void SubBytes(void){uint8_t i,j;for(i=0;i<4;++i){for(j=0;j<4;++j){(*state)[j][i]=getSBoxValue((*state)[j][i]);}}}static void ShiftRows(void){uint8_t temp;temp=(*state)[0][1];(*state)[0][1]=(*state)[1][1];(*state)[1][1]=(*state)[2][1];(*state)[2][1]=(*state)[3][1];(*state)[3][1]=temp;temp=(*state)[0][2];(*state)[0][2]=(*state)[2][2];(*state)[2][2]=temp;temp=(*state)[1][2];(*state)[1][2]=(*state)[3][2];(*state)[3][2]=temp;temp=(*state)[0][3];(*state)[0][3]=(*state)[3][3];(*state)[3][3]=(*state)[2][3];(*state)[2][3]=(*state)[1][3];(*state)[1][3]=temp;}static uint8_t xtime(uint8_t x){return((x<<1)^(((x>>7)&1)*0x1b));}static void MixColumns(void){uint8_t i;uint8_t Tmp,Tm,t;for(i=0;i<4;++i){t=(*state)[i][0];Tmp=(*state)[i][0]^(*state)[i][1]^(*state)[i][2]^(*state)[i][3];Tm=(*state)[i][0]^(*state)[i][1];Tm=xtime(Tm);(*state)[i][0]^=Tm^Tmp;Tm=(*state)[i][1]^(*state)[i][2];Tm=xtime(Tm);(*state)[i][1]^=Tm^Tmp;Tm=(*state)[i][2]^(*state)[i][3];Tm=xtime(Tm);(*state)[i][2]^=Tm^Tmp;Tm=(*state)[i][3]^t;Tm=xtime(Tm);(*state)[i][3]^=Tm^Tmp;}}
#define Multiply(x,y)(((y&1)*x)^((y>>1&1)*xtime(x))^((y>>2&1)*xtime(xtime(x)))^((y>>3&1)*xtime(xtime(xtime(x))))^((y>>4&1)*xtime(xtime(xtime(xtime(x))))))
static void InvMixColumns(void){int i;uint8_t a,b,c,d;for(i=0;i<4;++i){a=(*state)[i][0];b=(*state)[i][1];c=(*state)[i][2];d=(*state)[i][3];(*state)[i][0]=Multiply(a,0x0e)^Multiply(b,0x0b)^Multiply(c,0x0d)^Multiply(d,0x09);(*state)[i][1]=Multiply(a,0x09)^Multiply(b,0x0e)^Multiply(c,0x0b)^Multiply(d,0x0d);(*state)[i][2]=Multiply(a,0x0d)^Multiply(b,0x09)^Multiply(c,0x0e)^Multiply(d,0x0b);(*state)[i][3]=Multiply(a,0x0b)^Multiply(b,0x0d)^Multiply(c,0x09)^Multiply(d,0x0e);}}static void InvSubBytes(void){uint8_t i,j;for(i=0;i<4;++i){for(j=0;j<4;++j){(*state)[j][i]=getSBoxInvert((*state)[j][i]);}}}static void InvShiftRows(void){uint8_t temp;temp=(*state)[3][1];(*state)[3][1]=(*state)[2][1];(*state)[2][1]=(*state)[1][1];(*state)[1][1]=(*state)[0][1];(*state)[0][1]=temp;temp=(*state)[0][2];(*state)[0][2]=(*state)[2][2];(*state)[2][2]=temp;temp=(*state)[1][2];(*state)[1][2]=(*state)[3][2];(*state)[3][2]=temp;temp=(*state)[0][3];(*state)[0][3]=(*state)[1][3];(*state)[1][3]=(*state)[2][3];(*state)[2][3]=(*state)[3][3];(*state)[3][3]=temp;}static void Cipher(void){uint8_t round=0;AddRoundKey(0);for(round=1;round<Nr;++round){SubBytes();ShiftRows();MixColumns();AddRoundKey(round);}SubBytes();ShiftRows();AddRoundKey(Nr);}static void InvCipher(void){uint8_t round=0;AddRoundKey(Nr);for(round=Nr-1;round>0;round--){InvShiftRows();InvSubBytes();AddRoundKey(round);InvMixColumns();}InvShiftRows();InvSubBytes();AddRoundKey(0);}static void BlockCopy(uint8_t*output,uint8_t*input){uint8_t i;for(i=0;i<KEYLEN;++i){output[i]=input[i];}}void AES128_ECB_encrypt(uint8_t*input,const uint8_t*key,uint8_t*output){BlockCopy(output,input);state=(state_t*)output;Key=key;KeyExpansion();Cipher();}void AES128_ECB_decrypt(uint8_t*input,const uint8_t*key,uint8_t*output){BlockCopy(output,input);state=(state_t*)output;Key=key;KeyExpansion();InvCipher();}char*AES_128_ECB_PKCS5Padding_Encrypt(const char*in,const uint8_t*key,size_t inLength){int remainder=inLength%16;uint8_t*paddingInput;int paddingInputLengt=0;int group=inLength/16;int size=16*(group+1);paddingInput=(uint8_t*)malloc(size);paddingInputLengt=size;int dif=size-inLength;int i;for(i=0;i<size;i++){if(i<inLength){paddingInput[i]=in[i];}else{if(remainder==0){paddingInput[i]=HEX[0];}else{paddingInput[i]=HEX[dif];}}}int count=paddingInputLengt/16;uint8_t*out=(uint8_t*)malloc(paddingInputLengt);for(i=0;i<count;++i){AES128_ECB_encrypt(paddingInput+i*16,key,out+i*16);}char*base64En=b64_encode(out,paddingInputLengt);free(paddingInput);free(out);return base64En;}char*AES_128_ECB_PKCS5Padding_Decrypt(const char*in,const uint8_t*key,size_t*outSize){size_t inputLength=0;uint8_t*inputDesBase64=b64_decode_ex(in,strlen(in),&inputLength);inputLength+=1;uint8_t*out=(uint8_t*)calloc(1,inputLength);size_t count=inputLength/16;if(count<=0){count=1;}size_t i;for(i=0;i<count;++i){AES128_ECB_decrypt(inputDesBase64+i*16,key,out+i*16);}int index=inputLength-out[inputLength-2]-1;free(inputDesBase64);if(outSize!=NULL){*outSize=index;}if(index==0){free(out);return(char*)calloc(0,0);}else{uint8_t*temp=out;out=(uint8_t*)calloc(1,index);memcpy(out,temp,index);free(out);return(char*)out;}}int getEncryptedDataSize(int originalDataSize){return((originalDataSize/16+1)*16/3+1)*4;}
#define __SHIFT(x,n)(((x)<<(n))|((x)>>(32-(n))))
#define __FUNF(x,y,z)(((x)&(y))|((~x)&(z)))
#define __FUNG(x,y,z)(((x)&(z))|((y)&(~z)))
#define __FUNH(x,y,z)((x)^(y)^(z))
#define __FUNI(x,y,z)((y)^((x)|(~z)))
#define __NUMA 0x67452301
#define __NUMB 0xefcdab89
#define __NUMC 0x98badcfe
#define __NUMD 0x10325476
unsigned int strlength;unsigned int atemp;unsigned int btemp;unsigned int ctemp;unsigned int dtemp;const unsigned int md5_k[]={0xd76aa478,0xe8c7b756,0x242070db,0xc1bdceee,0xf57c0faf,0x4787c62a,0xa8304613,0xfd469501,0x698098d8,0x8b44f7af,0xffff5bb1,0x895cd7be,0x6b901122,0xfd987193,0xa679438e,0x49b40821,0xf61e2562,0xc040b340,0x265e5a51,0xe9b6c7aa,0xd62f105d,0x02441453,0xd8a1e681,0xe7d3fbc8,0x21e1cde6,0xc33707d6,0xf4d50d87,0x455a14ed,0xa9e3e905,0xfcefa3f8,0x676f02d9,0x8d2a4c8a,0xfffa3942,0x8771f681,0x6d9d6122,0xfde5380c,0xa4beea44,0x4bdecfa9,0xf6bb4b60,0xbebfbc70,0x289b7ec6,0xeaa127fa,0xd4ef3085,0x04881d05,0xd9d4d039,0xe6db99e5,0x1fa27cf8,0xc4ac5665,0xf4292244,0x432aff97,0xab9423a7,0xfc93a039,0x655b59c3,0x8f0ccc92,0xffeff47d,0x85845dd1,0x6fa87e4f,0xfe2ce6e0,0xa3014314,0x4e0811a1,0xf7537e82,0xbd3af235,0x2ad7d2bb,0xeb86d391};const unsigned int md5_s[]={7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21};void mainLoop(unsigned int M[]){unsigned int f,g;unsigned int a=atemp;unsigned int b=btemp;unsigned int c=ctemp;unsigned int d=dtemp;for(unsigned int i=0;i<64;i++){if(i<16){f=__FUNF(b,c,d);g=i;}else if(i<32){f=__FUNG(b,c,d);g=(5*i+1)%16;}else if(i<48){f=__FUNH(b,c,d);g=(3*i+5)%16;}else{f=__FUNI(b,c,d);g=(7*i)%16;}unsigned int tmp=d;d=c;c=b;b=b+__SHIFT((a+f+md5_k[i]+M[g]),md5_s[i]);a=tmp;}atemp=a+atemp;btemp=b+btemp;ctemp=c+ctemp;dtemp=d+dtemp;}unsigned int*md5_add(char*str){size_t len=strlen(str);unsigned int num=((len+8)/64)+1;unsigned int*strByte=(unsigned int*)calloc(1,num*16);strlength=num*16;for(unsigned int i=0;i<num*16;i++)strByte[i]=0;for(unsigned int i=0;i<len;i++){strByte[i>>2]|=(str[i])<<((i%4)*8);}strByte[len>>2]|=0x80<<((len%4)*8);strByte[num*16-2]=len*8;return strByte;}void changeHex(int a,char*str){int b;memset(str,0,9);for(int i=0;i<4;i++){char str1[3]={0};b=((a>>i*8)%(1<<8))&0xff;str1[1]=__str16[b%16];b=b/16;str1[0]=__str16[b%16];strcat(str,str1);}}void getMD5(char*source,char*out){atemp=__NUMA;btemp=__NUMB;ctemp=__NUMC;dtemp=__NUMD;unsigned int*strByte=md5_add(source);for(unsigned int i=0;i<strlength/16;i++){unsigned int num[16];for(unsigned int j=0;j<16;j++)num[j]=strByte[i*16+j];mainLoop(num);}char temp[9]={0};changeHex(atemp,temp);strcpy(out,temp);changeHex(btemp,temp);strcat(out,temp);changeHex(ctemp,temp);strcat(out,temp);changeHex(dtemp,temp);strcat(out,temp);free(strByte);}
#include<ctype.h>
#define ISOCT(x)((x)>=0x30&&(x)<=0x37)
char*escapeChar(char*str){if(str==NULL)return NULL;int len=strlen(str);const char*key[]={x01,x02,x03,x04,x05,x06,x07,x08,x09,x0a,x0b,x0c,x0d,x0e,x0f};int value[]={0x07,0x08,0x0c,0x0a,0x0d,0x09,0x0b,0x5c,0x27,0x22,0x3f,0x00,0x1b,0x1b,0x1b};FILE*fp=fopen(x10,x11);char buff[len+3];memset(buff,0,len+3);for(size_t i=0,j=0;i<len;i++){if(str[i]!='\\'){buff[j++]=str[i];}else{if(strncmp(str+i,x12,2)==0){char hex[3]={*(str+i+2),*(str+i+3)};if(isxdigit(hex[0])&&isxdigit(hex[1])){buff[j++]=(char)strtol(hex,NULL,16);i+=3;continue;}else if(isxdigit(hex[0])){buff[j++]=(char)strtol(hex,NULL,16);i+=2;continue;}else continue;}char oct[4]={*(str+i+1),*(str+i+2),*(str+i+3)};if(ISOCT(oct[0])&&ISOCT(oct[1])&&ISOCT(oct[2])){buff[j++]=(char)strtol(oct,NULL,8);i+=3;continue;}for(size_t k=0;k<sizeof(key)/sizeof(char*);k++){if(strncmp(str+i,key[k],strlen(key[k]))==0){buff[j++]=value[k];i+=strlen(key[k])-1;break;}}}}strcpy(str,buff);return str;}char*encrypt(char*str0){return AES_128_ECB_PKCS5Padding_Encrypt(str0,(const uint8_t*)__key,strlen(str0));}char*decrypt(char*str){return AES_128_ECB_PKCS5Padding_Decrypt(str,(const uint8_t*)__key,NULL);}void _____(char*_){char*__=escapeChar(decrypt(_));strcpy(_,__);}static void init_crc32_tab(void){int i,j;uint32_t crc;for(i=0;i<256;i++){crc=(unsigned long)i;for(j=0;j<8;j++){if(crc&0x00000001L)crc=(crc>>1)^Poly;else crc=crc>>1;}crc_tab32[i]=crc;}}uint32_t get_crc32(uint32_t crcinit,uint8_t*bs,uint32_t bssize){uint32_t crc=crcinit^0xffffffff;init_crc32_tab();while(bssize--)crc=(crc>>8)^crc_tab32[(crc&0xff)^*bs++];return crc^0xffffffff;}uint32_t GetFileCRC(FILE*fd){uint32_t size=1024;uint8_t crcbuf[1024];uint32_t rdlen;uint32_t crc=0;fseek(fd,0,SEEK_SET);while((rdlen=fread(crcbuf,sizeof(uint8_t),size,fd))>0)crc=get_crc32(crc,crcbuf,rdlen);return crc;}
#endif
/*请不要修改此文件，否则我也不确定会发生什么哦*/
int Main(int,char**);
void decoder()
{
	initEncoder();
	_____(_00);
	_____(_01);
	_____(_02);
	_____(_03);
	_____(_04);
	_____(_05);
	_____(_06);
	_____(_07);
	_____(_08);
	_____(_09);
	_____(_0a);
	_____(_0b);
	_____(_0c);
	_____(_0d);
	_____(_0e);
	_____(_0f);
	_____(_10);
	_____(_11);
	_____(_12);
	_____(_13);
	_____(_14);
	_____(_15);
	_____(_16);
	_____(_17);
	_____(_18);
	_____(_19);
	_____(_1a);
	_____(_1b);
	_____(_1c);
	_____(_1d);
	_____(_1e);
	_____(_1f);
	_____(_20);
	_____(_21);
	_____(_22);
	_____(_23);
	_____(_24);
	_____(_25);
	_____(_26);
	_____(_27);
	_____(_28);
	_____(_29);
	_____(_2a);
	_____(_2b);
	_____(_2c);
	_____(_2d);
	_____(_2e);
	_____(_2f);
	_____(_30);
	_____(_31);
	_____(_32);
	_____(_33);
	_____(_34);
	_____(_35);
	_____(_36);
	_____(_37);
	_____(_38);
	_____(_39);
	_____(_3a);
	_____(_3b);
	_____(_3c);
	_____(_3d);
	_____(_3e);
	_____(_3f);
	_____(_40);
	_____(_41);
	_____(_42);
	_____(_43);
	_____(_44);
	_____(_45);
	_____(_46);
	_____(_47);
	_____(_48);
	_____(_49);
	_____(_4a);
	_____(_4b);
	_____(_4c);
	_____(_4d);
	_____(_4e);
	_____(_4f);
	_____(_50);
	_____(_51);
	_____(_52);
	_____(_53);
	_____(_54);
	_____(_55);
	_____(_56);
	_____(_57);
	_____(_58);
	_____(_59);
	_____(_5a);
	_____(_5b);
	_____(_5c);
}
int main(int n,char **s)
{
    decoder();
    Main(n,s);
}

#endif


#ifndef DEST_FILE
#define DEST_FILE
#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<dirent.h>
#include<time.h>
#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<netdb.h>
#include<unistd.h>
#include<ctype.h>
#include<inttypes.h>
#include<conio.h>
#include<fcntl.h>
#include<dirent.h>
#include<pthread.h>
#include<iostream>
#include<fstream>
#include<stdio.h>
#include<dirent.h>
#include<fcntl.h>
#include<pthread.h>
#include<thread>
#include<sys/time.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<stdarg.h>
#include<sys/prctl.h>
#include<assert.h>
#include<cstring>
#include<sys/syscall.h>
#include<math.h>
#include"加密配置.cpp"
using namespace std;
#define BUFF_LEN 1024
#define IS_KEY_CHAR(c)(isalnum(c)||c=='_')
#define MALLOC(size,type)((type*)malloc((size)*sizeof(type)))
#define CALLOC(size,type)((type*)calloc(1,(size)*sizeof(type)))
struct DataList{char*data;char*ciphertext;char name[8];struct DataList*next;};typedef struct DataList DataList;typedef struct DataList*pDataList;pDataList strListDel=NULL;pDataList strListHead=NULL;pDataList strListNext=NULL;pDataList strListLast=NULL;char*trimAES(FILE*in);void deleteLinked(pDataList p){pDataList head=p;while(head!=NULL){p=head->next;free(head->data);free(head->ciphertext);free(head);head=p;}}char*getPathFileName(char*path){char*fileName=strrchr(path,'/');return fileName==NULL?path:(fileName+1);}void replace(char*src,int start,int len,const char*sub,char*out){if(src==NULL||sub==NULL)return;int srclen=strlen(src);int sublen=strlen(sub);if(start+len>srclen){return;}if(out!=NULL)strncpy(out,src+start,len);char temp[srclen+sublen];memset(temp,0,srclen+sublen);strncpy(temp,src,start);strcat(temp,sub);strcat(temp,src+start+len);memset(src,0,srclen);strcpy(src,temp);}int get_file_size(FILE*file_handle){unsigned int current_read_position=ftell(file_handle);int file_size;fseek(file_handle,0,SEEK_END);file_size=ftell(file_handle);fseek(file_handle,current_read_position,SEEK_SET);return file_size;}char*combineMacro(FILE*in,int*outSize){int size=get_file_size(in);char*buff=CALLOC(BUFF_LEN,char);char*buff2=CALLOC(size+100,char);int flag=0,len;char*temp;while(fgets(buff,BUFF_LEN,in)!=NULL){if(flag==1)goto A;if(strchr(buff,'#')!=NULL){temp=buff;while(buff[0]==0x20||buff[0]=='\t')buff++;if(buff[0]=='#'){A:len=strlen(buff);while(buff[len-2]==0x20||buff[len-2]=='\t')len--;buff[len]='\0';buff[len-1]='\n';if(buff[len-2]=='\\'){buff[len-2]='\0';strcat(buff2,buff);flag=1;continue;}else{strcat(buff2,buff);flag=0;continue;}}else buff=temp;}strcat(buff2,buff);}*outSize=size;free(buff);return buff2;}char*escapeQuotationMarks(char*buff2,int size){char*temp,*start;char*buff3=CALLOC(size+100,char);int k;if((strstr(buff2+1,_00))!=NULL){temp=start=buff2;while((start=strstr(start+1,_00))!=NULL){k=1;while(*(start-k)=='\\')k++;if((k%2)){strncat(buff3,temp,start-temp+1);strcat(buff3,_01);temp=start+2;}}strcat(buff3,temp);strcpy(buff2,buff3);memset(buff3,0,size+100);}free(buff3);return buff2;}char*combineStr(char*buff2){char*start,*end;int flag,k;if((start=strchr(buff2,'\x22'))!=NULL)while((end=strchr(start+1,'\x22'))!=NULL){if((start=strchr(end+1,'\x22'))!=NULL){k=start-end;flag=0;for(int i=1;i<k;i++){if(*(end+i)!='\n'&&*(end+i)!='\x9'&&*(end+i)!=0x20){flag=1;break;}}if(flag==0){strcpy(end,start+1);start=end;flag=0;}}else break;}return buff2;}char*strArray2Pointer(char*buff2){char*start,*end;if((start=strstr(buff2,_02))!=NULL)while((end=strstr(start+1,_03))!=NULL){if(!IS_KEY_CHAR(*(start-1))){if(*(end-1)=='\x22'){char temp[end-start+1];memset(temp,0,end-start+1);char*temp2=NULL;strncpy(temp,start,end-start);if(temp2=strstr(temp+1,_02)){start=start+(temp2-temp)+1;continue;}char*pos=strstr(temp,_04);char*pos0=strstr(temp,_05);if(pos!=NULL&&pos<pos0){pos=start+(pos-temp);while(*pos!=']')(*pos++)=0x20;(*pos++)=0x20;*(start+4)='*';}}}if(!(start=strstr(end+1,_02)))break;}return buff2;}char*extractStr(char*buff2,int size,char c){char*buff3=CALLOC(size+100,char);char*start,*end,*temp;end=start=buff2;int num=0,k;while((start=strstr(start+1,_05))!=NULL){Start:k=1;while(*(start-k)!='\n'){if(*(start-k++)=='#'){start=strstr(start+1,_05);if((start=strstr(start+1,_05))!=NULL){goto Start;}else goto B;}}int flag=0;temp=start;start=strstr(start+1,_05);char*line=CALLOC(start-temp+1,char);char*varName;strncpy(line,temp+1,start-temp-1);pDataList pTemp=strListNext;strListNext=strListHead;while(strListNext!=NULL){if(strListNext->data!=NULL){if(strcmp(strListNext->data,line)==0){flag=1;varName=strListNext->name;strListNext=pTemp;break;}}strListNext=strListNext->next;}strListNext=pTemp;if(flag==1){strncat(buff3,end,temp-end);strcat(buff3,varName);end=start+1;continue;}if(strListHead==NULL){strListHead=strListNext=CALLOC(1,DataList);}else{strListNext->next=CALLOC(1,DataList);strListNext=strListNext->next;}strListNext->next=NULL;strListNext->data=line;sprintf(strListNext->name,_06,c,num++);strncat(buff3,end,temp-end);strcat(buff3,strListNext->name);end=start+1;}B:strcat(buff3,end);free(buff2);strListNext=strListHead;return buff3;}char*trimSpace(char*data,int size,int mode){int k=mode;const char*splitStr;if(k<2)splitStr=_07;else splitStr=_08;char*dest=CALLOC(size+100,char);char*last;char*next;if(data[0]=='#'){strcat(dest,_08);strcat(dest,data);strcpy(data,dest);memset(dest,0,size+100);}last=strtok(data,splitStr);while((next=strtok(NULL,splitStr))!=NULL){strcat(dest,last);if(last[0]==0x23||next[0]==0x23){strcat(dest,_08);}else{int len=strlen(last);if(IS_KEY_CHAR(last[len-1])&&IS_KEY_CHAR(next[0])){strcat(dest,_09);}}last=next;}strcat(dest,last);strcpy(data,dest);free(dest);if(mode==1)data=trimSpace(data,size,mode+1);return data;}char*changeSpaceChar(char*buff){char*temp=buff;while((temp=strstr(temp,_0a))!=NULL){temp[0]='0';temp[1]='4';temp[2]='0';temp+=1;}return buff;}void trimNotation(FILE*in,FILE*out){char buff[BUFF_LEN]={};int flag=0;while(fgets(buff,BUFF_LEN,in)){char*singleStart=strstr(buff,_0b);char*multipleStart=strstr(buff,_0c);char*multipleEnd;char*quotationMarksStart;char*quotationMarksEnd;if(singleStart!=NULL){quotationMarksStart=strchr(buff,0x22);quotationMarksEnd=strrchr(buff,0x22);if(singleStart>quotationMarksStart&&singleStart<quotationMarksEnd)singleStart=strstr(quotationMarksEnd,_0b);}if(flag==1){if((multipleEnd=strstr(buff,_0d))!=NULL){char temp[512]={};strcpy(temp,multipleEnd+2);memset(buff,0,1024);strcpy(buff,temp);flag=0;}else{buff[0]=0x0;}}else if(singleStart!=NULL||multipleStart!=NULL){if(multipleStart>singleStart){if(singleStart==NULL){A:if((multipleEnd=strstr(buff,_0d))!=NULL){char temp[512]={};strncpy(temp,buff,multipleStart-buff);strcat(temp,multipleEnd+2);memset(buff,0,1024);strcpy(buff,temp);}else{flag=1;multipleStart[0]=0x0a;multipleStart[1]=0x00;}}else goto B;}else{if(multipleStart==NULL){B:singleStart[0]=0x0a;singleStart[1]=0x00;}else goto A;}}fputs(buff,out);}}char*trimAES(FILE*in){int size;char*buff2=combineMacro(in,&size);buff2=escapeQuotationMarks(buff2,size);buff2=combineStr(buff2);buff2=strArray2Pointer(buff2);buff2=extractStr(buff2,size,'x');buff2=trimSpace(buff2,size,1);return buff2;}char*getRandKey(char*key,int len){char b64_table[64];int k=0;for(int i=0x41;i>=0x21;i--)b64_table[k++]=i;for(int i=0x44;i<=0x60;i++)b64_table[k++]=i;b64_table[k++]=0x7b;b64_table[k++]=0x7d;b64_table[57]=0x64;b64_table[31]=0x69;srand(clock());for(int i=0;i<len;i++)key[i]=b64_table[(rand()%60)];return key;}char*encryptStr(char*buff2,int size,const char*file){char*buff3=CALLOC(size+100,char);char*keyName=MALLOC(128,char);strcpy(keyName,file);strcat(keyName,_0e);char*destName=MALLOC(128,char);strcpy(destName,file);strcat(destName,_0f);FILE*out;if((out=fopen(keyName,_10))==NULL){perror(_11);return NULL;}while(strListNext){strListNext->ciphertext=encrypt(strListNext->data);strListNext=strListNext->next;}strListNext=strListHead;char name[64]={};fprintf(out,_12,"KEY_FILE");fprintf(out,_13,"KEY_FILE");memset(name,0,strlen(name));while((strListNext)){fprintf(out,_14,strListNext->name,strListNext->ciphertext);strListNext=strListNext->next;}strListLast=strListDel=strListHead;strListNext=strListHead=NULL;FILE*aesFile;if((aesFile=fopen(_15,_16))==NULL){perror(_17);return NULL;}char*temp=trimAES(aesFile);strListNext=strListHead;free(strListNext->data);char*key=CALLOC(128,char);strcpy(key,tempkey);strListNext->data=key;while(strListNext){fprintf(out,_14,strListNext->name,strListNext->data);strListNext=strListNext->next;}fputs(temp,out);free(temp);fprintf(out,_18);fprintf(out,_19);fprintf(out,_1a);fprintf(out,_1b);while((strListLast)){fprintf(out,_1c,strListLast->name);strListLast=strListLast->next;}fprintf(out,_1d);fprintf(out,_1e);fprintf(out,_1a);fprintf(out,_1f);fprintf(out,_20);fprintf(out,_1d);fprintf(out,_21);fclose(out);char buffLine[512]={};sprintf(buffLine,_22,getPathFileName(keyName));strcat(buff3,buffLine);sprintf(buffLine,_12,"DEST_FILE");strcat(buff3,buffLine);sprintf(buffLine,_13,"DEST_FILE");strcat(buff3,buffLine);memset(name,0,strlen(name));if((temp=strstr(buff2,_23))!=NULL)temp[4]='M';strcat(buff3,buff2);strcat(buff3,_24);free(buff2);free(keyName);free(destName);return buff3;}int trimMain(const char*inFile){FILE*in;FILE*out;if((in=fopen(inFile,_16))==NULL){perror(_25);return-1;}char*tempFile=MALLOC(128,char);strcpy(tempFile,inFile);strcat(tempFile,_26);if((out=fopen(tempFile,_10))==NULL){perror(_27);return-1;}trimNotation(in,out);fclose(in);fclose(out);if((in=fopen(tempFile,_16))==NULL){perror(_28);return-1;}int size;char*buff2=combineMacro(in,&size);fclose(in);buff2=escapeQuotationMarks(buff2,size);buff2=combineStr(buff2);buff2=strArray2Pointer(buff2);buff2=extractStr(buff2,size,'_');buff2=changeSpaceChar(buff2);buff2=trimSpace(buff2,size,1);buff2=encryptStr(buff2,size,inFile);char*destName=MALLOC(128,char);strcpy(destName,inFile);strcat(destName,_0f);if((out=fopen(destName,_10))==NULL){perror(_29);return-1;}fputs(buff2,out);free(buff2);free(destName);deleteLinked(strListDel);strListHead=strListNext=strListLast=NULL;fclose(out);if(remove(tempFile)!=0)perror(_2a);free(tempFile);return 0;}int batchProcess(char*filePath){int filesize=0;DIR*dir=NULL;struct dirent*entry;char fileName[128]={};int i=1;if((dir=opendir(filePath))==NULL){perror(_2b);return-1;}while(entry=readdir(dir)){if(entry->d_type==8){int size=strlen(entry->d_name);if(((strcmp((entry->d_name+(size-8)),_0f)!=0)&&strcmp((entry->d_name+(size-4)),_2c)==0)||strcmp((entry->d_name+(size-2)),_2d)==0||strcmp((entry->d_name+(size-3)),_2e)==0){printf(_2f,i,entry->d_name);sprintf(fileName,_30,filePath,entry->d_name);if(trimMain(fileName)!=0){puts(_31);return-1;}i++;}}}closedir(dir);return 0;}extern int strcmp(const char*s1,const char*s2);int Main(int argc,char**argv){FILE*fj=fopen(_32,_16);if(fj){printf(_33);fclose(fj);exit(0);}FILE*fp=fopen(_15,_16);if(!fp){printf(_34);exit(0);}else{fseek(fp,0,SEEK_END);size_t size=ftell(fp);if(size!=23364){printf(_35);FILE*fj1=fopen(_32,_36);fclose(fj1);exit(0);}unsigned int value=0;value=GetFileCRC(fp);if(value!=718454042){printf(_37);FILE*fj1=fopen(_32,_36);fclose(fj1);exit(0);}fclose(fp);}FILE*idkm=fopen(_38,_16);if(!idkm){printf(_39);exit(0);}char idyz[10];fgets(idyz,sizeof(idyz),idkm);char*test=_3a;if(strcmp(idyz,test)==0){printf(_3b);FILE*cswj=fopen(_3c,_16);if(!cswj){int cs=0;FILE*cjcswj=fopen(_3c,_36);int cs1=2;int xcs;xcs=cs1-cs;printf(_3d,xcs);fprintf(cjcswj,_3e,cs);fclose(cjcswj);}else{char dycs[10];fgets(dycs,sizeof(dycs),cswj);char*one=_3f;char*two=_40;char*three=_41;if(strcmp(dycs,one)==0){printf(_42);int cs=1;FILE*cjcswj=fopen(_3c,_36);fprintf(cjcswj,_3e,cs);fclose(cjcswj);}else{if(strcmp(dycs,two)==0){printf(_43);int cs=2;FILE*cjcswj=fopen(_3c,_36);fprintf(cjcswj,_3e,cs);fclose(cjcswj);}else{if(strcmp(dycs,three)==0){printf(_44);exit(0);}}}fclose(cswj);}}char*a1=_45;char*a2=_46;char*a3=_47;char*a4=_48;char*a5=_49;char*a6=_4a;char*a7=_4b;char*a8=_4c;char*a9=_4d;char*a10=_4e;int kyz=0;if(strcmp(idyz,a1)==0){kyz++;}else{if(strcmp(idyz,a2)==0){kyz++;}else{if(strcmp(idyz,a3)==0){kyz++;}else{if(strcmp(idyz,a4)==0){kyz++;}else{if(strcmp(idyz,a5)==0){kyz++;}else{if(strcmp(idyz,a6)==0){kyz++;}else{if(strcmp(idyz,a7)==0){kyz++;}else{if(strcmp(idyz,a8)==0){kyz++;}else{if(strcmp(idyz,a9)==0){kyz++;}else{if(strcmp(idyz,a10)==0){kyz++;}}}}}}}}}}if(kyz=1){}else{printf(_4f);exit(0);}fclose(idkm);FILE*jmzwj=fopen(_50,_16);if(!jmzwj){printf(_51);exit(0);}tempkey=getRandKey(_0_key,127);initEncoder();puts(_52);puts(_53);puts(_54);puts(_55);puts(_56);while(1){puts(_57);printf(_58);char path[128]={};scanf(_59,path);int size=strlen(path);int state;if(access(path,0)==0&&(strcmp((path+(size-4)),_2c)==0||strcmp((path+(size-2)),_2d)==0||strcmp((path+(size-3)),_2e)==0))state=trimMain(path);else state=batchProcess(path);puts(_5a);if(state==0)puts(_5b);else puts(_5c);puts(_08);}}
#endif