package com.Firewire.box;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import static com.Firewire.box.MainActivity.*;
import static android.graphics.Typeface.BOLD;
import static android.graphics.Typeface.DEFAULT;


public class MyView extends View {
	
Paint yellow_Stack = new Paint();
	Paint green_Stack = new Paint();
	Paint number = new Paint();
	Paint fps画板 = new Paint();
    Paint 血条画笔 = new Paint();
	Paint 射线画笔 = new Paint();
	Paint 名字画笔 = new Paint();
	Paint mPaint=new Paint(),方框画笔=new Paint(),骨骼画笔=new Paint(),血量画笔=new Paint(),
    血框画笔=new Paint(),血=new Paint(),人数画笔=new Paint(),人数画笔1=new Paint(),背敌背景=new Paint(),
    背敌文字=new Paint(),骨=new Paint();
	

	
    Float x=null,y=null,w=null,h=null,hp=null;
    int state,zy,bot,m;
    String name;int hero=0;
    float tzy=0,tgd=0,sbzy=0,sbsx=0,pgzy=0,
    pgsx=0,zjzy=0,zjsx=0,yjzy=0,yjsx=0,zszzy=0,
    zszsx=0,yszzy=0,yszsx=0,zswzy=0,zswsx=0,
    yswzy=0,yswsx=0,zdtzy=0,zdtsx=0,ydtzy=0,
    ydtsx=0,zxgzy=0,zxgsx=0,yxgzy=0,yxgsx=0,
    zjwzy=0,zjwsx=0,yjwzy=0,yjwsx=0;
    float top1,top,left,bottom,right,x1;
	int k =0;
	int frames = 0;
	long startTime = 0;
	int fps =0;
	
	private int mFPS = 0;
	private int mFPSCounter = 0;
	private long mFPSTime = 0;
	int FPS = 60;
    
	private void init(){
		fps画板.setColor(Color.rgb(255, 0, 0));
        fps画板.setStrokeWidth(8);
        fps画板.setTextSize(28);
		
		血条画笔.setColor(0xFF00FF00);
        血条画笔.setStyle(Paint.Style.FILL);
        血条画笔.setAlpha(90);

		
		射线画笔.setStrokeWidth(3);
		射线画笔.setColor(0xbfffffff);
		射线画笔.setStyle(Paint.Style.STROKE);

		
		//名字画笔.setAntiAlias(true);
		名字画笔.setTextSize(28);
		//名字画笔.setFakeBoldText(true);
		名字画笔.setColor(0xffffffff);
		名字画笔.setTextAlign(Paint.Align.CENTER);
		
		mPaint.setTextSize(35);
		mPaint.setColor(0xFFFF0000);
		mPaint.setTextAlign(Paint.Align.CENTER);

        骨骼画笔.setColor(0xFFFF0000);
		骨骼画笔.setStrokeWidth(2.5f);

        方框画笔.setColor(0xEEEEEEEE);
        方框画笔.setStrokeWidth(1.4f);
        方框画笔.setStyle(Paint.Style.STROKE);
		方框画笔.setDither(true);

        血.setAntiAlias(true);
        血.setTextSize(20);
        血.setColor(0xFFFFFFFF);
		血.setTextAlign(Paint.Align.CENTER);

        血框画笔.setColor(0x5f000000);
        血框画笔.setStrokeWidth(1f);
        血框画笔.setStyle(Paint.Style.FILL);
        血框画笔.setDither(true);

        血量画笔.setColor(0xFF00FF00);
        血量画笔.setStyle(Paint.Style.FILL);
        血量画笔.setDither(true);

        人数画笔.setTextSize(40);
        人数画笔.setColor(0xFFFF0000);
        人数画笔.setTextAlign(Paint.Align.CENTER);
        人数画笔.setFakeBoldText(true);

        人数画笔1.setTextSize(40);
        人数画笔1.setColor(0xFFFFFFFF);
        人数画笔1.setStrokeWidth(5);
        人数画笔1.setTextAlign(Paint.Align.CENTER);
        人数画笔1.setStyle(Paint.Style.STROKE);
        人数画笔1.setFakeBoldText(true);

        背敌背景.setColor(0xEEEE0000);
        背敌背景.setStrokeWidth(1f);
        背敌背景.setStyle(Paint.Style.FILL);
		背敌背景.setDither(true);
        背敌背景.setAlpha(95);

        背敌文字.setTextSize(30);
        背敌文字.setColor(0xFFFFFFFF);
        背敌文字.setTextAlign(Paint.Align.CENTER);
        背敌文字.setFakeBoldText(true);
		
		yellow_Stack.setColor(0xFFFFC700);
		yellow_Stack.setStyle(Paint.Style.FILL);
		yellow_Stack.setAlpha(28);

		green_Stack.setColor(0xFF00FF00);
		green_Stack.setStyle(Paint.Style.FILL);
		green_Stack.setAlpha(28);

		number.setColor(0xC7000000);
		Typeface font = Typeface.create(Typeface.SANS_SERIF, BOLD);//加载字体
		number.setTypeface(font);
		number.setTextSize(24);
		
		
	}
	
	
	
	
    public MyView(Context context) {
		super(context);
		startTime = System.currentTimeMillis();
	}

    public MyView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }


	public static String getFileContent(File file)
	{
        String content = "";
        if (!file.isDirectory())
		{
            try
			{
                InputStream instream = new FileInputStream(file);
                if (instream != null)
				{
                    InputStreamReader inputreader
						= new InputStreamReader(instream, "UTF-8");
                    BufferedReader buffreader = new BufferedReader(inputreader);
                    String line = "";
                    while ((line = buffreader.readLine()) != null)
					{
                        content += line;
                    }
                    instream.close();//关闭输入流
                }
            }
			catch (FileNotFoundException e)
			{
            }
			catch (IOException e)
			{
            }
        }
        return content;
    }
	
	
	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		init();
        //绘制内容
		if (SystemClock.uptimeMillis() - mFPSTime > 1000) {
			mFPSTime = SystemClock.uptimeMillis();
			mFPS = mFPSCounter;
			mFPSCounter = 0;
		} else {
			mFPSCounter++;
		}
		canvas.drawText("Firewire:"+mFPS+"FPS",200,40,fps画板);
		int hero = 0;		
		float 屏幕宽=MainActivity.屏幕高;
		float 屏幕高=MainActivity.屏幕宽;
		if(Information.自瞄()){
			k++;
		//canvas.drawCircle(屏幕宽/2,屏幕高/2,Information.范围数(),射线画笔);
			RectF oval2 = new RectF(屏幕宽/2-Information.范围数(), 屏幕高/2-Information.范围数(), 屏幕宽/2+Information.范围数(),屏幕高/2+Information.范围数()); 
			canvas.drawArc(oval2, (k + 45) * -1, 60, false, 射线画笔);
			canvas.drawArc(oval2, (k + 90 + 45) * -1, 60, false, 射线画笔);
			canvas.drawArc(oval2, (k + 180 + 45) * -1, 60, false, 射线画笔);
			canvas.drawArc(oval2, (k + 270 + 45) * -1, 60, false, 射线画笔);
			
		}
		
		
		
		File file = new File("/storage/emulated/0/b.log");//坐标输出必须和cpp的路径一致
		String fileContent = getFileContent(file);
		String[] split = fileContent.split(";");
		for (int i = 0; i < split.length; i++)
		{
			String[] 获取数据 = split[i].split(",");
			try
			{
				x = Float.parseFloat(获取数据[0]);
				y = Float.parseFloat(获取数据[1]);
				w = Float.parseFloat(获取数据[2]);
				h = Float.parseFloat(获取数据[3]);
				m = Integer.parseInt(获取数据[4]);
				hp = Float.parseFloat(获取数据[5]);
				bot = Integer.parseInt(获取数据[6]);
				zy = Integer.parseInt(获取数据[7]);
				name = (获取数据[8]);
				state = Integer.parseInt(获取数据[9]);
				tzy = Float.parseFloat(获取数据[10]);//骨骼头左右
				tgd = Float.parseFloat(获取数据[11]);//骨骼头高度 
				sbzy = Float.parseFloat(获取数据[12]);//骨骼胸部左右
				sbsx = Float.parseFloat(获取数据[13]);//骨骼胸部上下
				pgzy = Float.parseFloat(获取数据[14]);//骨骼盆骨左右
				pgsx = Float.parseFloat(获取数据[15]);//骨骼盆骨上下
				zjzy = Float.parseFloat(获取数据[16]);//骨骼左肩左右
				zjsx = Float.parseFloat(获取数据[17]);//骨骼左肩上下
				yjzy = Float.parseFloat(获取数据[18]);//骨骼右肩左右
				yjsx = Float.parseFloat(获取数据[19]);//骨骼右肩上下
				zszzy = Float.parseFloat(获取数据[20]);//骨骼左手肘左右
				zszsx = Float.parseFloat(获取数据[21]);//骨骼左手肘上下
				yszzy = Float.parseFloat(获取数据[22]);//骨骼右手肘左右
				yszsx = Float.parseFloat(获取数据[23]);//骨骼右手肘上下
				zswzy = Float.parseFloat(获取数据[24]);//骨骼左手腕左右
				zswsx = Float.parseFloat(获取数据[25]);//骨骼左手腕上下
				yswzy = Float.parseFloat(获取数据[26]);//骨骼右手腕左右
				yswsx = Float.parseFloat(获取数据[27]);//骨骼右手腕上下
				zdtzy = Float.parseFloat(获取数据[28]);//骨骼左大腿左右
				zdtsx = Float.parseFloat(获取数据[29]);//骨骼左大腿上下
				ydtzy = Float.parseFloat(获取数据[30]);//骨骼右大腿左右
				ydtsx = Float.parseFloat(获取数据[31]);//骨骼右大腿上下
				zxgzy = Float.parseFloat(获取数据[32]);//骨骼左膝盖左右
				zxgsx = Float.parseFloat(获取数据[33]);//骨骼左膝盖上下
				yxgzy = Float.parseFloat(获取数据[34]);//骨骼右膝盖左右
				yxgsx = Float.parseFloat(获取数据[35]);//骨骼右膝盖上下
				zjwzy = Float.parseFloat(获取数据[36]);//骨骼左脚腕左右
				zjwsx = Float.parseFloat(获取数据[37]);//骨骼左脚腕上下
				yjwzy = Float.parseFloat(获取数据[38]);//骨骼右脚腕左右
				yjwsx = Float.parseFloat(获取数据[39]);//骨骼右脚腕上下
				
			}
			catch (Exception v)
			{
				v.printStackTrace();
			}
		   
			hero=hero + 1;
			
			if (x != null && y != null && w != null && h != null) {
				
				
			
			if(Information.信息()){
				if (x + (w / 2) < 0) {//左
					canvas.drawRoundRect(0, y - 30, 90, y + 30, 15, 15, 背敌背景);
					canvas.drawText(m + "m", 45, y + 12, 背敌文字);
				} else if (x - (w / 2) > 2400) {//右
					canvas.drawRoundRect(2400 - 90, y - 30, 2400, y + 30, 15, 15, 背敌背景);
					canvas.drawText(m + "m", 2400 - 45, y + 12, 背敌文字);
				} else if (y - w < 0) {//上
					canvas.drawRoundRect(x - 45, 0, x + 45, 60, 15, 15, 背敌背景);
					canvas.drawText(m + "m", x, 39, 背敌文字);
				} else if (x > 0 && x < 2400 && y > 0 && y < 1080 && w > 0) {
					if (zy > 0 && zy < 100) {
					}
					top1 = pgsx - tgd;
					top = pgsx - top1 - w / 6;
					if (zjwsx < yjwsx) {
						bottom = yjwsx + w / 10;
					} else {
						bottom = zjwsx + w / 10;
					}
					
					left = (x + w / 2) - w / 2.4f;
					right = x + w / 1.1f;
					x1 = (x + w / 2);
					canvas.drawRect(x1 - 50, top - 10, x1 + 50, top - 15, 血框画笔);
					canvas.drawRect(x1 - 50, top - 10, x1 - 50 + (50 * 2 / 100) * hp, top - 15, 血量画笔);
					if (bot == 1) {
						canvas.drawText("" + name, x1, top - 23, mPaint);
					} else {
						canvas.drawText("bot", x1, top - 23, 血);
					}
					canvas.drawText("T:" + zy, x1, bottom + 22, 血);
					canvas.drawText(m + "m", x1, bottom + 43, 血);
					canvas.drawLine(2400 / 2, 100, x1, top, 方框画笔);
					canvas.drawRect(left, top, right, bottom, 方框画笔);
					canvas.drawCircle(tzy, tgd, h / 20, 骨骼画笔);
					}
					}
					}
					}
		
			
	   
		if (hero > 0)
		{
			
			
		}
		
	
		//自动刷新
        this.invalidate();
     
		}
	

	

}
