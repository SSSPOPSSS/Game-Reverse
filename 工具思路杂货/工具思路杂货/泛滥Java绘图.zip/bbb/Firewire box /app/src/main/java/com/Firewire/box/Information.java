package com.Firewire.box;

public class Information {
    public static boolean 绘制开关=false,自瞄开关=false,方框开关=false,信息开关=false,射线开关=false;
	public static int 范围;
	public static boolean 绘制(){
		return 绘制开关;
	}
	public static boolean 自瞄(){
		return 自瞄开关;
	}
	public static boolean 方框(){
		return 方框开关;
	}
	public static boolean 信息(){
		return 信息开关;
	}
	public static boolean 射线(){
		return 射线开关;
	}
	public static int 范围数(){
		return 范围;
	}
}
