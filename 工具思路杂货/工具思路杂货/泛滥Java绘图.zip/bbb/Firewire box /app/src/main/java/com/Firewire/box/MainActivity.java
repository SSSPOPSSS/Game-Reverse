package com.Firewire.box;
 
import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.Toast;
import com.Firewire.box.madapter.MAdapter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;

public class MainActivity extends Activity { 


	private boolean 是否已经打开悬浮窗=false;
	private ImageButton mbutton;
	private boolean 悬浮球 = false;
	private boolean 悬浮窗 = false;
	private int mTouchStartX, mTouchStartY;//手指按下时坐标
	private int 按下X, 按下Y;
    private boolean isMove = false;
	private boolean 移动=false;
	private WindowManager mwindow;
	private WindowManager.LayoutParams lparam;
	private WindowManager mwMenu;
	private WindowManager.LayoutParams mparam;
	private LayoutInflater inflater;
	private View dis;
	private View displayMenu;
    static int  屏幕宽,屏幕高;
	private Switch 开启绘制,自瞄;
	private CheckBox 方框,信息,射线;
	private boolean 绘制按钮,自瞄按钮,方框按钮,信息按钮,射线按钮;
	private static int 范围;

	public static ServerSocket server = null;
    public static Socket soket = null;
    public static String state = "";
	
	private void 初始化() {
        new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        server = new ServerSocket(8192);
                        state = "socket连接SharpShooter服务器";
                        监听();
                    } catch (IOException e) {
                        state = "socket连接失败";
                        e.printStackTrace();
                    }
                }
            }).start();
    }

    private boolean islink = false;
    private void 监听() {
        while (!server.isClosed()) {
            try {
                soket = server.accept();
                state = "已连接SharpShooter服务器";
                islink = true;
                读取();
            } catch (IOException e) {
                state = "连接SharpShooter服务器失败";
                e.printStackTrace();
            }
        }
    }
	
    public InputStream input;
    public OutputStream output;
    private void 发送(final byte[] data) {
        new Thread(new Runnable() {
                @Override
                public void run() {
                    if (soket != null && soket.isConnected() && output != null) {
                        try {
                            output.write(data);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }).start();
    }

    //读取数据
    public static int len = 0;
    public static byte[] buf = new byte[8192];
    public static String 读取数据 = "";
    private List<MAdapter.Data> lists = null;
    private static Long stopTs = 0L;
    private static Long startTs = 0L;
    private boolean isStart = false;

    private void 读取()
    {
        new Thread(new Runnable() {
                @Override
                public void run()
                {
                    try
                    {
                        /*客户端上的使用

                         1.getInputStream方法可以得到一个输入流，客户端的Socket对象上的getInputStream方法得到输入流其实就是从服务器端发回的数据。

                         2.getOutputStream方法得到的是一个输出流，客户端的Socket对象上的getOutputStream方法得到的输出流其实就是发送给服务器端的数据。

                         服务器端上的使用

                         1.getInputStream方法得到的是一个输入流，服务端的Socket对象上的getInputStream方法得到的输入流其实就是从客户端发送给服务器端的数据流。

                         2.getOutputStream方法得到的是一个输出流，服务端的Socket对象上的getOutputStream方法得到的输出流其实就是发送给客户端的数据。
                         */
                        input = soket.getInputStream();
                        output = soket.getOutputStream();
                        //只要不中断则循环
                        while (soket.isConnected())
                        {
                            len = input.read(buf);
                            //判断读取到底数据小于0就跳出循环
                            if (len <= 0)
                            {
                                input.close();
                                output.close();
                                soket.close();
                                读取数据 = "";
                                监听();
                                break;
                            }
                            byte[] str = new byte[len];
                            System.arraycopy(buf, 0, str, 0, len);
                            读取数据 = new String(str);
                            if (len == 7)
                            {
                                if ("INIT_OK".equals(读取数据))
                                {
                                    state = "已连接socket";
                                }
                                else if ("INIT_NO".equals(读取数据))
                                {
                                    state = "已断开socket连接";
                                }
                                for (int i = 1; i < lists.size(); i++)
                                {
                                    lists.get(i).setEnable(true);
                                }
                                更新列表();
                            }
                            else
                            {
                                stopTs = System.currentTimeMillis();
                                state = "FPS：" + (stopTs - startTs) + "ms";
                                startTs = stopTs;
                            }
                        }
                        islink = false;
                        for (int i = 1; i < lists.size(); i++)
                        {
                            lists.get(i).setEnable(false);
                            lists.get(0).setIsche(false);
                        }
                        if (!state.equals("连接SharpShooter服务器失败"))
                        {
                            if (isStart)
                            {
                                isStart = false;
                                state = "socket连接异常";
                            }
                            else
                            {
                                state = "连接SharpShooter服务器";
                            }
                        }
                        更新列表();
                    }
                    catch (IOException e)
                    {
                        state = "连接SharpShooter失败";
                        e.printStackTrace();
                    }
                }
            }).start();
    }
    private MAdapter madapter;
    private void 更新列表()
    {
        runOnUiThread(new Runnable() {
                @Override
                public void run()
                {
                    if (madapter != null)
                    {
                        madapter.notifyDataSetChanged();
                    }
                }
            });
    }

	
	
	public static boolean 网络检测(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        if (info != null) {
            return info.isConnected();
        } else {
            return false;
        }
    }
	/*******************悬浮窗权限**********/
	public void 检查悬浮窗权限()
	{
		if (!Settings.canDrawOverlays(this))//如果不可以绘制悬浮窗
		{
			Toast.makeText(this, "请开启悬浮窗权限", Toast.LENGTH_LONG).show();
			startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())), 0);
		}
	}
	/*******************状态栏美化**********/
	public void 状态栏(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            //透明状态栏
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            //透明导航栏
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
			//状态栏
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
	}
	/*******************存储权限**********/
	public void 储存权限(){
		boolean isGranted = true;
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            if (this.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                isGranted = false;
            }
            if (this.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                isGranted = false;
            }
			if (!isGranted) {
                this.requestPermissions(
                    new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission
                        .ACCESS_FINE_LOCATION,
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    102);
            }
        }
	}
	/*******************分辨率获取**********/
	public void 分辨率()
	{
		WindowManager windowManager = (WindowManager)this.getSystemService(WINDOW_SERVICE);
		Display display = windowManager.getDefaultDisplay();
		Point outPoint = new Point();
		display.getRealSize(outPoint);
		屏幕宽 = outPoint.x;
		屏幕高 = outPoint.y;
		写入("/sdcard/y",String.valueOf(屏幕宽));
		写入("/sdcard/x",String.valueOf(屏幕高));
	}

	
	/*******************su执行**********/
	private void 执行(String shell)
    {
        String s=shell;
        try
        {
            Runtime.getRuntime().exec(s,null,null);//执行
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
	/*******************文件写入**********/
	public static void 写入(String 路径,String 内容){
        try {
            FileWriter fw = new FileWriter(路径);
            fw.write(内容);
            fw.close();
        } catch (IOException e) {}
    }
    public static void 创建(String 路径){

        File dir=new File(路径); 
        if(!dir.exists()) dir.mkdir();

    }
    
    
    
		
	/*******************文件夹创建**********/
	public static void 创建文件夹(String path) {
        //新建一个File，传入文件夹目录
        File file = new File(path);
        //判断文件夹是否存在，如果不存在就创建，否则不创建
        if (!file.exists()) {
            //通过file的mkdirs()方法创建目录中包含却不存在的文件夹
            file.mkdirs();
        }

    }
	/*******************初始化**********/
	
	
	
	/*******************读取文件**********/
	public static String 读取文件(String path)

    {

        String str="";

        File file=new File(path);

        try {

            FileInputStream in=new FileInputStream(file);

            // size  为字串的长度 ，这里一次性读完

            int size=in.available();

            byte[] buffer=new byte[size];

            in.read(buffer);

            in.close();

            str=new String(buffer,"GB2312");

        } catch (IOException e) {

            e.printStackTrace();

        }

        return str;


    }

	public boolean deleteFile(String filePath) {
		File file = new File(filePath);
        if (file.isFile() && file.exists()) {
			return file.delete();
        }
        return false;
    }

 
	
	public static boolean 写出assets资源文件(Context context, String outPath, String fileName) {
        File file = new File(outPath);
        if (!file.exists()) {
            if (!file.mkdirs()) {
                Log.e("--Method--", "copyAssetsSingleFile: cannot create directory.");
                return false;
            }
        }
        try {
            InputStream inputStream = context.getAssets().open(fileName);
            File outFile = new File(file, fileName);
            FileOutputStream fileOutputStream = new FileOutputStream(outFile);
            // Transfer bytes from inputStream to fileOutputStream
            byte[] buffer = new byte[1024];
            int byteRead;
            while (-1 != (byteRead = inputStream.read(buffer))) {
                fileOutputStream.write(buffer, 0, byteRead);
            }
            inputStream.close();
            fileOutputStream.flush();
            fileOutputStream.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
	
	
	private void 循环(){
        for(int i = 0; i < 3;i++){
            String s2 = String.valueOf(i);
            写出assets资源文件(this, getCacheDir() + "/qq1522348911",s2);    
			执行("chmod 777 "+getCacheDir() + "/qq1522348911/"+s2);
            写出assets资源文件(this, getCacheDir() + "/qq1522348911","250.png");    
			执行("chmod 777 "+getCacheDir() + "/qq1522348911/250.png");
			}
		写出assets资源文件(this, "/sdcard/","3");   
    }
	
	private void 小米无限制(){
		PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
		boolean hasIgnored = powerManager.isIgnoringBatteryOptimizations(this.getPackageName());
		if (!hasIgnored) {
			Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
			intent.setData(Uri.parse("package:" + this.getPackageName()));
			startActivity(intent);
			Toast.makeText(getApplication(), "请选择无限制", Toast.LENGTH_SHORT).show();
		}
	}
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		inflater = inflater.from(this);	
		执行("su");
	    检查悬浮窗权限();
		储存权限();
		分辨率();
		开启悬浮窗();
		初始化();
		循环();
		小米无限制();
		
		}
	

	/*******************悬浮窗**********/
	private void 开启悬浮窗()
	{
		mwindow = (WindowManager)getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
		lparam = new WindowManager.LayoutParams();
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
		{
            lparam.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }
		else
		{
            lparam.type = WindowManager.LayoutParams.TYPE_PHONE;
        }
		if (Settings.canDrawOverlays(this))
		{
			mbutton = new ImageButton(getApplicationContext());
			mbutton.setBackgroundResource(R.drawable.ic_launcher);///悬浮球的图片
			mbutton.setOnTouchListener(new OnTouchListener() 
				{
					@Override
					public boolean onTouch(View v, MotionEvent event) 
					{
						switch (event.getAction()) 
						{
							case MotionEvent.ACTION_DOWN:
								isMove = false;
								mTouchStartX = (int) event.getRawX();
								mTouchStartY = (int) event.getRawY();
								break;
							case MotionEvent.ACTION_MOVE:
								int nowX = (int) event.getRawX();
								int nowY = (int) event.getRawY();
								int movedX = nowX - mTouchStartX;
								int movedY = nowY - mTouchStartY;
								if (movedX > 5 || movedY > 5)
								{
									isMove = true;
								}
								mTouchStartX = nowX;
								mTouchStartY = nowY;
								lparam.x += movedX;
								lparam.y += movedY;
								mwindow.updateViewLayout(mbutton, lparam);
								break;
							case MotionEvent.ACTION_UP:
								break;
							case MotionEvent.ACTION_CANCEL:
								break;
						}
					    return isMove;
					}
				});
			mbutton.setOnClickListener(new OnClickListener()//悬浮球的单击事件
				{
					@Override
					public void onClick(View v)
					{
						加载窗口();//加载悬浮窗
						悬浮窗 = true;
						mwindow.removeView(mbutton);//关闭悬浮球
						悬浮球 = false;
					}
				});
			lparam.format = PixelFormat.RGBA_8888;
			lparam.gravity = Gravity.LEFT;
			lparam.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
			lparam.width = 120;
			//宽度
			lparam.height = 120;
			//高度
			if (mparam == null)
			{
				lparam.x = 300;//悬浮球起始x
				lparam.y = 0;//悬浮球起始y
			}
			else
			{
				lparam.x = mparam.x;
				lparam.y = mparam.y;//y
			}
			mwindow.addView(mbutton, lparam);//加载悬浮球
			悬浮球 = true;
		}
		else
		{
			Toast.makeText(this, "开启失败", Toast.LENGTH_LONG).show();
		}
		是否已经打开悬浮窗=true;
	}

	private void 加载窗口()
	{
		mwMenu = (WindowManager)getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
		mparam = new WindowManager.LayoutParams();
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
		{
            mparam.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }
		else
		{
            mparam.type = WindowManager.LayoutParams.TYPE_PHONE;
        }
		displayMenu = inflater.inflate(R.layout.SuspendedActivity, null);
		dis = displayMenu.findViewById(R.id.ZLinearLayout1);
		mparam.format = PixelFormat.RGBA_8888;
		mparam.gravity = Gravity.CENTER;
		mparam.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
		mparam.width = WindowManager.LayoutParams.WRAP_CONTENT;
		//宽度
		mparam.height = WindowManager.LayoutParams.WRAP_CONTENT;
		//高度
		mparam.x = 0;//x
		mparam.y = 0;//y
		mwMenu.addView(dis, mparam);

		//悬浮窗长按监听
		LinearLayout ll1=displayMenu.findViewById(R.id.ZLinearLayout1);
		ll1.setOnTouchListener(new OnTouchListener() 
			{
			    @Override
				public boolean onTouch(View v, MotionEvent event) 
				{
				    switch (event.getAction()) 
					{
					    case MotionEvent.ACTION_DOWN://单击
						    移动 = false;
						    按下X = (int) event.getRawX();
						    按下Y = (int) event.getRawY();
						    break;
						case MotionEvent.ACTION_MOVE://拖动
						    int nowX = (int) event.getRawX();
							int nowY = (int) event.getRawY();
							int movedX = nowX - 按下X;
							int movedY = nowY - 按下Y;
							if (movedX > 5 || movedY > 5)
							{
							    移动 = true;
				            }
					        按下X = nowX;
					        按下Y = nowY;
					        lparam.x += movedX;
					        lparam.y += movedY;
					        mwindow.updateViewLayout(displayMenu, mparam);
					        break;
					    case MotionEvent.ACTION_UP://抬起
						    break;
						case MotionEvent.ACTION_CANCEL:
						    break;
					}
					return 移动;
				}
			});
			
		Button 悬浮窗关闭=displayMenu.findViewById(R.id.关闭悬浮窗);
		开启绘制=displayMenu.findViewById(R.id.绘制);
		自瞄=displayMenu.findViewById(R.id.自瞄);
		方框=displayMenu.findViewById(R.id.方框);
		信息=displayMenu.findViewById(R.id.信息);
		射线=displayMenu.findViewById(R.id.射线);
		final SeekBar 自瞄范围 = displayMenu.findViewById(R.id.自瞄范围);
		

        开启绘制.setChecked(绘制按钮);
		自瞄.setChecked(自瞄按钮);
		方框.setChecked(方框按钮);
		信息.setChecked(信息按钮);
		射线.setChecked(射线按钮);
		
		开启绘制.setOnCheckedChangeListener(new QQ1522348911());
		自瞄.setOnCheckedChangeListener(new QQ1522348911());
		方框.setOnCheckedChangeListener(new QQ1522348911());
        信息.setOnCheckedChangeListener(new QQ1522348911());
        射线.setOnCheckedChangeListener(new QQ1522348911());
		
		自瞄范围.setProgress(Information.范围数());
		
		悬浮窗关闭.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v)
				{
					开启悬浮窗();//显示主悬浮窗
					mwMenu.removeView(dis);//移除菜单
					悬浮窗 = false;//菜单状态
				}
			});
		自瞄范围.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {}
                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {}

                //拖动
                @Override
                public void onProgressChanged(SeekBar seekBar,int progress, boolean fromUser) {
                   Information.范围 =  自瞄范围.getProgress();
				   写入("/sdcard/Firewire/fw.log",""+Information.范围);
                }
            });
			
			
}
	class QQ1522348911 implements OnCheckedChangeListener
	{

		@Override
		public void onCheckedChanged(CompoundButton p1, boolean isChecked)
		{

			switch(p1.getId())
			{

				case R.id.绘制:
					{

						if (isChecked)
						{
							deleteFile("/sdcard/stop.txt");
							写入("/sdcard/b.log","");
							执行(getCacheDir()+"/qq1522348911/250.png");
								
                            执行("su -c " + getCacheDir()+"/qq1522348911/250.png");	
							FloatService.ShowFloat(MainActivity.this);
							Toast.makeText(MainActivity.this,"注入绘制",Toast.LENGTH_LONG).show();
							绘制按钮=true;
							Information.绘制开关 = true;

						} 
						else
						{
							绘制按钮=false;
							写入("/sdcard/stop.txt","");
							FloatService.HideFloat();
							Toast.makeText(MainActivity.this,"关闭绘制",Toast.LENGTH_LONG).show();
							Information.绘制开关 = false;
							
						}
					}
					break;
				case R.id.自瞄:
					{

						if (isChecked)
						{
							执行("sh /sdcard/3");
							deleteFile("/sdcard/自瞄关");
							执行(getCacheDir()+"/qq1522348911/2");
							执行("su -c " + getCacheDir()+"/qq1522348911/2");	
							Toast.makeText(MainActivity.this,"注入自瞄",Toast.LENGTH_LONG).show();
							自瞄按钮=true;
							Information.自瞄开关 = true;

						} 
						else
						{
							写入("/sdcard/自瞄关","");
							自瞄按钮=false;
							Toast.makeText(MainActivity.this,"关闭自瞄",Toast.LENGTH_LONG).show();
							Information.自瞄开关 = false;

						}
					}
					break;
				case R.id.方框:
					{

						if (isChecked)
						{
							方框按钮=true;
							Information.方框开关 = true;
						} 
						else
						{
							方框按钮=false;
							Information.方框开关 = false;
						}
					}
					break;
				case R.id.信息:
					{

						if (isChecked)
						{
							信息按钮=true;
							Information.信息开关 = true;
						} 
						else
						{
							信息按钮=false;
							Information.信息开关 = false;
						}
					}
					break;
				case R.id.射线:
					{

						if (isChecked)
						{
							射线按钮=true;
							Information.射线开关 = true;
						} 
						else
						{
							射线按钮=false;
							Information.射线开关 = false;
						}
					}
					break;
			}//上面为控件
			}}

}
