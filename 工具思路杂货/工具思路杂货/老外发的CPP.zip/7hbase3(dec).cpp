int __cdecl main(int argc, const char **argv, const char **envp)
{
  __int64 v3; // x0
  char v5; // [xsp+20h] [xbp+20h]
  char v6; // [xsp+60h] [xbp+60h]
  char v7; // [xsp+C8h] [xbp+C8h]
  char v8; // [xsp+130h] [xbp+130h]
  __int64 v9; // [xsp+140h] [xbp+140h]
  int v10; // [xsp+148h] [xbp+148h]
  int v11; // [xsp+14Ch] [xbp+14Ch]

  v11 = atoi(argv[1]);
  if ( (unsigned int)isapkrunning("com.tencent.ig") == 1 )
  {
    v3 = ((__int64 (__fastcall *)(char *, const char *))sprintf)(&v6, "com.tencent.ig");
  }
  else if ( (unsigned int)isapkrunning("com.vng.pubgmobile") == 1 )
  {
    v3 = ((__int64 (__fastcall *)(char *, const char *))sprintf)(&v6, "com.vng.pubgmobile");
  }
  else if ( (unsigned int)isapkrunning("com.pubg.krmobile") == 1 )
  {
    v3 = ((__int64 (__fastcall *)(char *, const char *))sprintf)(&v6, "com.pubg.krmobile");
  }
  else if ( (unsigned int)isapkrunning("com.pubg.imobile") == 1 )
  {
    v3 = ((__int64 (__fastcall *)(char *, const char *))sprintf)(&v6, "com.pubg.imobile");
  }
  else if ( (unsigned int)isapkrunning("com.rekoo.pubgm") == 1 )
  {
    v3 = ((__int64 (__fastcall *)(char *, const char *))sprintf)(&v6, "com.rekoo.pubgm");
  }
  else
  {
    v3 = puts("PUBGM not running");
  }
  if ( (unsigned int)getuid(v3) == 0 )
    ((void (__fastcall *)(char *, const char *))sprintf)(&v7, "MODE_ROOT");
  else
    ((void (__fastcall *)(char *, const char *))sprintf)(&v7, "MODE_NO_ROOT");
  v10 = getPID(&v6);
  sprintf(&v5, "/proc/%d/mem");
  handle = open(&v5, 2LL);
  if ( handle == -1 )
  {
    puts("Gagal mendapatkan memory!\n");
    exit(1LL);
  }
  strcpy(&v8, "libUE4.so");
  v9 = get_module_base(v10, &v8);
  initXMemoryTools(&v6, &v7);
  if ( v11 == 9663 )
  {
    SetSearchRange(9);
    MemorySearch("1102851477", 0);
    MemoryOffset("1431681986", -8LL, 0);
    MemoryWrite("1120403456", 0LL, 0);
    MemorySearch("963608576", 0);
    MemoryOffset("2050064359", 12LL, 0);
    MemoryWrite("1128792064", 0LL, 0);
  }
  else if ( v11 <= 9663 )
  {
    if ( v11 == 9641 )
    {
      XA_BaseAddress_FLOAT(v9 + 31949668, 90.0);
    }
    else if ( v11 <= 9641 )
    {
      if ( v11 == 9273 )
      {
        XA_BaseAddress_DWORD(v9 + 65426768, 0);
      }
      else if ( v11 <= 9273 )
      {
        if ( v11 == 7442 )
        {
          SetSearchRange(9);
          MemorySearch("2.6562681e20", 1);
          MemoryOffset("999906560", -76LL, 1);
          MemoryWrite("2.65628006e20", 0LL, 1);
        }
        else if ( v11 <= 7442 )
        {
          if ( v11 == 7390 )
          {
            SetSearchRange(9);
            MemorySearch("1.40129846e-45", 1);
            MemoryOffset("45", -4LL, 1);
            MemoryOffset("45", -8LL, 1);
            MemoryOffset("135", 52LL, 1);
            MemoryOffset("135", 56LL, 1);
            MemoryOffset("225", 112LL, 1);
            MemoryOffset("225", 116LL, 1);
            MemoryOffset("315", 172LL, 1);
            MemoryOffset("315", 176LL, 1);
            MemoryWrite("200", -36LL, 1);
            MemoryWrite("200", 24LL, 1);
            MemoryWrite("200", 84LL, 1);
            MemoryWrite("200", 144LL, 1);
          }
          else if ( v11 <= 7390 )
          {
            if ( v11 == 7389 )
            {
              SetSearchRange(9);
              MemorySearch("1.40129846e-45", 1);
              MemoryOffset("45", -4LL, 1);
              MemoryOffset("45", -8LL, 1);
              MemoryOffset("135", 52LL, 1);
              MemoryOffset("135", 56LL, 1);
              MemoryOffset("225", 112LL, 1);
              MemoryOffset("225", 116LL, 1);
              MemoryOffset("315", 172LL, 1);
              MemoryOffset("315", 176LL, 1);
              MemoryWrite("100", -36LL, 1);
              MemoryWrite("100", 24LL, 1);
              MemoryWrite("100", 84LL, 1);
              MemoryWrite("100", 144LL, 1);
            }
            else if ( v11 <= 7389 )
            {
              if ( v11 == 7388 )
              {
                SetSearchRange(9);
                MemorySearch("1.40129846e-45", 1);
                MemoryOffset("45", -4LL, 1);
                MemoryOffset("45", -8LL, 1);
                MemoryOffset("135", 52LL, 1);
                MemoryOffset("135", 56LL, 1);
                MemoryOffset("225", 112LL, 1);
                MemoryOffset("225", 116LL, 1);
                MemoryOffset("315", 172LL, 1);
                MemoryOffset("315", 176LL, 1);
                MemoryWrite("90", -36LL, 1);
                MemoryWrite("90", 24LL, 1);
                MemoryWrite("90", 84LL, 1);
                MemoryWrite("90", 144LL, 1);
              }
              else if ( v11 <= 7388 )
              {
                if ( v11 == 7387 )
                {
                  SetSearchRange(9);
                  MemorySearch("1.40129846e-45", 1);
                  MemoryOffset("45", -4LL, 1);
                  MemoryOffset("45", -8LL, 1);
                  MemoryOffset("135", 52LL, 1);
                  MemoryOffset("135", 56LL, 1);
                  MemoryOffset("225", 112LL, 1);
                  MemoryOffset("225", 116LL, 1);
                  MemoryOffset("315", 172LL, 1);
                  MemoryOffset("315", 176LL, 1);
                  MemoryWrite("80", -36LL, 1);
                  MemoryWrite("80", 24LL, 1);
                  MemoryWrite("80", 84LL, 1);
                  MemoryWrite("80", 144LL, 1);
                }
                else if ( v11 <= 7387 )
                {
                  if ( v11 == 7386 )
                  {
                    SetSearchRange(9);
                    MemorySearch("1.40129846e-45", 1);
                    MemoryOffset("45", -4LL, 1);
                    MemoryOffset("45", -8LL, 1);
                    MemoryOffset("135", 52LL, 1);
                    MemoryOffset("135", 56LL, 1);
                    MemoryOffset("225", 112LL, 1);
                    MemoryOffset("225", 116LL, 1);
                    MemoryOffset("315", 172LL, 1);
                    MemoryOffset("315", 176LL, 1);
                    MemoryWrite("70", -36LL, 1);
                    MemoryWrite("70", 24LL, 1);
                    MemoryWrite("70", 84LL, 1);
                    MemoryWrite("70", 144LL, 1);
                  }
                  else if ( v11 <= 7386 )
                  {
                    if ( v11 == 7385 )
                    {
                      SetSearchRange(9);
                      MemorySearch("1.40129846e-45", 1);
                      MemoryOffset("45", -4LL, 1);
                      MemoryOffset("45", -8LL, 1);
                      MemoryOffset("135", 52LL, 1);
                      MemoryOffset("135", 56LL, 1);
                      MemoryOffset("225", 112LL, 1);
                      MemoryOffset("225", 116LL, 1);
                      MemoryOffset("315", 172LL, 1);
                      MemoryOffset("315", 176LL, 1);
                      MemoryWrite("60", -36LL, 1);
                      MemoryWrite("60", 24LL, 1);
                      MemoryWrite("60", 84LL, 1);
                      MemoryWrite("60", 144LL, 1);
                    }
                    else if ( v11 <= 7385 )
                    {
                      if ( v11 == 7384 )
                      {
                        SetSearchRange(9);
                        MemorySearch("1.40129846e-45", 1);
                        MemoryOffset("45", -4LL, 1);
                        MemoryOffset("45", -8LL, 1);
                        MemoryOffset("135", 52LL, 1);
                        MemoryOffset("135", 56LL, 1);
                        MemoryOffset("225", 112LL, 1);
                        MemoryOffset("225", 116LL, 1);
                        MemoryOffset("315", 172LL, 1);
                        MemoryOffset("315", 176LL, 1);
                        MemoryWrite("50", -36LL, 1);
                        MemoryWrite("50", 24LL, 1);
                        MemoryWrite("50", 84LL, 1);
                        MemoryWrite("50", 144LL, 1);
                      }
                      else if ( v11 <= 7384 )
                      {
                        if ( v11 == 7383 )
                        {
                          SetSearchRange(9);
                          MemorySearch("1.40129846e-45", 1);
                          MemoryOffset("45", -4LL, 1);
                          MemoryOffset("45", -8LL, 1);
                          MemoryOffset("135", 52LL, 1);
                          MemoryOffset("135", 56LL, 1);
                          MemoryOffset("225", 112LL, 1);
                          MemoryOffset("225", 116LL, 1);
                          MemoryOffset("315", 172LL, 1);
                          MemoryOffset("315", 176LL, 1);
                          MemoryWrite("40", -36LL, 1);
                          MemoryWrite("40", 24LL, 1);
                          MemoryWrite("40", 84LL, 1);
                          MemoryWrite("40", 144LL, 1);
                        }
                        else if ( v11 <= 7383 )
                        {
                          if ( v11 == 7382 )
                          {
                            SetSearchRange(9);
                            MemorySearch("1.40129846e-45", 1);
                            MemoryOffset("45", -4LL, 1);
                            MemoryOffset("45", -8LL, 1);
                            MemoryOffset("135", 52LL, 1);
                            MemoryOffset("135", 56LL, 1);
                            MemoryOffset("225", 112LL, 1);
                            MemoryOffset("225", 116LL, 1);
                            MemoryOffset("315", 172LL, 1);
                            MemoryOffset("315", 176LL, 1);
                            MemoryWrite("30", -36LL, 1);
                            MemoryWrite("30", 24LL, 1);
                            MemoryWrite("30", 84LL, 1);
                            MemoryWrite("30", 144LL, 1);
                          }
                          else if ( v11 <= 7382 )
                          {
                            if ( v11 == 7381 )
                            {
                              SetSearchRange(9);
                              MemorySearch("1.40129846e-45", 1);
                              MemoryOffset("45", -4LL, 1);
                              MemoryOffset("45", -8LL, 1);
                              MemoryOffset("135", 52LL, 1);
                              MemoryOffset("135", 56LL, 1);
                              MemoryOffset("225", 112LL, 1);
                              MemoryOffset("225", 116LL, 1);
                              MemoryOffset("315", 172LL, 1);
                              MemoryOffset("315", 176LL, 1);
                              MemoryWrite("20", -36LL, 1);
                              MemoryWrite("20", 24LL, 1);
                              MemoryWrite("20", 84LL, 1);
                              MemoryWrite("20", 144LL, 1);
                            }
                            else if ( v11 <= 7381 )
                            {
                              if ( v11 == 7380 )
                              {
                                SetSearchRange(9);
                                MemorySearch("1.40129846e-45", 1);
                                MemoryOffset("45", -4LL, 1);
                                MemoryOffset("45", -8LL, 1);
                                MemoryOffset("135", 52LL, 1);
                                MemoryOffset("135", 56LL, 1);
                                MemoryOffset("225", 112LL, 1);
                                MemoryOffset("225", 116LL, 1);
                                MemoryOffset("315", 172LL, 1);
                                MemoryOffset("315", 176LL, 1);
                                MemoryWrite("10", -36LL, 1);
                                MemoryWrite("10", 24LL, 1);
                                MemoryWrite("10", 84LL, 1);
                                MemoryWrite("10", 144LL, 1);
                              }
                              else if ( v11 <= 7380 )
                              {
                                if ( v11 == 6416 )
                                {
                                  SetSearchRange(9);
                                  MemorySearch("1100159584", 0);
                                  MemoryOffset("1503031935", 44LL, 0);
                                  MemoryWrite("1124229964", 0LL, 0);
                                }
                                else if ( v11 <= 6416 )
                                {
                                  if ( v11 == 6390 )
                                  {
                                    SetSearchRange(9);
                                    MemorySearch("1.40129846e-45", 1);
                                    MemoryOffset("45", -4LL, 1);
                                    MemoryOffset("45", -8LL, 1);
                                    MemoryOffset("135", 52LL, 1);
                                    MemoryOffset("135", 56LL, 1);
                                    MemoryOffset("225", 112LL, 1);
                                    MemoryOffset("225", 116LL, 1);
                                    MemoryOffset("315", 172LL, 1);
                                    MemoryOffset("315", 176LL, 1);
                                    MemoryWrite("1100", -32LL, 1);
                                    MemoryWrite("1100", 28LL, 1);
                                    MemoryWrite("1100", 88LL, 1);
                                    MemoryWrite("1100", 148LL, 1);
                                  }
                                  else if ( v11 <= 6390 )
                                  {
                                    if ( v11 == 6389 )
                                    {
                                      SetSearchRange(9);
                                      MemorySearch("1.40129846e-45", 1);
                                      MemoryOffset("45", -4LL, 1);
                                      MemoryOffset("45", -8LL, 1);
                                      MemoryOffset("135", 52LL, 1);
                                      MemoryOffset("135", 56LL, 1);
                                      MemoryOffset("225", 112LL, 1);
                                      MemoryOffset("225", 116LL, 1);
                                      MemoryOffset("315", 172LL, 1);
                                      MemoryOffset("315", 176LL, 1);
                                      MemoryWrite("1000", -32LL, 1);
                                      MemoryWrite("1000", 28LL, 1);
                                      MemoryWrite("1000", 88LL, 1);
                                      MemoryWrite("1000", 148LL, 1);
                                    }
                                    else if ( v11 <= 6389 )
                                    {
                                      if ( v11 == 6388 )
                                      {
                                        SetSearchRange(9);
                                        MemorySearch("1.40129846e-45", 1);
                                        MemoryOffset("45", -4LL, 1);
                                        MemoryOffset("45", -8LL, 1);
                                        MemoryOffset("135", 52LL, 1);
                                        MemoryOffset("135", 56LL, 1);
                                        MemoryOffset("225", 112LL, 1);
                                        MemoryOffset("225", 116LL, 1);
                                        MemoryOffset("315", 172LL, 1);
                                        MemoryOffset("315", 176LL, 1);
                                        MemoryWrite("900", -32LL, 1);
                                        MemoryWrite("900", 28LL, 1);
                                        MemoryWrite("900", 88LL, 1);
                                        MemoryWrite("900", 148LL, 1);
                                      }
                                      else if ( v11 <= 6388 )
                                      {
                                        if ( v11 == 6387 )
                                        {
                                          SetSearchRange(9);
                                          MemorySearch("1.40129846e-45", 1);
                                          MemoryOffset("45", -4LL, 1);
                                          MemoryOffset("45", -8LL, 1);
                                          MemoryOffset("135", 52LL, 1);
                                          MemoryOffset("135", 56LL, 1);
                                          MemoryOffset("225", 112LL, 1);
                                          MemoryOffset("225", 116LL, 1);
                                          MemoryOffset("315", 172LL, 1);
                                          MemoryOffset("315", 176LL, 1);
                                          MemoryWrite("800", -32LL, 1);
                                          MemoryWrite("800", 28LL, 1);
                                          MemoryWrite("800", 88LL, 1);
                                          MemoryWrite("800", 148LL, 1);
                                        }
                                        else if ( v11 <= 6387 )
                                        {
                                          if ( v11 == 6386 )
                                          {
                                            SetSearchRange(9);
                                            MemorySearch("1.40129846e-45", 1);
                                            MemoryOffset("45", -4LL, 1);
                                            MemoryOffset("45", -8LL, 1);
                                            MemoryOffset("135", 52LL, 1);
                                            MemoryOffset("135", 56LL, 1);
                                            MemoryOffset("225", 112LL, 1);
                                            MemoryOffset("225", 116LL, 1);
                                            MemoryOffset("315", 172LL, 1);
                                            MemoryOffset("315", 176LL, 1);
                                            MemoryWrite("700", -32LL, 1);
                                            MemoryWrite("700", 28LL, 1);
                                            MemoryWrite("700", 88LL, 1);
                                            MemoryWrite("700", 148LL, 1);
                                          }
                                          else if ( v11 <= 6386 )
                                          {
                                            if ( v11 == 6385 )
                                            {
                                              SetSearchRange(9);
                                              MemorySearch("1.40129846e-45", 1);
                                              MemoryOffset("45", -4LL, 1);
                                              MemoryOffset("45", -8LL, 1);
                                              MemoryOffset("135", 52LL, 1);
                                              MemoryOffset("135", 56LL, 1);
                                              MemoryOffset("225", 112LL, 1);
                                              MemoryOffset("225", 116LL, 1);
                                              MemoryOffset("315", 172LL, 1);
                                              MemoryOffset("315", 176LL, 1);
                                              MemoryWrite("600", -32LL, 1);
                                              MemoryWrite("600", 28LL, 1);
                                              MemoryWrite("600", 88LL, 1);
                                              MemoryWrite("600", 148LL, 1);
                                            }
                                            else if ( v11 <= 6385 )
                                            {
                                              if ( v11 == 6384 )
                                              {
                                                SetSearchRange(9);
                                                MemorySearch("1.40129846e-45", 1);
                                                MemoryOffset("45", -4LL, 1);
                                                MemoryOffset("45", -8LL, 1);
                                                MemoryOffset("135", 52LL, 1);
                                                MemoryOffset("135", 56LL, 1);
                                                MemoryOffset("225", 112LL, 1);
                                                MemoryOffset("225", 116LL, 1);
                                                MemoryOffset("315", 172LL, 1);
                                                MemoryOffset("315", 176LL, 1);
                                                MemoryWrite("500", -32LL, 1);
                                                MemoryWrite("500", 28LL, 1);
                                                MemoryWrite("500", 88LL, 1);
                                                MemoryWrite("500", 148LL, 1);
                                              }
                                              else if ( v11 <= 6384 )
                                              {
                                                if ( v11 == 6383 )
                                                {
                                                  SetSearchRange(9);
                                                  MemorySearch("1.40129846e-45", 1);
                                                  MemoryOffset("45", -4LL, 1);
                                                  MemoryOffset("45", -8LL, 1);
                                                  MemoryOffset("135", 52LL, 1);
                                                  MemoryOffset("135", 56LL, 1);
                                                  MemoryOffset("225", 112LL, 1);
                                                  MemoryOffset("225", 116LL, 1);
                                                  MemoryOffset("315", 172LL, 1);
                                                  MemoryOffset("315", 176LL, 1);
                                                  MemoryWrite("400", -32LL, 1);
                                                  MemoryWrite("400", 28LL, 1);
                                                  MemoryWrite("400", 88LL, 1);
                                                  MemoryWrite("400", 148LL, 1);
                                                }
                                                else if ( v11 <= 6383 )
                                                {
                                                  if ( v11 == 6382 )
                                                  {
                                                    SetSearchRange(9);
                                                    MemorySearch("1.40129846e-45", 1);
                                                    MemoryOffset("45", -4LL, 1);
                                                    MemoryOffset("45", -8LL, 1);
                                                    MemoryOffset("135", 52LL, 1);
                                                    MemoryOffset("135", 56LL, 1);
                                                    MemoryOffset("225", 112LL, 1);
                                                    MemoryOffset("225", 116LL, 1);
                                                    MemoryOffset("315", 172LL, 1);
                                                    MemoryOffset("315", 176LL, 1);
                                                    MemoryWrite("300", -32LL, 1);
                                                    MemoryWrite("300", 28LL, 1);
                                                    MemoryWrite("300", 88LL, 1);
                                                    MemoryWrite("300", 148LL, 1);
                                                  }
                                                  else if ( v11 <= 6382 )
                                                  {
                                                    if ( v11 == 6381 )
                                                    {
                                                      SetSearchRange(9);
                                                      MemorySearch("1.40129846e-45", 1);
                                                      MemoryOffset("45", -4LL, 1);
                                                      MemoryOffset("45", -8LL, 1);
                                                      MemoryOffset("135", 52LL, 1);
                                                      MemoryOffset("135", 56LL, 1);
                                                      MemoryOffset("225", 112LL, 1);
                                                      MemoryOffset("225", 116LL, 1);
                                                      MemoryOffset("315", 172LL, 1);
                                                      MemoryOffset("315", 176LL, 1);
                                                      MemoryWrite("200", -32LL, 1);
                                                      MemoryWrite("200", 28LL, 1);
                                                      MemoryWrite("200", 88LL, 1);
                                                      MemoryWrite("200", 148LL, 1);
                                                    }
                                                    else if ( v11 <= 6381 )
                                                    {
                                                      if ( v11 == 6380 )
                                                      {
                                                        SetSearchRange(9);
                                                        MemorySearch("1.40129846e-45", 1);
                                                        MemoryOffset("45", -4LL, 1);
                                                        MemoryOffset("45", -8LL, 1);
                                                        MemoryOffset("135", 52LL, 1);
                                                        MemoryOffset("135", 56LL, 1);
                                                        MemoryOffset("225", 112LL, 1);
                                                        MemoryOffset("225", 116LL, 1);
                                                        MemoryOffset("315", 172LL, 1);
                                                        MemoryOffset("315", 176LL, 1);
                                                        MemoryWrite("100", -32LL, 1);
                                                        MemoryWrite("100", 28LL, 1);
                                                        MemoryWrite("100", 88LL, 1);
                                                        MemoryWrite("100", 148LL, 1);
                                                      }
                                                      else if ( v11 <= 6380 )
                                                      {
                                                        if ( v11 == 6328 )
                                                        {
                                                          XA_BaseAddress_DWORD(v9 + 65426768, -1222129996);
                                                        }
                                                        else if ( v11 <= 6328 )
                                                        {
                                                          if ( v11 == 5297 )
                                                          {
                                                            XA_BaseAddress_FLOAT(v9 + 51403416, 10.0);
                                                          }
                                                          else if ( v11 <= 5297 )
                                                          {
                                                            if ( v11 == 3738 )
                                                            {
                                                              SetSearchRange(9);
                                                              MemorySearch("1", 1);
                                                              MemoryOffset("0.000005", -4LL, 1);
                                                              MemoryWrite("0.000005", 0LL, 1);
                                                            }
                                                            else if ( v11 <= 3738 )
                                                            {
                                                              if ( v11 == 3672 )
                                                              {
                                                                SetSearchRange(9);
                                                                MemorySearch("0.000005", 1);
                                                                MemoryOffset("0.000005", -4LL, 1);
                                                                MemoryWrite("1", 0LL, 1);
                                                              }
                                                              else if ( v11 <= 3672 )
                                                              {
                                                                if ( v11 == 3157 )
                                                                {
                                                                  SetSearchRange(9);
                                                                  MemorySearch("1120403456", 0);
                                                                  MemoryOffset("1431681986", -8LL, 0);
                                                                  MemoryWrite("1102851477", 0LL, 0);
                                                                  MemorySearch("1128792064", 0);
                                                                  MemoryOffset("2050064359", 12LL, 0);
                                                                  MemoryWrite("963608576", 0LL, 0);
                                                                }
                                                                else if ( v11 <= 3157 )
                                                                {
                                                                  if ( v11 == 2966 )
                                                                  {
                                                                    SetSearchRange(9);
                                                                    MemorySearch("2.65628006e20", 1);
                                                                    MemoryOffset("999906560", -76LL, 1);
                                                                    MemoryWrite("2.6562681e20", 0LL, 1);
                                                                  }
                                                                  else if ( v11 <= 2966 )
                                                                  {
                                                                    if ( v11 == 2647 )
                                                                    {
                                                                      SetSearchRange(9);
                                                                      MemorySearch("1124229964", 0);
                                                                      MemoryOffset("1503031935", 44LL, 0);
                                                                      MemoryWrite("1100159584", 0LL, 0);
                                                                    }
                                                                    else if ( v11 <= 2647 )
                                                                    {
                                                                      if ( v11 == 1386 )
                                                                      {
                                                                        SetSearchRange(9);
                                                                        MemorySearch("-980", 1);
                                                                        MemorySearch("-980", 1);
                                                                        MemorySearch("-980", 1);
                                                                        MemoryWrite("35000", 0LL, 1);
                                                                        sleep(1LL);
                                                                        MemoryWrite("-980", 0LL, 1);
                                                                      }
                                                                      else if ( v11 <= 1386 )
                                                                      {
                                                                        if ( v11 == 1111 )
                                                                        {
                                                                          XA_BaseAddress_FLOAT(v9 + 62586160, 200.0);
                                                                        }
                                                                        else if ( v11 <= 1111 )
                                                                        {
                                                                          if ( v11 == 999 )
                                                                          {
                                                                            XA_BaseAddress_FLOAT(v9 + 62586160, 230.0);
                                                                          }
                                                                          else if ( v11 <= 999 )
                                                                          {
                                                                            if ( v11 == 939 )
                                                                            {
                                                                              XA_BaseAddress_FLOAT(
                                                                                v9 + 61757424,
                                                                                -1.1145e28);
                                                                              XA_BaseAddress_FLOAT(
                                                                                v9 + 62573920,
                                                                                -1.1145e28);
                                                                            }
                                                                            else if ( v11 <= 939 )
                                                                            {
                                                                              if ( v11 == 888 )
                                                                              {
                                                                                XA_BaseAddress_FLOAT(
                                                                                  v9 + 62586160,
                                                                                  260.0);
                                                                              }
                                                                              else if ( v11 <= 888 )
                                                                              {
                                                                                if ( v11 == 870 )
                                                                                {
                                                                                  XA_BaseAddress_FLOAT(
                                                                                    v9 + 52843600,
                                                                                    0.0);
                                                                                }
                                                                                else if ( v11 <= 870 )
                                                                                {
                                                                                  if ( v11 == 858 )
                                                                                  {
                                                                                    XA_BaseAddress_FLOAT(
                                                                                      v9 + 61757424,
                                                                                      0.0);
                                                                                    XA_BaseAddress_FLOAT(
                                                                                      v9 + 62573920,
                                                                                      0.0);
                                                                                  }
                                                                                  else if ( v11 <= 858 )
                                                                                  {
                                                                                    if ( v11 == 777 )
                                                                                    {
                                                                                      XA_BaseAddress_FLOAT(
                                                                                        v9 + 62586160,
                                                                                        300.0);
                                                                                    }
                                                                                    else if ( v11 <= 777 )
                                                                                    {
                                                                                      if ( v11 == 774 )
                                                                                      {
                                                                                        XA_BaseAddress_FLOAT(
                                                                                          v9 + 31949668,
                                                                                          -1.1145e28);
                                                                                      }
                                                                                      else if ( v11 <= 774 )
                                                                                      {
                                                                                        if ( v11 == 678 )
                                                                                        {
                                                                                          XA_BaseAddress_FLOAT(
                                                                                            v9 + 52843600,
                                                                                            -2.7415e28);
                                                                                        }
                                                                                        else if ( v11 <= 678 )
                                                                                        {
                                                                                          if ( v11 == 666 )
                                                                                          {
                                                                                            XA_BaseAddress_FLOAT(
                                                                                              v9 + 62586160,
                                                                                              330.0);
                                                                                          }
                                                                                          else if ( v11 <= 666 )
                                                                                          {
                                                                                            if ( v11 == 555 )
                                                                                            {
                                                                                              XA_BaseAddress_FLOAT(
                                                                                                v9 + 62586160,
                                                                                                360.0);
                                                                                            }
                                                                                            else if ( v11 <= 555 )
                                                                                            {
                                                                                              if ( v11 > 303 )
                                                                                              {
                                                                                                if ( v11 == 420 )
                                                                                                  XA_BaseAddress_FLOAT(
                                                                                                    v9 + 51403416,
                                                                                                    0.0001);
                                                                                              }
                                                                                              else if ( v11 > 0 )
                                                                                              {
                                                                                                switch ( v11 )
                                                                                                {
                                                                                                  case 1:
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830136, -1.3978e24);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830108, -1.3978e24);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830124, -1.3978e24);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830120, -1.362e28);
                                                                                                    break;
                                                                                                  case 2:
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830136, -1.3978e24);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830108, -1.3978e24);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830124, -1.3978e24);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830120, 0.0);
                                                                                                    break;
                                                                                                  case 3:
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830108, -1.3978e24);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830124, -1.3978e24);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830120, -1.362e28);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830136, 0.0);
                                                                                                    break;
                                                                                                  case 4:
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830136, -1.3978e24);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830120, -1.362e28);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830124, 0.0);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830108, 0.0);
                                                                                                    break;
                                                                                                  case 5:
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830108, -1.3978e24);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830120, -1.362e28);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830124, 0.0);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830136, 0.0);
                                                                                                    break;
                                                                                                  case 6:
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830136, -1.3978e24);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830108, -1.3978e24);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830120, -1.362e28);
                                                                                                    XA_BaseAddress_FLOAT(v9 + 50830124, 0.0);
                                                                                                    break;
                                                                                                  case 65:
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("2500000000", 1);
                                                                                                    MemoryOffset("3600000000", -8LL, 1);
                                                                                                    MemoryOffset("50", 48LL, 1);
                                                                                                    MemoryWrite("70", 40LL, 1);
                                                                                                    MemoryWrite("-63", 44LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 66:
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("2500000000", 1);
                                                                                                    MemoryOffset("3600000000", -8LL, 1);
                                                                                                    MemoryOffset("50", 48LL, 1);
                                                                                                    MemoryWrite("88", 40LL, 1);
                                                                                                    MemoryWrite("60", 44LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 72:
                                                                                                    XA_BaseAddress_FLOAT(v9 + 21798876, -1.362e28);
                                                                                                    break;
                                                                                                  case 74:
                                                                                                    XA_BaseAddress_FLOAT(v9 + 21798876, 0.0);
                                                                                                    break;
                                                                                                  case 123:
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("310", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("220", 0LL, 1);
                                                                                                    MemorySearch("420", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("220", 0LL, 1);
                                                                                                    MemorySearch("590", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("220", 0LL, 1);
                                                                                                    MemorySearch("620", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("220", 0LL, 1);
                                                                                                    MemorySearch("1000", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("220", 0LL, 1);
                                                                                                    break;
                                                                                                  case 124:
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("220", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("310", 0LL, 1);
                                                                                                    MemorySearch("420", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("310", 0LL, 1);
                                                                                                    MemorySearch("590", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("310", 0LL, 1);
                                                                                                    MemorySearch("620", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("310", 0LL, 1);
                                                                                                    MemorySearch("1000", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("310", 0LL, 1);
                                                                                                    MemorySearch("220", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("310", 0LL, 1);
                                                                                                    break;
                                                                                                  case 125:
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("220", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("420", 0LL, 1);
                                                                                                    MemorySearch("310", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("420", 0LL, 1);
                                                                                                    MemorySearch("590", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("420", 0LL, 1);
                                                                                                    MemorySearch("620", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("420", 0LL, 1);
                                                                                                    MemorySearch("1000", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("420", 0LL, 1);
                                                                                                    MemorySearch("220", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("420", 0LL, 1);
                                                                                                    break;
                                                                                                  case 126:
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("220", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("590", 0LL, 1);
                                                                                                    MemorySearch("310", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("590", 0LL, 1);
                                                                                                    MemorySearch("420", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("590", 0LL, 1);
                                                                                                    MemorySearch("620", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("590", 0LL, 1);
                                                                                                    MemorySearch("1000", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("590", 0LL, 1);
                                                                                                    MemorySearch("220", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("590", 0LL, 1);
                                                                                                    break;
                                                                                                  case 127:
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("220", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("620", 0LL, 1);
                                                                                                    MemorySearch("310", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("620", 0LL, 1);
                                                                                                    MemorySearch("420", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("620", 0LL, 1);
                                                                                                    MemorySearch("590", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("620", 0LL, 1);
                                                                                                    MemorySearch("1000", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("620", 0LL, 1);
                                                                                                    MemorySearch("220", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("620", 0LL, 1);
                                                                                                    break;
                                                                                                  case 128:
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("220", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("1000", 0LL, 1);
                                                                                                    MemorySearch("310", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("1000", 0LL, 1);
                                                                                                    MemorySearch("420", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("1000", 0LL, 1);
                                                                                                    MemorySearch("590", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("1000", 0LL, 1);
                                                                                                    MemorySearch("620", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("1000", 0LL, 1);
                                                                                                    MemorySearch("220", 1);
                                                                                                    MemoryOffset("25", 8LL, 1);
                                                                                                    MemoryOffset("178", 24LL, 1);
                                                                                                    MemoryWrite("1000", 0LL, 1);
                                                                                                    break;
                                                                                                  case 152:
                                                                                                    SetSearchRange(5);
                                                                                                    MemorySearch("0", 1);
                                                                                                    MemoryOffset("-2.7860151e28", 4LL, 1);
                                                                                                    MemoryOffset("-3.7444097e28", 8LL, 1);
                                                                                                    MemoryWrite("-6.077603e27", 0LL, 1);
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(5);
                                                                                                    MemorySearch("0", 1);
                                                                                                    MemoryOffset("-1.3045739e23", 4LL, 1);
                                                                                                    MemoryOffset("-2.6563314e21", 8LL, 1);
                                                                                                    MemoryWrite("-1.427811e28", 0LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 200:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.00050000002", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 201:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.00999999978", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 202:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.01999999955", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 203:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.02999999933", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 204:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.03999999911", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 205:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.05000000075", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 206:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.05999999866", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 207:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.07000000003", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 208:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.07999999821", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 209:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.09000000358", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 210:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.10000000149", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 211:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.10099999994", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 212:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.11999999732", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 213:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.12999999523", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 214:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.14000000006", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 215:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.15000000596", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 216:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.15999999642", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 217:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.17000000179", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 218:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.17999999225", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 219:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.18999999762", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 220:
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(9);
                                                                                                    MemorySearch("0.0001", 1);
                                                                                                    MemoryOffset("20", 4LL, 1);
                                                                                                    MemoryOffset("0.40000000596", 12LL, 1);
                                                                                                    MemoryWrite("0.20000000298", 8LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  case 303:
                                                                                                    SetSearchRange(5);
                                                                                                    MemorySearch("-6.077603e27", 1);
                                                                                                    MemoryOffset("-2.7860151e28", 4LL, 1);
                                                                                                    MemoryOffset("-3.7444097e28", 8LL, 1);
                                                                                                    MemoryWrite("0", 0LL, 1);
                                                                                                    ClearResults();
                                                                                                    SetSearchRange(5);
                                                                                                    MemorySearch("-1.427811e28", 1);
                                                                                                    MemoryOffset("-1.3045739e23", 4LL, 1);
                                                                                                    MemoryOffset("-2.6563314e21", 8LL, 1);
                                                                                                    MemoryWrite("0", 0LL, 1);
                                                                                                    ClearResults();
                                                                                                    break;
                                                                                                  default:
                                                                                                    return 0;
                                                                                                }
                                                                                              }
                                                                                            }
                                                                                          }
                                                                                        }
                                                                                      }
                                                                                    }
                                                                                  }
                                                                                }
                                                                              }
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return 0;
}