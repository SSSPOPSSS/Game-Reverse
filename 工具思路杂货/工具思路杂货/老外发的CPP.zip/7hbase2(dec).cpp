int __cdecl main(int argc, const char **argv, const char **envp)
{
  __int64 v3; // x0
  char v5; // [xsp+20h] [xbp+20h]
  char v6; // [xsp+88h] [xbp+88h]
  int v7; // [xsp+ECh] [xbp+ECh]

  v7 = atoi(argv[1]);
  if ( (unsigned int)isapkrunning("com.tencent.ig") == 1 )
  {
    v3 = sprintf(&v5, "com.tencent.ig");
  }
  else if ( (unsigned int)isapkrunning("com.vng.pubgmobile") == 1 )
  {
    v3 = sprintf(&v5, "com.vng.pubgmobile");
  }
  else if ( (unsigned int)isapkrunning("com.pubg.krmobile") == 1 )
  {
    v3 = sprintf(&v5, "com.pubg.krmobile");
  }
  else if ( (unsigned int)isapkrunning("com.pubg.imobile") == 1 )
  {
    v3 = sprintf(&v5, "com.pubg.imobile");
  }
  else
  {
    v3 = (unsigned int)isapkrunning("com.rekoo.pubgm") == 1;
    if ( (_DWORD)v3 )
      v3 = sprintf(&v5, "com.rekoo.pubgm");
  }
  if ( (unsigned int)getuid(v3) == 0 )
    sprintf(&v6, "MODE_ROOT");
  else
    sprintf(&v6, "MODE_NO_ROOT");
  puts(&unk_43570);
  initXMemoryTools(&v5, &v6);
  switch ( v7 )
  {
    case 1:
      SetSearchRange(9);
      MemorySearch("1400129", 0);
      MemoryOffset("1400129", 0LL, 0);
      MemoryOffset("519", 4LL, 0);
      MemoryWrite("1405623", 0LL, 0);
      ClearResults();
      puts("XREVAN");
      break;
    case 2:
      SetSearchRange(9);
      MemorySearch("1405623", 0);
      MemoryOffset("1405623", 0LL, 0);
      MemoryOffset("519", 4LL, 0);
      MemoryWrite("1400129", 0LL, 0);
      ClearResults();
      break;
    case 3:
      SetSearchRange(9);
      MemorySearch("10100400", 0);
      MemoryOffset("10100400", 0LL, 0);
      MemoryOffset("8404", 4LL, 0);
      MemoryWrite("1101004045", 0LL, 0);
      ClearResults();
      break;
    case 4:
      SetSearchRange(9);
      MemorySearch("1101004045", 0);
      MemoryOffset("1101004045", 0LL, 0);
      MemoryOffset("8404", 4LL, 0);
      MemoryWrite("10100400", 0LL, 0);
      ClearResults();
      break;
    case 5:
      SetSearchRange(9);
      MemorySearch("10100300", 0);
      MemoryOffset("10100300", 0LL, 0);
      MemoryOffset("1101003057", 4LL, 0);
      MemoryWrite("1101003057", 0LL, 0);
      ClearResults();
      break;
    case 6:
      SetSearchRange(9);
      MemorySearch("1101003057", 0);
      MemoryOffset("1101003057", 0LL, 0);
      MemoryOffset("1101003057", 4LL, 0);
      MemoryWrite("10100300", 0LL, 0);
      ClearResults();
      break;
    case 7:
      SetSearchRange(9);
      MemorySearch("10300100", 0);
      MemoryOffset("10300100", 0LL, 0);
      MemoryOffset("10300100", 0LL, 0);
      MemoryWrite("1103001079", 0LL, 0);
      ClearResults();
      break;
    case 8:
      SetSearchRange(9);
      MemorySearch("1103001079", 0);
      MemoryOffset("1103001079", 0LL, 0);
      MemoryOffset("1103001079", 0LL, 0);
      MemoryWrite("10300100", 0LL, 0);
      ClearResults();
      break;
    case 9:
      SetSearchRange(9);
      MemorySearch("10300300", 0);
      MemoryOffset("10300300", 0LL, 0);
      MemoryOffset("10300300", 0LL, 0);
      MemoryWrite("1103003032", 0LL, 0);
      ClearResults();
      break;
    case 10:
      SetSearchRange(9);
      MemorySearch("1103003032", 0);
      MemoryOffset("1103003032", 0LL, 0);
      MemoryOffset("1103003032", 0LL, 0);
      MemoryWrite("10300300", 0LL, 0);
      ClearResults();
      break;
    case 11:
      SetSearchRange(9);
      MemorySearch("10800400", 0);
      MemoryOffset("10800400", 0LL, 0);
      MemoryWrite("1108004027", 0LL, 0);
      ClearResults();
      break;
    case 12:
      SetSearchRange(9);
      MemorySearch("1108004027", 0);
      MemoryOffset("1108004027", 0LL, 0);
      MemoryWrite("10800400", 0LL, 0);
      ClearResults();
      break;
    case 13:
      SetSearchRange(9);
      MemorySearch("10100100", 0);
      MemoryOffset("10100100", 0LL, 0);
      MemoryOffset("1101001103", 4LL, 0);
      MemoryWrite("1101001063", 0LL, 0);
      ClearResults();
      break;
    case 14:
      SetSearchRange(9);
      MemorySearch("1101001063", 0);
      MemoryOffset("1101001063", 0LL, 0);
      MemoryOffset("1101001063", 4LL, 0);
      MemoryWrite("10100100", 0LL, 0);
      ClearResults();
      break;
    case 15:
      SetSearchRange(9);
      MemorySearch("1400129", 0);
      MemoryOffset("1400129", 0LL, 0);
      MemoryOffset("1400129", 4LL, 0);
      MemoryWrite("1405628", 0LL, 0);
      ClearResults();
      SetSearchRange(9);
      MemorySearch("502001", 0);
      MemoryOffset("502001", 0LL, 0);
      MemoryOffset("502001", 4LL, 0);
      MemoryWrite("1402578", 0LL, 0);
      ClearResults();
      SetSearchRange(9);
      MemorySearch("502002", 0);
      MemoryOffset("502002", 0LL, 0);
      MemoryOffset("502002", 4LL, 0);
      MemoryWrite("1402578", 0LL, 0);
      ClearResults();
      SetSearchRange(9);
      MemorySearch("502003", 0);
      MemoryOffset("502003", 0LL, 0);
      MemoryOffset("502003", 4LL, 0);
      MemoryWrite("1402578", 0LL, 0);
      ClearResults();
      break;
    case 16:
      SetSearchRange(9);
      MemorySearch("1405628", 0);
      MemoryOffset("1405628", 0LL, 0);
      MemoryOffset("1405628", 4LL, 0);
      MemoryWrite("1400129", 0LL, 0);
      ClearResults();
      SetSearchRange(9);
      MemorySearch("1402578", 0);
      MemoryOffset("1402578", 0LL, 0);
      MemoryOffset("1402578", 4LL, 0);
      MemoryWrite("502001", 0LL, 0);
      ClearResults();
      ClearResults();
      SetSearchRange(9);
      MemorySearch("1402578", 0);
      MemoryOffset("1402578", 0LL, 0);
      MemoryOffset("1402578", 4LL, 0);
      MemoryWrite("502002", 0LL, 0);
      ClearResults();
      SetSearchRange(9);
      MemorySearch("1402578", 0);
      MemoryOffset("1402578", 0LL, 0);
      MemoryOffset("1402578", 4LL, 0);
      MemoryWrite("502003", 0LL, 0);
      ClearResults();
      break;
    case 17:
      SetSearchRange(9);
      MemorySearch("1903001", 0);
      MemoryOffset("1903001", 0LL, 0);
      MemoryOffset("1903001", 4LL, 0);
      MemoryWrite("1903023", 0LL, 0);
      ClearResults();
      break;
    case 18:
      SetSearchRange(9);
      MemorySearch("1903023", 0);
      MemoryOffset("1903023", 0LL, 0);
      MemoryOffset("1903023", 4LL, 0);
      MemoryWrite("1903001", 0LL, 0);
      ClearResults();
      break;
    case 19:
      ClearResults();
      SetSearchRange(9);
      MemorySearch("502001", 0);
      MemoryOffset("502001", 0LL, 0);
      MemoryOffset("502", -4LL, 0);
      MemoryWrite("1502001069", 0LL, 0);
      SetSearchRange(9);
      MemorySearch("502004", 0);
      MemoryOffset("502004", 0LL, 0);
      MemoryOffset("502", -4LL, 0);
      MemoryWrite("1502002069", 0LL, 0);
      SetSearchRange(9);
      MemorySearch("502002", 0);
      MemoryOffset("502002", 0LL, 0);
      MemoryOffset("502", -4LL, 0);
      MemoryWrite("1502002069", 0LL, 0);
      SetSearchRange(9);
      MemorySearch("502005", 0);
      MemoryOffset("502005", 0LL, 0);
      MemoryOffset("502", -4LL, 0);
      MemoryWrite("1502002069", 0LL, 0);
      SetSearchRange(9);
      MemorySearch("502003", 0);
      MemoryOffset("502003", 0LL, 0);
      MemoryOffset("502", -4LL, 0);
      MemoryWrite("1502003069", 0LL, 0);
      ClearResults();
      break;
    case 20:
      ClearResults();
      SetSearchRange(9);
      MemorySearch("1502001069", 0);
      MemoryOffset("1502001069", 0LL, 0);
      MemoryOffset("502", -4LL, 0);
      MemoryWrite("502001", 0LL, 0);
      SetSearchRange(9);
      MemorySearch("1502002069", 0);
      MemoryOffset("1502002069", 0LL, 0);
      MemoryOffset("502", -4LL, 0);
      MemoryWrite("502004", 0LL, 0);
      SetSearchRange(9);
      MemorySearch("1502002069", 0);
      MemoryOffset("1502002069", 0LL, 0);
      MemoryOffset("502", -4LL, 0);
      MemoryWrite("502002", 0LL, 0);
      SetSearchRange(9);
      MemorySearch("1502002069", 0);
      MemoryOffset("1502002069", 0LL, 0);
      MemoryOffset("502", -4LL, 0);
      MemoryWrite("502005", 0LL, 0);
      SetSearchRange(9);
      MemorySearch("1502003069", 0);
      MemoryOffset("1502003069", 0LL, 0);
      MemoryOffset("502", -4LL, 0);
      MemoryWrite("502003", 0LL, 0);
      ClearResults();
      break;
    case 31:
      SetSearchRange(9);
      MemorySearch("1400129", 0);
      MemoryOffset("1400129", 0LL, 0);
      MemoryOffset("519", 4LL, 0);
      MemoryWrite("1405870", 0LL, 0);
      ClearResults();
      break;
    case 32:
      SetSearchRange(9);
      MemorySearch("1400129", 0);
      MemoryOffset("1400129", 0LL, 0);
      MemoryOffset("519", 4LL, 0);
      MemoryWrite("1405092", 0LL, 0);
      ClearResults();
      break;
    case 33:
      SetSearchRange(9);
      MemorySearch("1400129", 0);
      MemoryOffset("1400129", 0LL, 0);
      MemoryOffset("519", 4LL, 0);
      MemoryWrite("1405186", 0LL, 0);
      ClearResults();
      break;
    case 34:
      SetSearchRange(9);
      MemorySearch("1400129", 0);
      MemoryOffset("1400129", 0LL, 0);
      MemoryOffset("519", 4LL, 0);
      MemoryWrite("1400687", 0LL, 0);
      ClearResults();
      break;
    default:
      return 0;
  }
  return 0;
}