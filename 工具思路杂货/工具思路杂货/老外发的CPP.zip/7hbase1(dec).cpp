int __cdecl main(int argc, const char **argv, const char **envp)
{
  char v4; // [xsp+20h] [xbp+20h]
  char v5; // [xsp+60h] [xbp+60h]
  __int64 v6; // [xsp+70h] [xbp+70h]
  int v7; // [xsp+78h] [xbp+78h]
  int v8; // [xsp+7Ch] [xbp+7Ch]

  v7 = atoi(argv[1]);
  v8 = getPID("com.tencent.ig");
  if ( !v8 )
  {
    v8 = getPID("com.pubg.krmobile");
    if ( !v8 )
    {
      v8 = getPID("com.vng.pubgmobile");
      if ( !v8 )
      {
        v8 = getPID("com.pubg.imobile");
        if ( !v8 )
        {
          puts("Aplikasi tidak berjalan!");
          exit(1LL);
        }
      }
    }
  }
  sprintf(&v4, "/proc/%d/mem", (unsigned int)v8);
  handle = open(&v4, 2LL);
  if ( handle == -1 )
  {
    puts("Gagal mendapatkan memory!\n");
    exit(1LL);
  }
  strcpy(&v5, "libUE4.so");
  v6 = get_module_base(v8, &v5);
  puts(&unk_1F90);
  if ( v7 == 9641 )
  {
    YOG_BaseAddress_FLOAT(v6 + 32269772, 0.0);
    close((unsigned int)handle);
  }
  else if ( v7 <= 9641 )
  {
    if ( v7 == 9273 )
    {
      YOG_BaseAddress_FLOAT(v6 + 65899116, 0.0);
      close((unsigned int)handle);
    }
    else if ( v7 <= 9273 )
    {
      if ( v7 == 6328 )
      {
        YOG_BaseAddress_FLOAT(v6 + 65899116, -0.00001);
        close((unsigned int)handle);
      }
      else if ( v7 <= 6328 )
      {
        if ( v7 == 5297 )
        {
          YOG_BaseAddress_FLOAT(v6 + 51847944, 10.0);
          close((unsigned int)handle);
        }
        else if ( v7 <= 5297 )
        {
          if ( v7 == 1111 )
          {
            YOG_BaseAddress_FLOAT(v6 + 63055072, 190.0);
            close((unsigned int)handle);
          }
          else if ( v7 <= 1111 )
          {
            if ( v7 == 999 )
            {
              YOG_BaseAddress_FLOAT(v6 + 63055072, 210.0);
              close((unsigned int)handle);
            }
            else if ( v7 <= 999 )
            {
              if ( v7 == 939 )
              {
                YOG_BaseAddress_FLOAT(v6 + 62227392, -1.1145e28);
                YOG_BaseAddress_FLOAT(v6 + 63042832, -1.1145e28);
                close((unsigned int)handle);
              }
              else if ( v7 <= 939 )
              {
                if ( v7 == 888 )
                {
                  YOG_BaseAddress_FLOAT(v6 + 63055072, 220.0);
                  close((unsigned int)handle);
                }
                else if ( v7 <= 888 )
                {
                  if ( v7 == 870 )
                  {
                    YOG_BaseAddress_FLOAT(v6 + 53292320, 0.0);
                    close((unsigned int)handle);
                  }
                  else if ( v7 <= 870 )
                  {
                    if ( v7 == 858 )
                    {
                      YOG_BaseAddress_FLOAT(v6 + 62227392, 0.0);
                      YOG_BaseAddress_FLOAT(v6 + 63042832, 0.0);
                      close((unsigned int)handle);
                    }
                    else if ( v7 <= 858 )
                    {
                      if ( v7 == 777 )
                      {
                        YOG_BaseAddress_FLOAT(v6 + 63055072, 240.0);
                        close((unsigned int)handle);
                      }
                      else if ( v7 <= 777 )
                      {
                        if ( v7 == 774 )
                        {
                          YOG_BaseAddress_FLOAT(v6 + 32269772, 3.8127e-21);
                          close((unsigned int)handle);
                        }
                        else if ( v7 <= 774 )
                        {
                          if ( v7 == 678 )
                          {
                            YOG_BaseAddress_FLOAT(v6 + 53292320, -2.7415e28);
                            close((unsigned int)handle);
                          }
                          else if ( v7 <= 678 )
                          {
                            if ( v7 == 666 )
                            {
                              YOG_BaseAddress_FLOAT(v6 + 63055072, 290.0);
                            }
                            else if ( v7 <= 666 )
                            {
                              if ( v7 == 555 )
                              {
                                YOG_BaseAddress_FLOAT(v6 + 63055072, 360.0);
                                close((unsigned int)handle);
                              }
                              else if ( v7 <= 555 )
                              {
                                if ( v7 == 420 )
                                {
                                  YOG_BaseAddress_FLOAT(v6 + 51847944, 0.0001);
                                  close((unsigned int)handle);
                                }
                                else if ( v7 <= 420 )
                                {
                                  if ( v7 == 98 )
                                  {
                                    YOG_BaseAddress_FLOAT(v6 + 42878508, 0.0);
                                    YOG_BaseAddress_DWORD(v6 + 17972808, 2046820353);
                                    YOG_BaseAddress_DWORD(v6 + 17977644, 2046820353);
                                    YOG_BaseAddress_DWORD(v6 + 22496432, 2046820353);
                                    close((unsigned int)handle);
                                  }
                                  else if ( v7 <= 98 )
                                  {
                                    if ( v7 == 97 )
                                    {
                                      YOG_BaseAddress_FLOAT(v6 + 42878508, 0.0);
                                      YOG_BaseAddress_DWORD(v6 + 17972808, 2046820353);
                                      YOG_BaseAddress_DWORD(v6 + 17977644, 2046820354);
                                      YOG_BaseAddress_DWORD(v6 + 22496432, 2046820354);
                                      close((unsigned int)handle);
                                    }
                                    else if ( v7 <= 97 )
                                    {
                                      if ( v7 == 96 )
                                      {
                                        YOG_BaseAddress_FLOAT(v6 + 42878508, 0.0);
                                        YOG_BaseAddress_DWORD(v6 + 17972808, 2046820354);
                                        YOG_BaseAddress_DWORD(v6 + 17977644, 2046820354);
                                        YOG_BaseAddress_DWORD(v6 + 22496432, 2046820354);
                                        close((unsigned int)handle);
                                      }
                                      else if ( v7 <= 96 )
                                      {
                                        if ( v7 == 95 )
                                        {
                                          YOG_BaseAddress_FLOAT(v6 + 42878508, 2015200000.0);
                                          YOG_BaseAddress_DWORD(v6 + 17972808, 2046820354);
                                          YOG_BaseAddress_DWORD(v6 + 17977644, 2046820354);
                                          YOG_BaseAddress_DWORD(v6 + 22496432, 2046820354);
                                          close((unsigned int)handle);
                                        }
                                        else if ( v7 <= 95 )
                                        {
                                          if ( v7 == 74 )
                                          {
                                            YOG_BaseAddress_FLOAT(v6 + 21939444, 0.0);
                                            YOG_BaseAddress_FLOAT(v6 + 21945488, 0.0);
                                            close((unsigned int)handle);
                                          }
                                          else if ( v7 <= 74 )
                                          {
                                            if ( v7 == 72 )
                                            {
                                              YOG_BaseAddress_FLOAT(v6 + 21939444, -1.362e28);
                                              YOG_BaseAddress_FLOAT(v6 + 21945488, -2.787e28);
                                              close((unsigned int)handle);
                                            }
                                            else if ( v7 <= 72 )
                                            {
                                              if ( v7 == 8 )
                                              {
                                                YOG_BaseAddress_FLOAT(v6 + 108939448, 0.0);
                                                YOG_BaseAddress_FLOAT(v6 + 108935008, COERCE_FLOAT(3014705));
                                                YOG_BaseAddress_FLOAT(v6 + 108935012, COERCE_FLOAT(3014705));
                                              }
                                              else if ( v7 <= 8 )
                                              {
                                                if ( v7 == 7 )
                                                {
                                                  YOG_BaseAddress_FLOAT(v6 + 42251432, -3.8923e21);
                                                  close((unsigned int)handle);
                                                }
                                                else if ( v7 <= 7 )
                                                {
                                                  if ( v7 == 6 )
                                                  {
                                                    YOG_BaseAddress_FLOAT(v6 + 42251432, 0.0);
                                                    close((unsigned int)handle);
                                                  }
                                                  else if ( v7 <= 6 )
                                                  {
                                                    if ( v7 == 1 )
                                                    {
                                                      YOG_BaseAddress_FLOAT(v6 + 51274712, -1.362e28);
                                                      close((unsigned int)handle);
                                                    }
                                                    else if ( v7 == 2 )
                                                    {
                                                      YOG_BaseAddress_FLOAT(v6 + 51274712, 0.0);
                                                      close((unsigned int)handle);
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return 0;
}