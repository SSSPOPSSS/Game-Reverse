#ifndef _ANDROIDMEMDEBUG_H_
#define _ANDROIDMEMDEBUG_H_

#include <stdio.h>
#include <stdlib.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/syscall.h>
#include <pthread.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <iostream>

// 支持的搜索类型
enum
{
	DWORD,
	FLOAT,
	BYTE,
	WORD,
	QWORD,
	XOR,
	DOUBLE,
};

// 支持的内存范围(请参考GG修改器内存范围)
enum
{
	Mem_Auto,					// 所以内存页
	Mem_A,
	Mem_Ca,
	Mem_Cd,
	Mem_Cb,
	Mem_Jh,
	Mem_J,
	Mem_S,
	Mem_V,
	Mem_Xa,
	Mem_Xs,
	Mem_As,
	Mem_B,
	Mem_O,
};

struct MemPage
{
	long start;
	long end;
	char flags[8];
	char name[128];
	void *buf = NULL;
};

struct AddressData
{
	long *addrs = NULL;
	int count = 0;
};

// 根据类型判断类型所占字节大小
size_t judgSize(int type)
{
	switch (type)
	{
	case DWORD:
	case FLOAT:
	case XOR:
		return 4;
	case BYTE:
		return sizeof(char);
	case WORD:
		return sizeof(short);
	case QWORD:
		return sizeof(long);
	case DOUBLE:
		return sizeof(double);
	}
	return 4;
}

int memContrast(char *str)
{
	if (strlen(str) == 0)
		return Mem_A;
	if (strstr(str, "/dev/ashmem/") != NULL)
		return Mem_As;
	if (strstr(str, "/system/fonts/") != NULL)
		return Mem_B;
	if (strstr(str, "/data/app/") != NULL)
		return Mem_Xa;
	if (strstr(str, "/system/framework/") != NULL)
		return Mem_Xs;
	if (strcmp(str, "[anon:libc_malloc]") == 0)
		return Mem_Ca;
	if (strstr(str, ":bss") != NULL)
		return Mem_Cb;
	if (strstr(str, "/data/data/") != NULL)
		return Mem_Cd;
	if (strstr(str, "[anon:dalvik") != NULL)
		return Mem_J;
	if (strcmp(str, "[stack]") == 0)
		return Mem_S;
	if (strcmp(str, "/dev/kgsl-3d0") == 0)
		return Mem_V;
	return Mem_O;
}



class MemoryDebug
{
  private:
	pid_t pid = 0;			// 调试应用的PID

  public:
  //设置调试的应用包名，返回PID
    int setPackageName(const char* name);
    //获取模块的基址，@name：模块名，@index：模块在内存中的内存页位置(第几位，从1开始，默认1)
    long getModuleBase(const char* name,int index = 1);
	//获取模块的BSS基址
	long getBssModuleBase(const char *name);
	//读内存的基础函数
	size_t preadv(long address, void *buffer, size_t size);
	//写内存的基础函数
	size_t pwritev(long address, void *buffer, size_t size);
	
	//根据值搜索内存，并返回相应地址
	template < class T > AddressData search(T value, int type, int mem, bool debug = false);
	//修改内存地址值，返回-1，修改失败，返回1，修改成功
	template < class T > int edit(T value,long address,int type,bool debug = false);
	
	//读取一个DWORD(int)数值
	int ReadDword(long address);
	//读取一个int指针地址数值
	long ReadDword64(long address);
	//读取一个float类型数值
	float ReadFloat(long address);
	//读取一个long类型数值
	long ReadLong(long address);
};

#include "AndroidMemDebug.cpp"

#endif
