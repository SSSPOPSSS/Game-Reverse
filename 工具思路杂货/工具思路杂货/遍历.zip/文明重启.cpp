#include "AndroidMemDebug.h"
#include <stdio.h>
float px;
float py;
int main(int argc, char** argv)
{
	FILE *fp = fopen("/sdcard/x", "r");
	FILE *fp1 = fopen("/sdcard/y", "r");
	if (fp==NULL||fp1==NULL)
	{
	 px=2340/2.0;
	 py=1080/2.0;
		}
	else
	{
	fscanf(fp, "%f", &px);
	printf("屏幕x%f\n",px);
	fscanf(fp1, "%f", &py);
	printf("屏幕y%f\n",py);
	if (py > px)
		{
			float t = px;
			px = py;
			py = t;
		}
		py = py / 2.0;
		px = px / 2.0;
		fclose(fp);
		fclose(fp1);
		}
	int rwgs=0;
    char aaa[2048] = "";
	char b[256];
	int fd;
	getRoot(argv);
	MemoryDebug md;
	/*
	matrix = gezz(gezz(gezz(libbase + 0xFF5900) + 0x50) + 0x8)+0xC4;
	*/
	
	
	md.setPackageName("com.yingxiong.gw.Android.hero");
    long BaseAddress = md.getModuleBase("libunity.so");
    long add=md.ReadDword(BaseAddress+0xFF5900)& 0xFFFFFFFF;
    add=md.ReadDword(add+0x50)& 0xFFFFFFFF;
    add=md.ReadDword(add+8)& 0xFFFFFFFF;
    char matrix[50];
    for (int i=0;i<16;i++)
    {
    add = md.ReadDword(0xC4+i*0x4);
    matrix[i] = add;
    printf("矩阵为%f\n",md.ReadFloat(matrix[i]));
    	}
    for (int a=0;a<99;a++)
    {
    long libone = md.getBssModuleBase("libilcpp.so");
    long Uleve = add = md.ReadDword(libone) + 0x11F8;
    long ux = md.ReadFloat(Uleve+0x4);
    long uy = md.ReadFloat(Uleve+0x8);
    long uz = md.ReadFloat(Uleve+0x12);
    float camear_z = matrix[3] * ux + matrix[7] * uz + matrix[11] * uy + matrix[15];
	float r_x = px + (matrix[0] * ux + matrix[4] * uz + matrix[8] * uy + matrix[12]) / camear_z * px;
	float r_y = py - (matrix[1] * ux + matrix[5] * (uz + 0.5) + matrix[9] * uy + matrix[13]) / camear_z * py;
	float r_w = py - (matrix[1] * ux + matrix[5] * (uz - 0.5) + matrix[9] * uy + matrix[13]) / camear_z * py;
    sprintf(b,"%f,%f,%f,%f",r_x - (r_y - r_w)/4, r_y,(r_y - r_w) / 2,r_y - r_w,rwgs);
    strcat(aaa, b);
	rwgs+=1;
     }
    rwgs=0;
    fd = open("/sdcard/b.log", O_WRONLY | O_CREAT);
    write(fd, aaa, sizeof(aaa));
    close(fd);
    usleep(10);
}