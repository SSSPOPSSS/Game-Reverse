
#include <MemoryTools.H>

//开源QQ2656301969
#include <string>
long Matrixa = 0,Matrix,BaseMatrix;
int m = 0;

int getMatrix()
{
	if (m == 0)
	{
		for (int i = 0; Matrix != 128; i++)
		{
			Matrix = ReadZZ(ReadZZ(BaseMatrix) + i * 0x8) + 0x80;
			if (ReadFloat(Matrix) > 1)
			{
				if (ReadDword(Matrix + 0x3c) == 0)
				{
					Matrixa = Matrix + 0x40;
				}
				else
				{
					Matrixa = Matrix;
				}
				if (ReadFloat(Matrixa + 0x14) > 0)
				{
					printf("扫描到矩阵0x%lX\n", Matrixa);
					m = 1;
					return Matrixa;
				}
			}
		}
		printf("未扫描到矩阵\n");
		return 0;
	}
}

void yxpd()
{
	while (1)
	{
		pid = GetProcessID("com.tencent.tmgp.sgame");
		if (pid < 1)
		{
			printf("进程结束\n");
			exit(0);
		}
		sleep(2);
	}
}

float matrix[16];
int my_rd, hlpd;
int coordinates[2];
int main(int argc, char **argv)
{


//开源QQ2656301969
	GetProcessID("com.tencent.tmgp.sgame");
	std::thread t(yxpd);
	BaseMatrix = getModuleBase("libunity.so", 1) + 0x1402AF0;
	float py = ReadDword(BaseMatrix + 0x4A040) / 2;
	float px = ReadDword(BaseMatrix + 0x4A51FC) / 2;
	long lib = getModuleBase("libGameCore.so", 1) + 0x6BB3080;
	long ks = lib + 0x494d678;
	FILE *fp;
	system("rm -rf /sdcard/停止.log");
	while ((fp = fopen("/sdcard/停止.log", "r")) == NULL)
	{
		if (ReadDword(ks) == 1)
		{
			getMatrix();
			int sl = ReadDword(ReadZZ(lib) + 0x1c);

			long Buff_addr =
				ReadZZ(ReadZZ(ReadZZ(ReadZZ(ReadZZ(ReadZZ(lib) + 0xB0) + 0x18) + 0x30) + 0xA8) +
					   0xc8);

			if (ReadFloat(Matrixa) > 1)
			{
				hlpd = 1;
				my_rd = 1;
			}
			else
			{
				hlpd = -1;
				my_rd = 2;
			}
			int Ture_count = 0;
			char ygsj[3048], rwsj[256], sjtj[3048] = "";
			for (int i = 0; i < 16; i++)
			{
				matrix[i] = ReadFloat(Matrixa + 0x4 * i);
			}
			for (int i = 0; i < sl - 3; i++)
			{
				long Array_structure =
					ReadZZ(ReadZZ(ReadZZ(ReadZZ(lib) + 0x8) + 0x30 + 0x10 * i) + 0x58);

				int rd = ReadDword(Array_structure + 0x2c);
				if (rd == my_rd)
				{
					continue;
				}

				int id = ReadDword(Array_structure + 0x20);

				int Error = ReadDword(ReadZZ(Array_structure + 0x148) + 0x28);

				long Coordinate_addr = ReadZZ(ReadZZ(Array_structure + 0x148) + 0x10);

				for (int a = 0; a < 2; a++)
				{
					coordinates[a] = ReadDword(Coordinate_addr + 0xC * Error + 0x8 * a);
				}

				if (coordinates[0] == 0 || coordinates[1] == 0)
				{
					continue;
				}
				else
				{
					Ture_count++;
				}

				int dtx = coordinates[0] * hlpd, dty =
					coordinates[1] * hlpd;

				float d_x = coordinates[0] * 0.001;
				float d_y = coordinates[1] * 0.001;
				float d_z = 0;
				
				float camear_r = matrix[3] * d_x + matrix[7] * d_z + matrix[11] * d_y + matrix[15];
				
				float r_x =
					px + (matrix[0] * d_x + matrix[4] * d_z + matrix[8] * d_y +
						  matrix[12]) / camear_r * px;
				float r_y =
					py - (matrix[1] * d_x + matrix[5] * d_z + matrix[9] * d_y +
						  matrix[13]) / camear_r * py;
				float r_w =
					py - (matrix[1] * d_x + matrix[5] * (d_z + 3.7) + matrix[9] * d_y +
						  matrix[13]) / camear_r * py;

				int xl =
					ReadDword(ReadZZ(Array_structure + 0xD8) +
							  0x78) * 100 / ReadDword(ReadZZ(Array_structure + 0xD8) + 0x78 + 8);

				int hc = ReadDword(ReadZZ(ReadZZ(Array_structure + 0x98) + 0x1808) - 0x130);

				int zh =
					ReadDword(ReadZZ(ReadZZ(Array_structure + 0xD8) + 0xB98) + 0x4b0) / 8192000;

				int dz =
					ReadDword(ReadZZ(ReadZZ(Array_structure + 0xD8) + 0xB78) + 0x4b0) / 8192000;

				long hl[4];
				for (long i = 0; i < 4; i++)
				{
					long buff4 = ReadZZ(Buff_addr + (i * 16));
					hl[i] = ReadDword(buff4 + 0x1C8) / 1000;
				}

				long yl = ReadZZ(Buff_addr + 224);
				int yltime = ReadDword(yl+0x1C8) / 1000;
				long yl2 = ReadZZ(Buff_addr + 160);
				int yltime2 = ReadDword(yl2 + 0x1C8) / 1000;
				long xy = ReadZZ(Buff_addr + 240);
				int xytime3 = ReadDword(xy+0x1C8) / 1000;
				long xy2 = ReadZZ(Buff_addr + 176);
				int xytime4 = ReadDword(xy2 + 0x1C8) / 1000;
				long xn = ReadZZ(Buff_addr + 208);
				int xntime5 = ReadDword(xn+0x1C8) / 1000;
				long xn2 = ReadZZ(Buff_addr + 272);
				int xntime6 = ReadDword(xn2 + 0x1C8) / 1000;
				long yz = ReadZZ(Buff_addr + 256);
				int yztime7 = ReadDword(yz+0x1C8) / 1000;
				long yz2 = ReadZZ(Buff_addr + 192);
				int yztime8 = ReadDword(yz2 + 0x1C8) / 1000;
				
				float stx = r_x - (r_y - r_w) / 16, sty = r_y - (r_y - r_w) / 2;

				sprintf(rwsj, "1,%d,%d,%d,%d,%0.2f,%0.2f,%d,%d,%d;\n", id,
						xl, dtx, dty, stx, sty, hc, zh, dz);
				strcat(sjtj, rwsj);

				if (hlpd == 1)
				{
					sprintf(ygsj, "2,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d;",
							hl[0], hl[1], hl[2], hl[3], yltime, yltime2,
							xytime3, xytime4, xntime5, xntime6, yztime7,
							yztime8);
				}
				else if (hlpd != 1)
				{
					sprintf(ygsj, "2,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d;",
							hl[2], hl[3], hl[0], hl[1], yltime2, yltime,
							xytime4, xytime3, xntime6, xntime5, yztime8,
							yztime7);
				}
			}
			strcat(sjtj, ygsj);
			int fd = open("/sdcard/b.log", O_WRONLY | O_CREAT);
			write(fd, sjtj, sizeof(sjtj));
			close(fd);
			usleep(100);
		}
		else
		{
			m = 0;
		}
	}
	system("rm -rf /sdcard/停止.log");
}