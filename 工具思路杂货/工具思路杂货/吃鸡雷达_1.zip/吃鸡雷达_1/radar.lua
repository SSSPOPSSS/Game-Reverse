
function 创建文件(a)
  import "java.io.File"
  return File(a).createNewFile()
end
if 雷达半径==nil then
  雷达半径=200
end
function 文件是否存在(id)
  return File(id).exists()
end
import "android.content.Context"
function 调用(fun)
  import "java.io.File"
  if 文件是否存在("/sdcard/android/dofile.l")==true then
   else
    创建文件('/sdcard/android/dofile.l')
  end
  io.open("/storage/emulated/0/android/dofile.l","w"):write(fun):close()
  dofile("/storage/emulated/0/android/dofile.l")
end
悬浮窗limo={}
function error(a)
  print(a)
end
function 载入悬浮(布局,悬浮X,悬浮Y,悬浮宽,悬浮高)
  if 显示状态==nil then
    显示状态={}
  end
  布局=布局
  local 随机数=tostring(math.random(1,999999999999999))
  显示状态[随机数]=false
  if 悬浮X==nil then
    悬浮X=activity.getWidth()/6
   else
    悬浮X=悬浮X
  end
  if 悬浮Y==nil then
    悬浮Y=activity.getHeight()/6
   else
    悬浮Y=悬浮Y
  end

  if type(悬浮X)~="number" then
    error(">>载入悬浮<<该函数的第二参数必须为>>number<<类型")
  end
  if type(悬浮Y)~="number" then
    error(">>载入悬浮<<该函数的第三参数必须为>>number<<类型")
  end
  if 悬浮宽==nil then
    悬浮宽=-2
  end
  if 悬浮高==nil then
    悬浮高=-2
  end

  调用([[
  if wmManagerlimo1]]..随机数..[[==nil then
    wmManagerlimo1]]..随机数..[[=activity.getSystemService(Context.WINDOW_SERVICE) --获取窗口管理器
  HasFocus=true --是否有焦点
  wmParamslimo1]]..随机数..[[=WindowManager.LayoutParams() --对象
  wmParamslimo1]]..随机数..[[.type =WindowManager.LayoutParams.TYPE_SYSTEM_ALERT --设置悬浮窗limo方式
  import "android.graphics.PixelFormat" --导入
  wmParamslimo1]]..随机数..[[.format =PixelFormat.RGBA_8888 --设置背景
  if Build.VERSION.SDK_INT >= 26 then
    --安卓8~10
    wmParamslimo1]]..随机数..[[.type =WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    --悬浮窗limo打开方式
   else
    --安卓6~7.1.2
    wmParamslimo1]]..随机数..[[.type =WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
    --悬浮窗limo打开方式
  end
  wmParamslimo1]]..随机数..[[.flags= WindowManager.LayoutParams().FLAG_NOT_FOCUSABLE--焦点设置
  --焦点设置
  wmParamslimo1]]..随机数..[[.gravity = Gravity.LEFT| Gravity.TOP --重力设置
  wmParamslimo1]]..随机数..[[.x = ]]..tostring(悬浮X)..[[
  wmParamslimo1]]..随机数..[[.y = ]]..tostring(悬浮Y)..[[

  wmParamslimo1]]..随机数..[[.width =]]..tostring(悬浮宽)..[[--activity.getWidth()--WindowManager.LayoutParams.WRAP_CONTENT
  wmParamslimo1]]..随机数..[[.height =]]..tostring(悬浮高)..[[--activity.getHeight()--WindowManager.LayoutParams.WRAP_CONTENT

    end
 ]])

  悬浮窗limo[随机数]=loadlayout(布局)

  return 随机数
end
function 关闭悬浮(布局)
  if 显示状态[布局]==nil then
    error(">>关闭悬浮<<该函数传入的特征码不存在")
   else
    调用([[
  wmManagerlimo1]]..布局..[[.removeView(悬浮窗limo["]]..布局..[["])
  ]])
    显示状态[布局]=false
  end
end
function 显示悬浮(随机数)
  if 显示状态[随机数]==nil then
    error(">>显示悬浮<<该函数传入的特征码不存在")
   else

    调用([[
  wmManagerlimo1]]..随机数..[[.addView(悬浮窗limo["]]..随机数..[["],wmParamslimo1]]..随机数..[[)
  ]])
    显示状态[随机数]=true
  end
end
function 悬浮拖动(拖动,布局)
  if 显示状态[布局]==nil then
    error(">>悬浮拖动<<该函数的第二参数传入的特征码不存在")
   else
    调用([[
  function ]]..拖动..[[.OnTouchListener(v,event)
    if event.getAction()==MotionEvent.ACTION_DOWN then
      first]]..tostring(布局)..[[X=event.getRawX()
      first]]..tostring(布局)..[[Y=event.getRawY()
      wm]]..tostring(布局)..[[X=wmParamslimo1]]..布局..[[.x
      wm]]..tostring(布局)..[[Y=wmParamslimo1]]..布局..[[.y
     elseif event.getAction()==MotionEvent.ACTION_MOVE then
      wmParamslimo1]]..布局..[[.x=wm]]..tostring(布局)..[[X+(event.getRawX()-first]]..tostring(布局)..[[X)
      wmParamslimo1]]..布局..[[.y=wm]]..tostring(布局)..[[Y+(event.getRawY()-first]]..tostring(布局)..[[Y)
      wmManagerlimo1]]..布局..[[.updateViewLayout(悬浮窗limo["]]..tostring(布局)..[["],wmParamslimo1]]..布局..[[)
      -- wmManagerlimo1]]..布局..[[.updateViewLayout(二级悬浮,wmParamslimo1]]..布局..[[)
     elseif event.getAction()==MotionEvent.ACTION_UP then
    end
    return false
  end
]])
  end
end

function 悬浮状态(ID)
  if 显示状态[ID]==nil then
    error(">>悬浮状态<<该函数传入的特征码不存在")
   else
    return 显示状态[ID]
  end
end
function 修改悬浮(布局,ID)
  if 显示状态[ID]==nil then
    error(">>修改悬浮<<该函数的第二参数传入的特征码不存在")
   else
    悬浮窗limo[ID]=loadlayout(布局)
    if 悬浮状态(ID) then
      关闭悬浮(ID)
      显示悬浮(ID)
    end
  end
end
function 悬浮位置(x,y,ID)
  调用([[
  wmParamslimo1]]..tostring(ID)..[[.x=]]..tostring(x)..[[
    wmParamslimo1]]..tostring(ID)..[[.y=]]..tostring(y)..[[
      ]])
  if 悬浮状态(ID) then
    关闭悬浮(ID)
    显示悬浮(ID)
  end

end













import "android.provider.Settings"
function 判断悬浮窗权限()
  if (Build.VERSION.SDK_INT >= 23 and not Settings.canDrawOverlays(this)) then
    return false
   elseif Build.VERSION.SDK_INT < 23 then
    return nil
   else
    return true
  end
end

function 申请悬浮窗权限()
  import "android.net.Uri"
  import "android.content.Intent"
  import "android.provider.Settings"
  intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
  intent.setData(Uri.parse("package:" .. activity.getPackageName()));
  activity.startActivityForResult(intent, 100);
  --获取悬浮窗权限
end
function 中英(a)
  return a
end

if 判断悬浮窗权限() then
  --  print("有悬浮窗权限")
 else
  AlertDialog.Builder(this)
  --  .setTitle("没有悬浮窗权限！")
  .setMessage(中英("请允许显示在其他应用的上层","Please allow the suspension window to be displayed"))
  .setPositiveButton(中英("确定","Yes"),{onClick=function(v)申请悬浮窗权限()end})
  .show()
end






缩放=8

function 获取屏幕高1()
  import "android.util.DisplayMetrics"
  dm = DisplayMetrics();
  activity.getWindowManager().getDefaultDisplay().getRealMetrics(dm);
  local a = dm.widthPixels;
  local b = dm.heightPixels;
  if tonumber(a)>tonumber(b) then
    b=a
   else
    b=b
  end
  return tonumber(b)
end
高度=获取屏幕高1()
坐标x1=高度/2
function 写(a,b,str)
  --获取SharedPreferences文件，后面的第一个参数就是文件名，没有会自己创建，有就读取
  sp = activity.getSharedPreferences(a, Context.MODE_PRIVATE)
  --设置编辑
  sped = sp.edit()
  --设置键值对
  sped.putString(b,str)
  --提交保存数据
  sped.commit()
end

function 读(a,b)
  --获取SharedPreferences文件
  sp = activity.getSharedPreferences(a, Context.MODE_PRIVATE)
  --打印对应的值
  return sp.getString(b,"")
end
--创建示例布局
shamrock=
{
  LinearLayout;--线性布局
  Orientation='vertical';--布局方向
  layout_width="fill";--布局宽度
  layout_height='fill';--布局高度
  id='布局画布';--绑定id
  {
    LinearLayout;--线性布局
    Orientation='vertical';--布局方向
    layout_width="fill";--布局宽度
    layout_height='fill';--布局高度
    id='布局画布1';--绑定id

  };
};
ld=载入悬浮(shamrock,坐标x1+100,50,(雷达半径*2)+(8*(缩放/8)),雷达半径+80)
悬浮拖动("布局画布",ld)
function 角度(x0,y0,x1,y1)
  return math.tan(-1)*(y1-y0)/(x1-x0)
end

--调用方式
--x,y=圆形坐标(圆心x,圆心y,半径,角度)



function 雷达(x,y,r,画布,画笔)
  x=x+(8*(缩放/8))
  y=y+(8*(缩放/8))
  import "android.graphics.RectF"
  import "android.graphics.Paint"
  function 圆形坐标(x,y,r,ao)--圆形坐标算法，取圆上任意点的坐标
    if ao==0 then
      ao=360
    end
    ao=ao-90

    return x+r*math.cos(ao*math.pi/180),y+r*math.sin(ao*math.pi/180)
  end

  雷达x=x
  雷达y=y
  雷达r=r
  function 坐标(x1,m,ai,hp,画布,画笔)
    if x1>=0 && x1<=高度 && m<=320 then

      画笔.setStrokeWidth(8*(缩放/8))
      if hp==true or hp==0 then
        画笔.setColor(0xFFD7ADFF)
       elseif ai==true then
        画笔.setColor(0xffffffff)--设置画笔
       elseif ai==false then
        画笔.setColor(0xff00ff00)--设置画笔
      end
      ao1=360/((高度*2)/x1)
      if ao1<90 then
        ao1=ao1+270
       else
        ao1=ao1-90
      end
      if ao1>=0&&ao1<=360 then
        a,b=圆形坐标(雷达x,雷达y,m*(雷达r/320),ao1)
        画布.drawPoint(a,b,画笔)
      end
    end
  end
  function 坐标1(x1,ai,画布,画笔)
    if x1>=0 && x1<=高度 && m<=320 then
      画笔.setStrokeWidth((8*(缩放/8)))
      if ai then
        画笔.setColor(0xffffffff)--设置画笔
       else
        画笔.setColor(0xff00ff00)--设置画笔
      end
      ao1=360/((高度*2)/x1)
      if ao1<90 then
        ao1=ao1+270
       else
        ao1=ao1-90
      end
      if ao1>=0&&ao1<=360 then
        a,b=圆形坐标(雷达x,雷达y,雷达r+(8*(缩放/8)),ao1)
        画布.drawPoint(a,b,画笔)
      end
    end
  end
  画笔.setStrokeWidth((3*(缩放/8)))--设置画笔宽为10
  画笔.setColor(0x75000000)--设置画笔颜色
  画笔.setStyle(Paint.Style.FILL)
  画布.drawArc(RectF(x-(r),y-(r),x+r,y+r),-180,180,true,画笔)--画布绘制弧
  画笔.setStyle(Paint.Style.STROKE)
  画笔.setColor(0x7f000000)--设置画笔颜色
  画布.drawArc(RectF(x-(r),y-(r),x+r,y+r),-180,180,true,画笔)--画布绘制弧
  画布.drawArc(RectF(x-(r*(1/4)),y-(r*(1/4)),x+(r*(1/4)),y+(r*(1/4))),-180,180,true,画笔)--画布绘制弧
  画布.drawArc(RectF(x-(r*(2/4)),y-(r*(2/4)),x+(r*(2/4)),y+(r*(2/4))),-180,180,true,画笔)--画布绘制弧
  画布.drawArc(RectF(x-(r*(3/4)),y-(r*(3/4)),x+(r*(3/4)),y+(r*(3/4))),-180,180,true,画笔)--画布绘制弧
  a,b=圆形坐标(x,y,r,0)
  画布.drawLine(a,b,x,y,画笔)
  a,b=圆形坐标(x,y,r,30)
  画布.drawLine(a,b,x,y,画笔)
  a,b=圆形坐标(x,y,r,60)
  画布.drawLine(a,b,x,y,画笔)
  a,b=圆形坐标(x,y,r,300)
  画布.drawLine(a,b,x,y,画笔)
  a,b=圆形坐标(x,y,r,330)
  画布.drawLine(a,b,x,y,画笔)
  画笔.setColor(0xffff0000)--设置画笔颜色
  画笔.setStrokeWidth((8*(缩放/8)))
  画布.drawPoint(x,y,画笔)

end





布局画布.setBackground(--设置背景
LuaDrawable(--设置自绘制
function(画布,画笔)--绘制函数
  雷达(雷达半径,雷达半径,雷达半径,画布,画笔)
end))


time=0
缩放=8
function 缩放8()
  布局画布.onClick=function()
    if time+1 > tonumber(os.time()) then
      雷达半径=雷达半径-25
      缩放=缩放-1
      if 雷达半径<100 then
        雷达半径=200
        缩放=8
      end
      关闭悬浮(ld)
      ld=载入悬浮(shamrock,坐标x1+100,50,(雷达半径*2)+(8*(缩放/8)),雷达半径+80)
      悬浮拖动("布局画布",ld)
      显示悬浮(ld)
      缩放8()
      布局画布.setBackground(--设置背景
      LuaDrawable(--设置自绘制
      function(画布,画笔)--绘制函数
        雷达(雷达半径,雷达半径,雷达半径,画布,画笔)
      end))
      collectgarbage("collect")
      time=0
     else
      time=tonumber(os.time())
    end
  end
end
缩放8()
布局画布1.setBackground(--设置背景
LuaDrawable(--设置自绘制
function(画布,画笔)--绘制函数
  画笔.setTextSize(30)
  画笔.setColor(0xffff0000)
  画布.drawText("身后有【0】人",(雷达半径/2)-((雷达半径/20))+8,雷达半径+50,画笔)
end))
function 执行(func,sd)
  if sd==nil then
    sd=30
  end
  func1=func
  function 循环()
    人数=0
    布局画布1.setBackground(--设置背景
    LuaDrawable(--设置自绘制
    function(画布,画笔)--绘制函数
      func1(function(x3,h,m,hid,hp)
        if x3~=nil then
          if x3+200<0 or x3+200>高度 then
            x3=nil
          end
          if hid==0 then
            hid=true
           else
            hid=false
          end
          if hp>0 then
            hp=false
           else
            hp=true
          end
          if x3~=nil then
            if h>0 then
              坐标(x3+200,m,hid,hp,画布,画笔)
             elseif h<=0 && hp~=true then
              人数=人数+1
              坐标1(x3+200,hid,画布,画笔)
            end
          end
        end
      end)
      画笔.setTextSize(30)
      画笔.setColor(0xffff0000)
      画布.drawText("身后有【"..tostring(人数).."】人",(雷达半径/2)-((雷达半径/20))+8-(雷达半径*1.8/缩放),雷达半径+50,画笔)
    end))
  end
  thread(function(sd)
    while(true)
      call("循环")
      this.sleep(sd)
    end
  end,sd)

end
function 显示雷达()
  显示悬浮(ld)
end
function 隐藏雷达()
  关闭悬浮(ld)
end
collectgarbage("collect")
return 执行