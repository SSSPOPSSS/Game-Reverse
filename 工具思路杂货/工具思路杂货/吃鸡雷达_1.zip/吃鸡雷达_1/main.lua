require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "layout"
import "mian"
activity.setContentView(loadlayout(layout))


执行=import "radar"--导入雷达模块，并将返回函数赋值给变量"执行"

执行(function(参数)--运行雷达的返回函数，并将调用函数赋值给"参数"变量
  --运行自己的代码，获取坐标信息
  function 数组(s, c)
    if not s then return nil end
    local m = string.format("([^%s]+)", c)
    local t = {}
    local k = 1
    for v in string.gmatch(s, m) do
      t[k] = v
      k = k + 1
    end
    return t
  end

  file=数组(io.open("/sdcard/b.log"):read("*a"),"\n")
  for i=1,#file-1 do
    if file[i]~="" && file[i]:find("^%s-$")==nil then
      coor=数组(file[i],",")
      if coor[1]~=nil and coor[4]~=nil then
        x3=tonumber(coor[1])
        h=tonumber(coor[4])
        m=tonumber(coor[5])
        hid=tonumber(coor[7])
        hp=tonumber(coor[6])

        参数(x3,h,m,hid,hp)--执行调用函数，并将坐标信息循环传入
        --坐标信息依次为 x坐标,背敌判断,距离,人机判断,血量
      end
    end
  end
end,30)--雷达循环的间隔




开关=false
按钮.onClick=function()
  if 开关 then
    开关=false
    隐藏雷达()--隐藏雷达
    按钮.text="开启雷达"
   else
    开关=true
    显示雷达()--显示雷达
    按钮.text="关闭雷达"
  end
end

--导入模块直接载入雷达代码，运行返回函数，开始循环绘制(默认不显示雷达)，运行显示雷达函数，雷达显示出来
--本模块必须配合其他绘制，支持所有游戏(只要有坐标)
--该版本为异步版，会另开一个线程循环
--如需跟绘制一起循环，请使用同步版